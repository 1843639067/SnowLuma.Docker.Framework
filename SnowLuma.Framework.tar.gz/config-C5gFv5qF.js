import { randomBytes } from "crypto";
import fs from "fs";
import path from "path";
//#region src/onebot/config.ts
var CONFIG_DIR = "config";
var DEFAULT_CONFIG_PATH = path.join(CONFIG_DIR, "onebot.json");
var DEFAULT_ACCESS_TOKEN_BYTES = 32;
function makeDefaultOneBotConfig() {
	return {
		networks: {
			httpServers: [{
				name: "http-default",
				host: "0.0.0.0",
				port: 3e3,
				path: "/",
				accessToken: generateAccessToken(),
				messageFormat: "array",
				reportSelfMessage: false
			}],
			httpClients: [],
			wsServers: [{
				name: "ws-default",
				host: "0.0.0.0",
				port: 3001,
				path: "/",
				role: "universal",
				accessToken: generateAccessToken(),
				messageFormat: "array",
				reportSelfMessage: false
			}],
			wsClients: []
		},
		musicSignUrl: ""
	};
}
function generateAccessToken() {
	return randomBytes(DEFAULT_ACCESS_TOKEN_BYTES).toString("base64url");
}
function loadOneBotConfig(uin) {
	ensureConfigDir();
	const perUinPath = path.join(CONFIG_DIR, `onebot_${uin}.json`);
	const globalRaw = tryLoadJson(DEFAULT_CONFIG_PATH);
	const perUinRaw = tryLoadJson(perUinPath);
	const legacy = !!perUinRaw && hasLegacyTopLevel(perUinRaw);
	const sources = [];
	if (globalRaw) sources.push(globalRaw);
	if (perUinRaw) sources.push(perUinRaw);
	const config = fromJson(sources);
	if (!perUinRaw || legacy) saveOneBotConfig(uin, config);
	return config;
}
function saveOneBotConfig(uin, config) {
	ensureConfigDir();
	saveJson(path.join(CONFIG_DIR, `onebot_${uin}.json`), toJsonObject(config));
}
function ensureConfigDir() {
	fs.mkdirSync(CONFIG_DIR, { recursive: true });
}
function toJsonObject(config) {
	const nets = config.networks;
	return {
		networks: {
			httpServers: nets.httpServers.map(httpServerToJson),
			httpClients: nets.httpClients.map(httpClientToJson),
			wsServers: nets.wsServers.map(wsServerToJson),
			wsClients: nets.wsClients.map(wsClientToJson)
		},
		musicSignUrl: config.musicSignUrl ?? ""
	};
}
function applyBase(out, n) {
	out.name = n.name;
	if (n.enabled === false) out.enabled = false;
	if (n.accessToken) out.accessToken = n.accessToken;
	out.messageFormat = n.messageFormat;
	out.reportSelfMessage = n.reportSelfMessage;
}
function httpServerToJson(n) {
	const out = {};
	applyBase(out, n);
	out.host = n.host ?? "0.0.0.0";
	out.port = n.port;
	out.path = n.path ?? "/";
	return out;
}
function httpClientToJson(n) {
	const out = {};
	applyBase(out, n);
	out.url = n.url;
	if (typeof n.timeoutMs === "number" && n.timeoutMs > 0) out.timeoutMs = n.timeoutMs;
	return out;
}
function wsServerToJson(n) {
	const out = {};
	applyBase(out, n);
	out.host = n.host ?? "0.0.0.0";
	out.port = n.port;
	out.path = n.path ?? "/";
	out.role = n.role ?? "universal";
	return out;
}
function wsClientToJson(n) {
	const out = {};
	applyBase(out, n);
	out.url = n.url;
	out.role = n.role ?? "universal";
	out.reconnectIntervalMs = typeof n.reconnectIntervalMs === "number" && Number.isFinite(n.reconnectIntervalMs) ? Math.max(1e3, Math.trunc(n.reconnectIntervalMs)) : 5e3;
	return out;
}
function fromJson(sources) {
	let legacyFormat;
	let legacyReport;
	let musicSignUrl = "";
	for (const src of sources) {
		const mf = parseMessageFormat(src.messageFormat);
		if (mf) legacyFormat = mf;
		if (typeof src.reportSelfMessage === "boolean") legacyReport = src.reportSelfMessage;
		if (typeof src.musicSignUrl === "string") musicSignUrl = src.musicSignUrl;
	}
	const adapterDefaults = {
		messageFormat: legacyFormat ?? "array",
		reportSelfMessage: legacyReport ?? false
	};
	const httpServers = collectByName(sources, "httpServers", (raw) => parseHttpServer(raw, adapterDefaults));
	const httpClients = collectByName(sources, "httpClients", (raw) => parseHttpClient(raw, adapterDefaults), "httpPostEndpoints");
	const wsServers = collectByName(sources, "wsServers", (raw) => parseWsServer(raw, adapterDefaults));
	const wsClients = collectByName(sources, "wsClients", (raw) => parseWsClient(raw, adapterDefaults));
	if (httpServers.length === 0 && httpClients.length === 0 && wsServers.length === 0 && wsClients.length === 0) {
		const defaults = makeDefaultOneBotConfig().networks;
		httpServers.push(...defaults.httpServers);
		wsServers.push(...defaults.wsServers);
	}
	return {
		networks: {
			httpServers,
			httpClients,
			wsServers,
			wsClients
		},
		musicSignUrl
	};
}
function collectByName(sources, kind, parse, legacyKey) {
	const byName = /* @__PURE__ */ new Map();
	const order = [];
	let counter = 0;
	const ingest = (rawArr) => {
		if (!Array.isArray(rawArr)) return;
		for (const raw of rawArr) {
			if (!isObject(raw)) continue;
			const parsed = parse(raw);
			if (!parsed) continue;
			const name = parsed.name && parsed.name.trim() ? parsed.name.trim() : pickAutoName(kind, byName, ++counter);
			parsed.name = name;
			if (!byName.has(name)) order.push(name);
			byName.set(name, parsed);
		}
	};
	for (const src of sources) {
		ingest(isObject(src.networks) ? src.networks[kind] : void 0);
		if (legacyKey) ingest(src[legacyKey]);
		ingest(src[kind]);
	}
	return order.map((n) => byName.get(n));
}
function pickAutoName(kind, used, counter) {
	const prefix = kind === "httpServers" ? "http" : kind === "httpClients" ? "httppost" : kind === "wsServers" ? "ws" : "wsclient";
	let candidate = `${prefix}-${counter}`;
	while (used.has(candidate)) {
		counter += 1;
		candidate = `${prefix}-${counter}`;
	}
	return candidate;
}
function parseBase(value, defaults) {
	return {
		name: asString(value.name),
		enabled: typeof value.enabled === "boolean" ? value.enabled : void 0,
		accessToken: asString(value.accessToken) || void 0,
		messageFormat: parseMessageFormat(value.messageFormat) ?? defaults.messageFormat,
		reportSelfMessage: typeof value.reportSelfMessage === "boolean" ? value.reportSelfMessage : defaults.reportSelfMessage
	};
}
function parseHttpServer(value, defaults) {
	const port = asNumber(value.port, 0);
	if (port <= 0) return null;
	return clean({
		...parseBase(value, defaults),
		host: asString(value.host, "0.0.0.0"),
		port,
		path: asString(value.path, "/")
	});
}
function parseHttpClient(value, defaults) {
	const url = asString(value.url);
	if (!url) return null;
	const timeout = asNumber(value.timeoutMs, 0);
	return clean({
		...parseBase(value, defaults),
		url,
		timeoutMs: timeout > 0 ? timeout : void 0
	});
}
function parseWsServer(value, defaults) {
	const port = asNumber(value.port, 0);
	if (port <= 0) return null;
	return clean({
		...parseBase(value, defaults),
		host: asString(value.host, "0.0.0.0"),
		port,
		path: asString(value.path, "/"),
		role: asRole(value.role, "universal")
	});
}
function parseWsClient(value, defaults) {
	const url = asString(value.url);
	if (!url) return null;
	const reconnectIntervalMs = asNumber(value.reconnectIntervalMs, 5e3);
	return clean({
		...parseBase(value, defaults),
		url,
		role: asRole(value.role, "universal"),
		reconnectIntervalMs: Math.max(1e3, reconnectIntervalMs)
	});
}
function hasLegacyTopLevel(raw) {
	return Array.isArray(raw.httpServers) || Array.isArray(raw.httpPostEndpoints) || Array.isArray(raw.wsServers) || Array.isArray(raw.wsClients) || typeof raw.messageFormat === "string" || typeof raw.reportSelfMessage === "boolean";
}
function parseMessageFormat(value) {
	if (value === "array" || value === "string") return value;
}
function clean(obj) {
	for (const key of Object.keys(obj)) if (obj[key] === void 0) delete obj[key];
	return obj;
}
function asRole(value, fallback) {
	const text = asString(value, fallback);
	return text === "api" || text === "event" || text === "universal" ? text : fallback;
}
function asString(value, fallback = "") {
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	return fallback;
}
function asNumber(value, fallback = 0) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.max(0, Math.trunc(value));
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return Math.max(0, Math.trunc(n));
	}
	return fallback;
}
function tryLoadJson(filePath) {
	if (!fs.existsSync(filePath)) return null;
	try {
		const raw = fs.readFileSync(filePath, "utf8");
		const parsed = JSON.parse(raw);
		return isObject(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function saveJson(filePath, json) {
	fs.mkdirSync(path.dirname(filePath), { recursive: true });
	fs.writeFileSync(filePath, JSON.stringify(json, null, 2), "utf8");
}
function isObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
export { saveOneBotConfig as n, loadOneBotConfig as t };
