import { a as resolveReportOptions, i as pickDispatchJson, o as shapeEventForAdapter, r as buildDispatchPayload, t as HttpPostTransport } from "./http-post-transport-Cv2FtwNQ.js";
import { t as createLogger } from "./logger-eam4arGv.js";
import { t as loadOneBotConfig } from "./config-C5gFv5qF.js";
import { gunzipSync, gzipSync, inflateSync } from "zlib";
import { createHash } from "crypto";
import fs, { existsSync, promises } from "fs";
import path from "path";
import net from "net";
import crypto$1, { createHash as createHash$1 } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { createServer } from "http";
import { EventEmitter } from "node:events";
import { existsSync as existsSync$1 } from "node:fs";
import path$1 from "node:path";
import { URL as URL$1, fileURLToPath } from "node:url";
import zlib from "node:zlib";
import http from "node:http";
import https from "node:https";
import net$1 from "node:net";
import tls from "node:tls";
import { fileURLToPath as fileURLToPath$1 } from "url";
import os from "os";
import { EventEmitter as EventEmitter$1 } from "events";
//#region src/protocol/ntqq-handler.ts
var log$10 = createLogger("NTQQ");
var NtqqHandler = class {
	cmdHandlers = /* @__PURE__ */ new Map();
	cmdAllHandlers = [];
	registerCmd(cmd, cb) {
		const arr = this.cmdHandlers.get(cmd) ?? [];
		arr.push(cb);
		this.cmdHandlers.set(cmd, arr);
	}
	registerCmdAll(cb) {
		this.cmdAllHandlers.push(cb);
	}
	onHookPacket(pid, packet) {
		this.dispatchPacket({
			pid,
			uin: packet.uin,
			serviceCmd: packet.cmd,
			seqId: packet.seq,
			retCode: packet.error,
			fromClient: false,
			body: Buffer.from(packet.body)
		});
	}
	dispatchPacket(pkt) {
		const specific = this.cmdHandlers.get(pkt.serviceCmd);
		if (specific) for (const cb of specific) try {
			cb(pkt);
		} catch (e) {
			log$10.error("dispatch error for %s: %s", pkt.serviceCmd, e instanceof Error ? e.stack ?? e.message : String(e));
		}
		for (const cb of this.cmdAllHandlers) try {
			cb(pkt);
		} catch (e) {
			log$10.error("dispatch error for %s: %s", pkt.serviceCmd, e instanceof Error ? e.stack ?? e.message : String(e));
		}
	}
};
//#endregion
//#region src/protobuf/wire.ts
var WireType = /* @__PURE__ */ function(WireType) {
	WireType[WireType["Varint"] = 0] = "Varint";
	WireType[WireType["Fixed64"] = 1] = "Fixed64";
	WireType[WireType["LengthDelimited"] = 2] = "LengthDelimited";
	WireType[WireType["Fixed32"] = 5] = "Fixed32";
	return WireType;
}({});
function decodeVarint(data, offset) {
	let result = 0n;
	for (let i = 0; i < 10 && offset + i < data.length; i++) {
		result |= BigInt(data[offset + i] & 127) << BigInt(7 * i);
		if ((data[offset + i] & 128) === 0) return [result, i + 1];
	}
	return null;
}
function encodeVarint(value, out) {
	let v = typeof value === "number" ? BigInt(value >>> 0) : value;
	if (v < 0n) v = v + (1n << 64n);
	while (v >= 128n) {
		out.push(Number(v & 127n) | 128);
		v >>= 7n;
	}
	out.push(Number(v));
}
function encodeKey(fieldNumber, wireType, out) {
	encodeVarint(BigInt(fieldNumber) << 3n | BigInt(wireType), out);
}
function fieldAsString(f) {
	return new TextDecoder().decode(f.bytes);
}
var WireMessage = class WireMessage {
	fields_;
	constructor(fields) {
		this.fields_ = fields;
	}
	static decode(data) {
		if (!data || data.length === 0) return null;
		const fields = [];
		let pos = 0;
		while (pos < data.length) {
			const tagResult = decodeVarint(data, pos);
			if (!tagResult) break;
			const [tag, tagLen] = tagResult;
			pos += tagLen;
			const fieldNum = Number(tag >> 3n);
			const wireType = Number(tag & 7n);
			if (fieldNum === 0) break;
			const field = {
				fieldNumber: fieldNum,
				wireType,
				varint: 0n,
				bytes: new Uint8Array(0)
			};
			switch (wireType) {
				case WireType.Varint: {
					const valResult = decodeVarint(data, pos);
					if (!valResult) return null;
					field.varint = valResult[0];
					pos += valResult[1];
					break;
				}
				case WireType.Fixed64:
					if (pos + 8 > data.length) return null;
					field.varint = new DataView(data.buffer, data.byteOffset + pos, 8).getBigUint64(0, true);
					pos += 8;
					break;
				case WireType.Fixed32: {
					if (pos + 4 > data.length) return null;
					const dv = new DataView(data.buffer, data.byteOffset + pos, 4);
					field.varint = BigInt(dv.getUint32(0, true));
					pos += 4;
					break;
				}
				case WireType.LengthDelimited: {
					const lenResult = decodeVarint(data, pos);
					if (!lenResult) return null;
					const fieldLen = Number(lenResult[0]);
					pos += lenResult[1];
					if (pos + fieldLen > data.length) return null;
					field.bytes = data.subarray(pos, pos + fieldLen);
					pos += fieldLen;
					break;
				}
				default: return null;
			}
			fields.push(field);
		}
		return new WireMessage(fields);
	}
	field(num) {
		for (const f of this.fields_) if (f.fieldNumber === num) return f;
		return null;
	}
	has(num) {
		return this.field(num) !== null;
	}
	getVarint(num) {
		const f = this.field(num);
		if (!f || f.wireType !== WireType.Varint) return null;
		return f.varint;
	}
	getInt32(num) {
		const v = this.getVarint(num);
		return v !== null ? Number(BigInt.asIntN(32, v)) : null;
	}
	getUint32(num) {
		const v = this.getVarint(num);
		return v !== null ? Number(BigInt.asUintN(32, v)) : null;
	}
	getInt64(num) {
		const v = this.getVarint(num);
		return v !== null ? BigInt.asIntN(64, v) : null;
	}
	getUint64(num) {
		return this.getVarint(num);
	}
	getString(num) {
		const f = this.field(num);
		if (!f || f.wireType !== WireType.LengthDelimited) return null;
		return fieldAsString(f);
	}
	getBytes(num) {
		const f = this.field(num);
		if (!f || f.wireType !== WireType.LengthDelimited) return null;
		return f.bytes;
	}
	getMessage(num) {
		const f = this.field(num);
		if (!f || f.wireType !== WireType.LengthDelimited) return null;
		return WireMessage.decode(f.bytes);
	}
	fields(num) {
		return this.fields_.filter((f) => f.fieldNumber === num);
	}
	getRepeatedVarint(num) {
		const result = [];
		for (const f of this.fields_) {
			if (f.fieldNumber !== num) continue;
			if (f.wireType === WireType.Varint) result.push(f.varint);
			else if (f.wireType === WireType.LengthDelimited) {
				let pos = 0;
				while (pos < f.bytes.length) {
					const r = decodeVarint(f.bytes, pos);
					if (!r) break;
					result.push(r[0]);
					pos += r[1];
				}
			}
		}
		return result;
	}
	getRepeatedString(num) {
		const result = [];
		const decoder = new TextDecoder();
		for (const f of this.fields_) if (f.fieldNumber === num && f.wireType === WireType.LengthDelimited) result.push(decoder.decode(f.bytes));
		return result;
	}
	getRepeatedMessage(num) {
		const result = [];
		for (const f of this.fields_) if (f.fieldNumber === num && f.wireType === WireType.LengthDelimited) {
			const sub = WireMessage.decode(f.bytes);
			if (sub) result.push(sub);
		}
		return result;
	}
	get allFields() {
		return this.fields_;
	}
	get empty() {
		return this.fields_.length === 0;
	}
};
//#endregion
//#region src/protobuf/decode.ts
function protoDecode(data, schema) {
	const wire = data instanceof WireMessage ? data : WireMessage.decode(data);
	if (!wire) return null;
	const result = {};
	for (const [key, def] of Object.entries(schema)) switch (def.type) {
		case "bool": {
			const v = wire.getVarint(def.field);
			if (v !== null) result[key] = v !== 0n;
			break;
		}
		case "int32": {
			const v = wire.getInt32(def.field);
			if (v !== null) result[key] = v;
			break;
		}
		case "uint32": {
			const v = wire.getUint32(def.field);
			if (v !== null) result[key] = v;
			break;
		}
		case "int64": {
			const v = wire.getInt64(def.field);
			if (v !== null) result[key] = v;
			break;
		}
		case "uint64": {
			const v = wire.getUint64(def.field);
			if (v !== null) result[key] = v;
			break;
		}
		case "string": {
			const v = wire.getString(def.field);
			if (v !== null) result[key] = v;
			break;
		}
		case "bytes": {
			const v = wire.getBytes(def.field);
			if (v !== null) result[key] = v;
			break;
		}
		case "message": {
			const sub = wire.getMessage(def.field);
			if (sub && def.schema) result[key] = protoDecode(sub, def.schema);
			break;
		}
		case "repeated_varint":
			result[key] = wire.getRepeatedVarint(def.field).map((v) => Number(BigInt.asIntN(32, v)));
			break;
		case "repeated_uint32":
			result[key] = wire.getRepeatedVarint(def.field).map((v) => Number(BigInt.asUintN(32, v)));
			break;
		case "repeated_string":
			result[key] = wire.getRepeatedString(def.field);
			break;
		case "repeated_bytes":
			result[key] = wire.fields(def.field).filter((f) => f.wireType === WireType.LengthDelimited).map((f) => f.bytes);
			break;
		case "repeated_message":
			if (!def.schema) {
				result[key] = [];
				break;
			}
			result[key] = wire.getRepeatedMessage(def.field).map((m) => protoDecode(m, def.schema)).filter((m) => m !== null);
			break;
	}
	return result;
}
function protoEncode(obj, schema) {
	const out = [];
	const record = obj;
	for (const [key, def] of Object.entries(schema)) {
		const val = record[key];
		if (val === void 0 || val === null) continue;
		switch (def.type) {
			case "bool":
				encodeKey(def.field, WireType.Varint, out);
				encodeVarint(val ? 1 : 0, out);
				break;
			case "int32":
			case "uint32":
				encodeKey(def.field, WireType.Varint, out);
				encodeVarint(val, out);
				break;
			case "int64":
			case "uint64":
				encodeKey(def.field, WireType.Varint, out);
				encodeVarint(val, out);
				break;
			case "string": {
				const encoded = new TextEncoder().encode(val);
				encodeKey(def.field, WireType.LengthDelimited, out);
				encodeVarint(encoded.length, out);
				for (const b of encoded) out.push(b);
				break;
			}
			case "bytes": {
				const buf = val;
				encodeKey(def.field, WireType.LengthDelimited, out);
				encodeVarint(buf.length, out);
				for (const b of buf) out.push(b);
				break;
			}
			case "message": {
				if (!def.schema) break;
				const nested = protoEncode(val, def.schema);
				encodeKey(def.field, WireType.LengthDelimited, out);
				encodeVarint(nested.length, out);
				for (const b of nested) out.push(b);
				break;
			}
			case "repeated_varint":
			case "repeated_uint32":
				for (const v of val) {
					encodeKey(def.field, WireType.Varint, out);
					encodeVarint(v, out);
				}
				break;
			case "repeated_string": {
				const encoder = new TextEncoder();
				for (const s of val) {
					const encoded = encoder.encode(s);
					encodeKey(def.field, WireType.LengthDelimited, out);
					encodeVarint(encoded.length, out);
					for (const b of encoded) out.push(b);
				}
				break;
			}
			case "repeated_bytes":
				for (const buf of val) {
					encodeKey(def.field, WireType.LengthDelimited, out);
					encodeVarint(buf.length, out);
					for (const b of buf) out.push(b);
				}
				break;
			case "repeated_message":
				if (!def.schema) break;
				for (const item of val) {
					const nested = protoEncode(item, def.schema);
					encodeKey(def.field, WireType.LengthDelimited, out);
					encodeVarint(nested.length, out);
					for (const b of nested) out.push(b);
				}
				break;
		}
	}
	return new Uint8Array(out);
}
//#endregion
//#region src/bridge/proto/element.ts
var CustomFacePbReserveSchema = {
	subType: {
		field: 1,
		type: "int32"
	},
	summary: {
		field: 9,
		type: "string"
	}
};
var NotOnlineImagePbReserveSchema = {
	subType: {
		field: 1,
		type: "int32"
	},
	field3: {
		field: 3,
		type: "int32"
	},
	field4: {
		field: 4,
		type: "int32"
	},
	summary: {
		field: 8,
		type: "string"
	},
	field10: {
		field: 10,
		type: "int32"
	},
	field20: {
		field: 20,
		type: "message",
		schema: {
			field1: {
				field: 1,
				type: "int32"
			},
			field2: {
				field: 2,
				type: "string"
			},
			field3: {
				field: 3,
				type: "int32"
			},
			field4: {
				field: 4,
				type: "int32"
			},
			field5: {
				field: 5,
				type: "int32"
			},
			field7: {
				field: 7,
				type: "string"
			}
		}
	},
	url: {
		field: 30,
		type: "string"
	},
	md5Str: {
		field: 31,
		type: "string"
	}
};
var TextElemSchema = {
	str: {
		field: 1,
		type: "string"
	},
	link: {
		field: 2,
		type: "string"
	},
	attr6Buf: {
		field: 3,
		type: "bytes"
	},
	attr7Buf: {
		field: 4,
		type: "bytes"
	},
	buf: {
		field: 11,
		type: "bytes"
	},
	pbReserve: {
		field: 12,
		type: "bytes"
	}
};
var FaceElemSchema = {
	index: {
		field: 1,
		type: "int32"
	},
	oldData: {
		field: 2,
		type: "bytes"
	},
	buf: {
		field: 11,
		type: "bytes"
	}
};
var OnlineImageSchema = {
	guid: {
		field: 1,
		type: "bytes"
	},
	filePath: {
		field: 2,
		type: "bytes"
	},
	oldVerSendFile: {
		field: 3,
		type: "bytes"
	}
};
var NotOnlineImageSchema = {
	filePath: {
		field: 1,
		type: "string"
	},
	fileLen: {
		field: 2,
		type: "uint32"
	},
	downloadPath: {
		field: 3,
		type: "string"
	},
	oldVerSendFile: {
		field: 4,
		type: "bytes"
	},
	imgType: {
		field: 5,
		type: "int32"
	},
	previewsImage: {
		field: 6,
		type: "bytes"
	},
	picMd5: {
		field: 7,
		type: "bytes"
	},
	picHeight: {
		field: 8,
		type: "uint32"
	},
	picWidth: {
		field: 9,
		type: "uint32"
	},
	resId: {
		field: 10,
		type: "string"
	},
	flag: {
		field: 11,
		type: "bytes"
	},
	thumbUrl: {
		field: 12,
		type: "string"
	},
	original: {
		field: 13,
		type: "int32"
	},
	bigUrl: {
		field: 14,
		type: "string"
	},
	origUrl: {
		field: 15,
		type: "string"
	},
	bizType: {
		field: 16,
		type: "int32"
	},
	result: {
		field: 17,
		type: "int32"
	},
	index: {
		field: 18,
		type: "int32"
	},
	opFaceBuf: {
		field: 19,
		type: "bytes"
	},
	oldPicMd5: {
		field: 20,
		type: "bool"
	},
	thumbWidth: {
		field: 21,
		type: "int32"
	},
	thumbHeight: {
		field: 22,
		type: "int32"
	},
	fileId: {
		field: 23,
		type: "int32"
	},
	showLen: {
		field: 24,
		type: "uint32"
	},
	downloadLen: {
		field: 25,
		type: "uint32"
	},
	x400Url: {
		field: 26,
		type: "string"
	},
	x400Width: {
		field: 27,
		type: "int32"
	},
	x400Height: {
		field: 28,
		type: "int32"
	},
	pbRes: {
		field: 29,
		type: "message",
		schema: NotOnlineImagePbReserveSchema
	}
};
var ElemSchema = {
	text: {
		field: 1,
		type: "message",
		schema: TextElemSchema
	},
	face: {
		field: 2,
		type: "message",
		schema: FaceElemSchema
	},
	onlineImage: {
		field: 3,
		type: "message",
		schema: OnlineImageSchema
	},
	notOnlineImage: {
		field: 4,
		type: "message",
		schema: NotOnlineImageSchema
	},
	transElem: {
		field: 5,
		type: "message",
		schema: {
			elemType: {
				field: 1,
				type: "int32"
			},
			elemValue: {
				field: 2,
				type: "bytes"
			}
		}
	},
	marketFace: {
		field: 6,
		type: "message",
		schema: {
			faceName: {
				field: 1,
				type: "string"
			},
			itemType: {
				field: 2,
				type: "uint32"
			},
			faceInfo: {
				field: 3,
				type: "uint32"
			},
			faceId: {
				field: 4,
				type: "bytes"
			},
			tabId: {
				field: 5,
				type: "uint32"
			},
			subType: {
				field: 6,
				type: "uint32"
			},
			key: {
				field: 7,
				type: "bytes"
			},
			param: {
				field: 8,
				type: "bytes"
			},
			mediaType: {
				field: 9,
				type: "uint32"
			},
			imageWidth: {
				field: 10,
				type: "uint32"
			},
			imageHeight: {
				field: 11,
				type: "uint32"
			},
			mobileParam: {
				field: 12,
				type: "bytes"
			},
			pbReserve: {
				field: 13,
				type: "bytes"
			}
		}
	},
	customFace: {
		field: 8,
		type: "message",
		schema: {
			guid: {
				field: 1,
				type: "bytes"
			},
			filePath: {
				field: 2,
				type: "string"
			},
			shortcut: {
				field: 3,
				type: "string"
			},
			buffer: {
				field: 4,
				type: "bytes"
			},
			flag: {
				field: 5,
				type: "bytes"
			},
			oldData: {
				field: 6,
				type: "bytes"
			},
			fileId: {
				field: 7,
				type: "uint32"
			},
			serverIp: {
				field: 8,
				type: "int32"
			},
			serverPort: {
				field: 9,
				type: "int32"
			},
			fileType: {
				field: 10,
				type: "int32"
			},
			signature: {
				field: 11,
				type: "bytes"
			},
			useful: {
				field: 12,
				type: "int32"
			},
			md5: {
				field: 13,
				type: "bytes"
			},
			thumbUrl: {
				field: 14,
				type: "string"
			},
			bigUrl: {
				field: 15,
				type: "string"
			},
			origUrl: {
				field: 16,
				type: "string"
			},
			bizType: {
				field: 17,
				type: "int32"
			},
			repeatIndex: {
				field: 18,
				type: "int32"
			},
			repeatImage: {
				field: 19,
				type: "int32"
			},
			imageType: {
				field: 20,
				type: "int32"
			},
			index: {
				field: 21,
				type: "int32"
			},
			width: {
				field: 22,
				type: "int32"
			},
			height: {
				field: 23,
				type: "int32"
			},
			source: {
				field: 24,
				type: "int32"
			},
			size: {
				field: 25,
				type: "uint32"
			},
			origin: {
				field: 26,
				type: "int32"
			},
			thumbWidth: {
				field: 27,
				type: "int32"
			},
			thumbHeight: {
				field: 28,
				type: "int32"
			},
			showLen: {
				field: 29,
				type: "int32"
			},
			downloadLen: {
				field: 30,
				type: "int32"
			},
			x400Url: {
				field: 31,
				type: "string"
			},
			x400Width: {
				field: 32,
				type: "int32"
			},
			x400Height: {
				field: 33,
				type: "int32"
			},
			pbRes: {
				field: 34,
				type: "message",
				schema: CustomFacePbReserveSchema
			}
		}
	},
	richMsg: {
		field: 12,
		type: "message",
		schema: {
			template1: {
				field: 1,
				type: "bytes"
			},
			serviceId: {
				field: 2,
				type: "int32"
			},
			msgResId: {
				field: 3,
				type: "bytes"
			},
			rand: {
				field: 4,
				type: "int32"
			},
			seq: {
				field: 5,
				type: "uint32"
			}
		}
	},
	groupFile: {
		field: 13,
		type: "message",
		schema: {
			filename: {
				field: 1,
				type: "string"
			},
			fileSize: {
				field: 2,
				type: "uint64"
			},
			fileId: {
				field: 3,
				type: "string"
			},
			batchId: {
				field: 4,
				type: "string"
			},
			fileKey: {
				field: 5,
				type: "string"
			},
			mark: {
				field: 6,
				type: "bytes"
			},
			sequence: {
				field: 7,
				type: "uint64"
			},
			batchItemId: {
				field: 8,
				type: "bytes"
			},
			feedMsgTime: {
				field: 9,
				type: "int32"
			},
			pbReserve: {
				field: 10,
				type: "bytes"
			}
		}
	},
	extraInfo: {
		field: 16,
		type: "message",
		schema: {
			nick: {
				field: 1,
				type: "bytes"
			},
			groupCard: {
				field: 2,
				type: "bytes"
			},
			level: {
				field: 3,
				type: "int32"
			},
			flags: {
				field: 4,
				type: "int32"
			},
			groupMask: {
				field: 5,
				type: "int32"
			},
			msgTailId: {
				field: 6,
				type: "int32"
			},
			senderTitle: {
				field: 7,
				type: "bytes"
			},
			apnsTips: {
				field: 8,
				type: "bytes"
			},
			uin: {
				field: 9,
				type: "uint64"
			},
			msgStateFlag: {
				field: 10,
				type: "int32"
			},
			apnsSoundType: {
				field: 11,
				type: "int32"
			},
			newGroupFlag: {
				field: 12,
				type: "int32"
			}
		}
	},
	videoFile: {
		field: 19,
		type: "message",
		schema: {
			fileUuid: {
				field: 1,
				type: "string"
			},
			fileMd5: {
				field: 2,
				type: "bytes"
			},
			fileName: {
				field: 3,
				type: "string"
			},
			fileFormat: {
				field: 4,
				type: "int32"
			},
			fileTime: {
				field: 5,
				type: "int32"
			},
			fileSize: {
				field: 6,
				type: "int32"
			},
			thumbWidth: {
				field: 7,
				type: "int32"
			},
			thumbHeight: {
				field: 8,
				type: "int32"
			},
			thumbFileMd5: {
				field: 9,
				type: "bytes"
			},
			source: {
				field: 10,
				type: "bytes"
			},
			thumbFileSize: {
				field: 11,
				type: "int32"
			},
			busiType: {
				field: 12,
				type: "int32"
			},
			fromChatType: {
				field: 13,
				type: "int32"
			},
			toChatType: {
				field: 14,
				type: "int32"
			},
			supportProgressive: {
				field: 15,
				type: "bool"
			},
			fileWidth: {
				field: 16,
				type: "int32"
			},
			fileHeight: {
				field: 17,
				type: "int32"
			},
			subBusiType: {
				field: 18,
				type: "int32"
			},
			videoAttr: {
				field: 19,
				type: "int32"
			},
			pbReserve: {
				field: 24,
				type: "bytes"
			}
		}
	},
	generalFlags: {
		field: 37,
		type: "message",
		schema: {
			bubbleDiyTextId: {
				field: 1,
				type: "int32"
			},
			groupFlagNew: {
				field: 2,
				type: "int32"
			},
			uin: {
				field: 3,
				type: "uint64"
			},
			longTextFlag: {
				field: 6,
				type: "int32"
			},
			longTextResId: {
				field: 7,
				type: "string"
			}
		}
	},
	srcMsg: {
		field: 45,
		type: "message",
		schema: {
			origSeqs: {
				field: 1,
				type: "repeated_uint32"
			},
			senderUin: {
				field: 2,
				type: "uint64"
			},
			time: {
				field: 3,
				type: "int32"
			},
			flag: {
				field: 4,
				type: "int32"
			},
			elemsRaw: {
				field: 5,
				type: "repeated_bytes"
			},
			type: {
				field: 6,
				type: "int32"
			},
			richMsg: {
				field: 7,
				type: "bytes"
			},
			pbReserve: {
				field: 8,
				type: "bytes"
			},
			sourceMsg: {
				field: 9,
				type: "bytes"
			},
			toUin: {
				field: 10,
				type: "uint64"
			},
			troopName: {
				field: 11,
				type: "bytes"
			}
		}
	},
	lightApp: {
		field: 51,
		type: "message",
		schema: {
			data: {
				field: 1,
				type: "bytes"
			},
			msgResid: {
				field: 2,
				type: "bytes"
			}
		}
	},
	commonElem: {
		field: 53,
		type: "message",
		schema: {
			serviceType: {
				field: 1,
				type: "int32"
			},
			pbElem: {
				field: 2,
				type: "bytes"
			},
			businessType: {
				field: 3,
				type: "uint32"
			}
		}
	}
};
var MentionExtraSchema = {
	type: {
		field: 3,
		type: "int32"
	},
	uin: {
		field: 4,
		type: "uint32"
	},
	field5: {
		field: 5,
		type: "int32"
	},
	uid: {
		field: 9,
		type: "string"
	}
};
var QFaceExtraSchema = {
	packId: {
		field: 1,
		type: "string"
	},
	stickerId: {
		field: 2,
		type: "string"
	},
	qsid: {
		field: 3,
		type: "int32"
	},
	sourceType: {
		field: 4,
		type: "int32"
	},
	stickerType: {
		field: 5,
		type: "int32"
	},
	resultId: {
		field: 6,
		type: "string"
	},
	text: {
		field: 7,
		type: "string"
	},
	randomType: {
		field: 9,
		type: "int32"
	}
};
var QSmallFaceExtraSchema = {
	faceId: {
		field: 1,
		type: "uint32"
	},
	preview: {
		field: 2,
		type: "string"
	},
	preview2: {
		field: 3,
		type: "string"
	}
};
var IndexNodeSchema = {
	info: {
		field: 1,
		type: "message",
		schema: {
			fileSize: {
				field: 1,
				type: "uint32"
			},
			fileHash: {
				field: 2,
				type: "string"
			},
			fileSha1: {
				field: 3,
				type: "string"
			},
			fileName: {
				field: 4,
				type: "string"
			},
			type: {
				field: 5,
				type: "message",
				schema: {
					type: {
						field: 1,
						type: "uint32"
					},
					picFormat: {
						field: 2,
						type: "uint32"
					},
					videoFormat: {
						field: 3,
						type: "uint32"
					},
					voiceFormat: {
						field: 4,
						type: "uint32"
					}
				}
			},
			width: {
				field: 6,
				type: "uint32"
			},
			height: {
				field: 7,
				type: "uint32"
			},
			time: {
				field: 8,
				type: "uint32"
			},
			original: {
				field: 9,
				type: "uint32"
			}
		}
	},
	fileUuid: {
		field: 2,
		type: "string"
	},
	storeId: {
		field: 3,
		type: "uint32"
	},
	uploadTime: {
		field: 4,
		type: "uint32"
	},
	ttl: {
		field: 5,
		type: "uint32"
	},
	subType: {
		field: 6,
		type: "uint32"
	}
};
var PictureInfoSchema = {
	urlPath: {
		field: 1,
		type: "string"
	},
	ext: {
		field: 2,
		type: "message",
		schema: {
			originalParameter: {
				field: 1,
				type: "string"
			},
			bigParameter: {
				field: 2,
				type: "string"
			},
			thumbParameter: {
				field: 3,
				type: "string"
			}
		}
	},
	domain: {
		field: 3,
		type: "string"
	}
};
var PicExtBizInfoSchema = {
	bizType: {
		field: 1,
		type: "uint32"
	},
	textSummary: {
		field: 2,
		type: "string"
	},
	bytesPbReserveC2c: {
		field: 11,
		type: "bytes"
	},
	extData: {
		field: 12,
		type: "message",
		schema: {
			subType: {
				field: 1,
				type: "uint32"
			},
			textSummary: {
				field: 9,
				type: "string"
			}
		}
	},
	fromScene: {
		field: 1001,
		type: "uint32"
	},
	toScene: {
		field: 1002,
		type: "uint32"
	},
	oldFileId: {
		field: 1003,
		type: "uint32"
	}
};
var VideoExtBizInfoSchema = {
	fromScene: {
		field: 1,
		type: "uint32"
	},
	toScene: {
		field: 2,
		type: "uint32"
	},
	bytesPbReserve: {
		field: 3,
		type: "bytes"
	}
};
var PttExtBizInfoSchema = {
	srcUin: {
		field: 1,
		type: "uint64"
	},
	pttScene: {
		field: 2,
		type: "uint32"
	},
	pttType: {
		field: 3,
		type: "uint32"
	},
	changeVoice: {
		field: 4,
		type: "uint32"
	},
	waveform: {
		field: 5,
		type: "bytes"
	},
	autoConvertText: {
		field: 6,
		type: "uint32"
	},
	bytesReserve: {
		field: 11,
		type: "bytes"
	},
	bytesPbReserve: {
		field: 12,
		type: "bytes"
	},
	bytesGeneralFlags: {
		field: 13,
		type: "bytes"
	}
};
var ExtBizInfoSchema = {
	pic: {
		field: 1,
		type: "message",
		schema: PicExtBizInfoSchema
	},
	video: {
		field: 2,
		type: "message",
		schema: VideoExtBizInfoSchema
	},
	ptt: {
		field: 3,
		type: "message",
		schema: PttExtBizInfoSchema
	},
	busiType: {
		field: 10,
		type: "uint32"
	}
};
var HashSumSchema = {
	bytesPbReserveC2c: {
		field: 201,
		type: "message",
		schema: { friendUid: {
			field: 2,
			type: "string"
		} }
	},
	troopSource: {
		field: 202,
		type: "message",
		schema: { groupUin: {
			field: 1,
			type: "uint32"
		} }
	}
};
var MsgInfoSchema = {
	msgInfoBody: {
		field: 1,
		type: "repeated_message",
		schema: {
			index: {
				field: 1,
				type: "message",
				schema: IndexNodeSchema
			},
			picture: {
				field: 2,
				type: "message",
				schema: PictureInfoSchema
			},
			fileExist: {
				field: 5,
				type: "bool"
			},
			hashSum: {
				field: 6,
				type: "message",
				schema: HashSumSchema
			}
		}
	},
	extBizInfo: {
		field: 2,
		type: "message",
		schema: ExtBizInfoSchema
	}
};
var GroupFileExtraSchema = { inner: {
	field: 7,
	type: "message",
	schema: { info: {
		field: 2,
		type: "message",
		schema: {
			busId: {
				field: 1,
				type: "uint32"
			},
			fileId: {
				field: 2,
				type: "string"
			},
			fileSize: {
				field: 3,
				type: "uint64"
			},
			fileName: {
				field: 4,
				type: "string"
			},
			fileSha: {
				field: 5,
				type: "bytes"
			},
			extInfoString: {
				field: 6,
				type: "string"
			},
			fileMd5: {
				field: 7,
				type: "bytes"
			}
		}
	} }
} };
var ResponseHeadSchema = {
	fromUin: {
		field: 1,
		type: "uint32"
	},
	fromUid: {
		field: 2,
		type: "string"
	},
	type: {
		field: 3,
		type: "uint32"
	},
	sigMap: {
		field: 4,
		type: "uint32"
	},
	toUin: {
		field: 5,
		type: "uint32"
	},
	toUid: {
		field: 6,
		type: "string"
	},
	forward: {
		field: 7,
		type: "message",
		schema: { friendName: {
			field: 6,
			type: "string"
		} }
	},
	grp: {
		field: 8,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			memberName: {
				field: 2,
				type: "string"
			},
			groupName: {
				field: 4,
				type: "string"
			}
		}
	}
};
var ContentHeadSchema = {
	msgType: {
		field: 1,
		type: "uint32"
	},
	subType: {
		field: 2,
		type: "uint32"
	},
	divSeq: {
		field: 3,
		type: "uint32"
	},
	msgId: {
		field: 4,
		type: "uint32"
	},
	sequence: {
		field: 5,
		type: "uint32"
	},
	timestamp: {
		field: 6,
		type: "uint32"
	},
	field7: {
		field: 7,
		type: "uint64"
	},
	newId: {
		field: 12,
		type: "uint64"
	}
};
var MessageBodySchema = {
	richText: {
		field: 1,
		type: "message",
		schema: {
			elems: {
				field: 2,
				type: "repeated_message",
				schema: ElemSchema
			},
			notOnlineFile: {
				field: 3,
				type: "message",
				schema: {
					fileType: {
						field: 1,
						type: "uint32"
					},
					fileUuid: {
						field: 3,
						type: "string"
					},
					fileMd5: {
						field: 4,
						type: "bytes"
					},
					fileName: {
						field: 5,
						type: "string"
					},
					fileSize: {
						field: 6,
						type: "uint64"
					},
					fileHash: {
						field: 57,
						type: "string"
					}
				}
			},
			ptt: {
				field: 4,
				type: "message",
				schema: {
					fileType: {
						field: 1,
						type: "uint32"
					},
					fileId: {
						field: 2,
						type: "uint64"
					},
					fileUuid: {
						field: 3,
						type: "bytes"
					},
					fileMd5: {
						field: 4,
						type: "bytes"
					},
					fileName: {
						field: 5,
						type: "string"
					},
					fileSize: {
						field: 6,
						type: "uint32"
					},
					groupFileKey: {
						field: 10,
						type: "string"
					},
					fileKey: {
						field: 14,
						type: "bytes"
					},
					time: {
						field: 19,
						type: "uint32"
					},
					format: {
						field: 29,
						type: "uint32"
					}
				}
			}
		}
	},
	msgContent: {
		field: 2,
		type: "bytes"
	}
};
var FileExtraSchema = { file: {
	field: 1,
	type: "message",
	schema: {
		fileSize: {
			field: 1,
			type: "uint64"
		},
		fileName: {
			field: 2,
			type: "string"
		},
		fileMd5: {
			field: 3,
			type: "bytes"
		},
		fileUuid: {
			field: 4,
			type: "string"
		},
		fileHash: {
			field: 5,
			type: "string"
		}
	}
} };
var PushMsgBodySchema = {
	responseHead: {
		field: 1,
		type: "message",
		schema: ResponseHeadSchema
	},
	contentHead: {
		field: 2,
		type: "message",
		schema: ContentHeadSchema
	},
	body: {
		field: 3,
		type: "message",
		schema: MessageBodySchema
	}
};
var PushMsgSchema = {
	message: {
		field: 1,
		type: "message",
		schema: PushMsgBodySchema
	},
	status: {
		field: 3,
		type: "int32"
	}
};
var OperatorInfoSchema = { operatorField: {
	field: 1,
	type: "message",
	schema: {
		uid: {
			field: 1,
			type: "string"
		},
		field2: {
			field: 2,
			type: "uint32"
		},
		field3: {
			field: 3,
			type: "bytes"
		},
		field4: {
			field: 4,
			type: "uint32"
		},
		field5: {
			field: 5,
			type: "bytes"
		}
	}
} };
var GroupChangeSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	flag: {
		field: 2,
		type: "uint32"
	},
	memberUid: {
		field: 3,
		type: "string"
	},
	decreaseType: {
		field: 4,
		type: "uint32"
	},
	operatorBytes: {
		field: 5,
		type: "bytes"
	},
	increaseType: {
		field: 6,
		type: "uint32"
	},
	field7: {
		field: 7,
		type: "bytes"
	}
};
var GroupAdminExtraSchema = {
	adminUid: {
		field: 1,
		type: "string"
	},
	isPromote: {
		field: 2,
		type: "bool"
	}
};
var GroupAdminSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	flag: {
		field: 2,
		type: "uint32"
	},
	isPromote: {
		field: 3,
		type: "bool"
	},
	body: {
		field: 4,
		type: "message",
		schema: {
			extraDisable: {
				field: 1,
				type: "message",
				schema: GroupAdminExtraSchema
			},
			extraEnable: {
				field: 2,
				type: "message",
				schema: GroupAdminExtraSchema
			}
		}
	}
};
var GroupInvitationSchema = {
	cmd: {
		field: 1,
		type: "int32"
	},
	info: {
		field: 2,
		type: "message",
		schema: { inner: {
			field: 1,
			type: "message",
			schema: {
				groupUin: {
					field: 1,
					type: "uint32"
				},
				field2: {
					field: 2,
					type: "uint32"
				},
				field3: {
					field: 3,
					type: "uint32"
				},
				field4: {
					field: 4,
					type: "uint32"
				},
				targetUid: {
					field: 5,
					type: "string"
				},
				invitorUid: {
					field: 6,
					type: "string"
				},
				field7: {
					field: 7,
					type: "uint32"
				},
				field9: {
					field: 9,
					type: "uint32"
				},
				field10: {
					field: 10,
					type: "bytes"
				},
				field11: {
					field: 11,
					type: "uint32"
				},
				field12: {
					field: 12,
					type: "string"
				}
			}
		} }
	}
};
var GroupInviteSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	},
	field3: {
		field: 3,
		type: "uint32"
	},
	field4: {
		field: 4,
		type: "uint32"
	},
	invitorUid: {
		field: 5,
		type: "string"
	},
	hashes: {
		field: 6,
		type: "bytes"
	}
};
var GroupJoinSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	},
	targetUid: {
		field: 3,
		type: "string"
	},
	field4: {
		field: 4,
		type: "uint32"
	},
	field6: {
		field: 6,
		type: "uint32"
	},
	field7: {
		field: 7,
		type: "string"
	},
	field8: {
		field: 8,
		type: "uint32"
	},
	field9: {
		field: 9,
		type: "bytes"
	}
};
var FriendRequestSchema = { info: {
	field: 1,
	type: "message",
	schema: {
		targetUid: {
			field: 1,
			type: "string"
		},
		sourceUid: {
			field: 2,
			type: "string"
		},
		newSource: {
			field: 5,
			type: "string"
		},
		message: {
			field: 10,
			type: "string"
		},
		source: {
			field: 11,
			type: "string"
		}
	}
} };
var FriendRecallSchema = {
	info: {
		field: 1,
		type: "message",
		schema: {
			fromUid: {
				field: 1,
				type: "string"
			},
			toUid: {
				field: 2,
				type: "string"
			},
			clientSequence: {
				field: 3,
				type: "uint32"
			},
			newId: {
				field: 4,
				type: "uint64"
			},
			time: {
				field: 5,
				type: "uint32"
			},
			random: {
				field: 6,
				type: "uint32"
			},
			pkgNum: {
				field: 7,
				type: "uint32"
			},
			pkgIndex: {
				field: 8,
				type: "uint32"
			},
			divSeq: {
				field: 9,
				type: "uint32"
			},
			tipInfo: {
				field: 13,
				type: "message",
				schema: { tip: {
					field: 2,
					type: "string"
				} }
			}
		}
	},
	instId: {
		field: 2,
		type: "uint32"
	},
	appId: {
		field: 3,
		type: "uint32"
	},
	longMessageFlag: {
		field: 4,
		type: "uint32"
	},
	reserved: {
		field: 5,
		type: "bytes"
	}
};
var GroupMuteSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	subType: {
		field: 2,
		type: "uint32"
	},
	field3: {
		field: 3,
		type: "uint32"
	},
	operatorUid: {
		field: 4,
		type: "string"
	},
	data: {
		field: 5,
		type: "message",
		schema: {
			timestamp: {
				field: 1,
				type: "uint32"
			},
			type: {
				field: 2,
				type: "uint32"
			},
			state: {
				field: 3,
				type: "message",
				schema: {
					targetUid: {
						field: 1,
						type: "string"
					},
					duration: {
						field: 2,
						type: "uint32"
					}
				}
			}
		}
	}
};
var GroupRecallSchema = {
	operatorUid: {
		field: 1,
		type: "string"
	},
	recallMessages: {
		field: 3,
		type: "repeated_message",
		schema: {
			sequence: {
				field: 1,
				type: "uint32"
			},
			time: {
				field: 2,
				type: "uint32"
			},
			random: {
				field: 3,
				type: "uint32"
			},
			type: {
				field: 4,
				type: "uint32"
			},
			flag: {
				field: 5,
				type: "uint32"
			},
			authorUid: {
				field: 6,
				type: "string"
			}
		}
	},
	userDef: {
		field: 5,
		type: "bytes"
	},
	groupType: {
		field: 6,
		type: "int32"
	},
	opType: {
		field: 7,
		type: "int32"
	},
	tipInfo: {
		field: 9,
		type: "message",
		schema: { tip: {
			field: 2,
			type: "string"
		} }
	}
};
var GeneralGrayTipInfoSchema = {
	busiType: {
		field: 1,
		type: "uint64"
	},
	busiId: {
		field: 2,
		type: "uint64"
	},
	ctrlFlag: {
		field: 3,
		type: "uint32"
	},
	c2cType: {
		field: 4,
		type: "uint32"
	},
	serviceType: {
		field: 5,
		type: "uint32"
	},
	templId: {
		field: 6,
		type: "uint64"
	},
	msgTemplParam: {
		field: 7,
		type: "repeated_message",
		schema: {
			name: {
				field: 1,
				type: "string"
			},
			value: {
				field: 2,
				type: "string"
			}
		}
	},
	content: {
		field: 8,
		type: "string"
	}
};
var NotifyMessageBodySchema = {
	type: {
		field: 1,
		type: "uint32"
	},
	groupUin: {
		field: 4,
		type: "uint32"
	},
	eventParam: {
		field: 5,
		type: "bytes"
	},
	recall: {
		field: 11,
		type: "message",
		schema: GroupRecallSchema
	},
	field13: {
		field: 13,
		type: "uint32"
	},
	operatorUid: {
		field: 21,
		type: "string"
	},
	generalGrayTip: {
		field: 26,
		type: "message",
		schema: GeneralGrayTipInfoSchema
	},
	essenceMessage: {
		field: 33,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			msgSequence: {
				field: 2,
				type: "uint32"
			},
			random: {
				field: 3,
				type: "uint32"
			},
			setFlag: {
				field: 4,
				type: "uint32"
			},
			memberUin: {
				field: 5,
				type: "uint32"
			},
			operatorUin: {
				field: 6,
				type: "uint32"
			},
			timestamp: {
				field: 7,
				type: "uint32"
			},
			msgSequence2: {
				field: 8,
				type: "uint32"
			},
			operatorNickname: {
				field: 9,
				type: "string"
			},
			memberNickname: {
				field: 10,
				type: "string"
			},
			setFlag2: {
				field: 11,
				type: "uint32"
			}
		}
	},
	msgSequence: {
		field: 37,
		type: "uint32"
	},
	field39: {
		field: 39,
		type: "uint32"
	}
};
//#endregion
//#region src/bridge/handlers/msg-push-handler.ts
var PkgType = /* @__PURE__ */ function(PkgType) {
	PkgType[PkgType["ForwardFakePrivateMessage"] = 9] = "ForwardFakePrivateMessage";
	PkgType[PkgType["PrivateMessage"] = 166] = "PrivateMessage";
	PkgType[PkgType["GroupMessage"] = 82] = "GroupMessage";
	PkgType[PkgType["TempMessage"] = 141] = "TempMessage";
	PkgType[PkgType["Event0x210"] = 528] = "Event0x210";
	PkgType[PkgType["Event0x2DC"] = 732] = "Event0x2DC";
	PkgType[PkgType["PrivateRecordMessage"] = 208] = "PrivateRecordMessage";
	PkgType[PkgType["PrivateFileMessage"] = 529] = "PrivateFileMessage";
	PkgType[PkgType["GroupRequestInvitationNotice"] = 525] = "GroupRequestInvitationNotice";
	PkgType[PkgType["GroupRequestJoinNotice"] = 84] = "GroupRequestJoinNotice";
	PkgType[PkgType["GroupInviteNotice"] = 87] = "GroupInviteNotice";
	PkgType[PkgType["GroupAdminChangedNotice"] = 44] = "GroupAdminChangedNotice";
	PkgType[PkgType["GroupMemberIncreaseNotice"] = 33] = "GroupMemberIncreaseNotice";
	PkgType[PkgType["GroupMemberDecreaseNotice"] = 34] = "GroupMemberDecreaseNotice";
	return PkgType;
}(PkgType || {});
var Event0x2DCSubType = /* @__PURE__ */ function(Event0x2DCSubType) {
	Event0x2DCSubType[Event0x2DCSubType["GroupMuteNotice"] = 12] = "GroupMuteNotice";
	Event0x2DCSubType[Event0x2DCSubType["GroupRecallNotice"] = 17] = "GroupRecallNotice";
	Event0x2DCSubType[Event0x2DCSubType["GroupGreyTipNotice"] = 20] = "GroupGreyTipNotice";
	Event0x2DCSubType[Event0x2DCSubType["GroupEssenceNotice"] = 21] = "GroupEssenceNotice";
	return Event0x2DCSubType;
}(Event0x2DCSubType || {});
var Event0x210SubType = /* @__PURE__ */ function(Event0x210SubType) {
	Event0x210SubType[Event0x210SubType["FriendRequestNotice"] = 35] = "FriendRequestNotice";
	Event0x210SubType[Event0x210SubType["FriendRecallNotice"] = 138] = "FriendRecallNotice";
	Event0x210SubType[Event0x210SubType["FriendPokeNotice"] = 290] = "FriendPokeNotice";
	return Event0x210SubType;
}(Event0x210SubType || {});
function makeImageUrl(origUrl) {
	if (!origUrl) return "";
	if (origUrl.includes("rkey")) return "https://multimedia.nt.qq.com.cn" + origUrl;
	return "http://gchat.qpic.cn" + origUrl;
}
var HEX_CHARS = "0123456789ABCDEF";
function bytesToHex(data) {
	let r = "";
	for (const b of data) {
		r += HEX_CHARS[b >> 4];
		r += HEX_CHARS[b & 15];
	}
	return r;
}
function decompressData(data) {
	if (!data || data.length === 0) return "";
	if (data[0] === 1 && data.length > 1) try {
		return inflateSync(Buffer.from(data.subarray(1))).toString("utf8");
	} catch {
		return "";
	}
	if (data[0] === 0 && data.length > 1) return Buffer.from(data.subarray(1)).toString("utf8");
	return Buffer.from(data).toString("utf8");
}
function isNumericUin(value) {
	return value.length > 0 && /^\d+$/.test(value);
}
function parseU64OrZero(value) {
	if (!value) return 0;
	const n = parseInt(value, 10);
	return isNaN(n) ? 0 : n;
}
function resolveUidToUin(qqInfo, groupId, uid, fallback = 0) {
	if (!uid) return fallback;
	if (isNumericUin(uid)) {
		const n = parseInt(uid, 10);
		if (!isNaN(n)) return n;
	}
	if (groupId) {
		const uin = qqInfo.resolveGroupMemberUid(groupId, uid);
		if (uin !== null) return uin;
	}
	const uin = qqInfo.resolveUid(uid);
	if (uin !== null) return uin;
	return fallback;
}
function decodeOperatorUid(bytes) {
	if (!bytes || bytes.length === 0) return "";
	const info = protoDecode(bytes, OperatorInfoSchema);
	if (info?.operatorField?.uid) return info.operatorField.uid;
	return Buffer.from(bytes).toString("utf8");
}
function buildTemplateMap(params) {
	const map = /* @__PURE__ */ new Map();
	for (const p of params) if (p.name !== void 0) map.set(p.name, p.value ?? "");
	return map;
}
function findTemplateValue(map, ...keys) {
	for (const k of keys) {
		const v = map.get(k);
		if (v) return v;
	}
	return "";
}
function unwrapGroupNotifyPayload(content) {
	if (content.length <= 7) return null;
	const lenBe = content[5] << 8 | content[6];
	const lenLe = content[5] | content[6] << 8;
	if (7 + lenBe <= content.length) return content.subarray(7, 7 + lenBe);
	if (7 + lenLe <= content.length) return content.subarray(7, 7 + lenLe);
	return content.subarray(7);
}
function convertElements(elems) {
	const result = [];
	let skipNext = false;
	for (const elem of elems) {
		if (skipNext) {
			skipNext = false;
			continue;
		}
		if (elem.srcMsg?.origSeqs && elem.srcMsg.origSeqs.length > 0) result.push({
			type: "reply",
			replySeq: elem.srcMsg.origSeqs[0]
		});
		if (elem.text) {
			const t = elem.text;
			let mention = null;
			if (t.pbReserve && t.pbReserve.length > 0) mention = protoDecode(t.pbReserve, MentionExtraSchema);
			const hasAttr6 = t.attr6Buf && t.attr6Buf.length > 11;
			const hasMention = mention && (mention.type === 1 || mention.type === 2);
			if (hasAttr6 || hasMention) {
				const me = {
					type: "at",
					text: t.str ?? ""
				};
				if (hasAttr6) {
					const buf = t.attr6Buf;
					me.targetUin = (buf[7] << 24 | buf[8] << 16 | buf[9] << 8 | buf[10]) >>> 0;
				}
				if (hasMention && mention) {
					me.uid = mention.uid ?? "";
					if (!me.targetUin) me.targetUin = mention.uin ?? 0;
				}
				result.push(me);
			} else {
				const text = t.str ?? "";
				if (text) result.push({
					type: "text",
					text
				});
			}
		}
		if (elem.face) result.push({
			type: "face",
			faceId: elem.face.index ?? 0
		});
		if (elem.marketFace) result.push({
			type: "mface",
			text: elem.marketFace.faceName ?? "",
			faceId: elem.marketFace.tabId ?? 0,
			subType: elem.marketFace.subType ?? 0
		});
		if (elem.notOnlineImage) {
			const img = elem.notOnlineImage;
			if (img.picMd5 && img.picMd5.length > 0) {
				const urlPath = img.origUrl || img.bigUrl || "";
				result.push({
					type: "image",
					imageUrl: makeImageUrl(urlPath),
					fileId: img.filePath ?? "",
					fileSize: img.fileLen ?? 0,
					width: img.picWidth ?? 0,
					height: img.picHeight ?? 0,
					subType: img.pbRes?.subType ?? 0,
					summary: img.pbRes?.summary ?? "[image]"
				});
			}
		}
		if (elem.customFace) {
			const img = elem.customFace;
			if (img.md5 && img.md5.length > 0) result.push({
				type: "image",
				imageUrl: makeImageUrl(img.origUrl ?? ""),
				fileId: img.filePath ?? "",
				fileSize: img.size ?? 0,
				width: img.width ?? 0,
				height: img.height ?? 0,
				subType: img.pbRes?.subType ?? 0,
				summary: img.pbRes?.summary ?? "[image]"
			});
		}
		if (elem.videoFile) {
			const v = elem.videoFile;
			result.push({
				type: "video",
				fileId: v.fileUuid ?? "",
				fileName: v.fileName ?? "",
				fileSize: v.fileSize ?? 0,
				duration: v.fileTime ?? 0,
				fileHash: v.fileMd5 && v.fileMd5.length > 0 ? bytesToHex(v.fileMd5) : "",
				mediaNode: {
					fileUuid: v.fileUuid ?? "",
					info: {
						fileSize: v.fileSize ?? 0,
						fileHash: v.fileMd5 && v.fileMd5.length > 0 ? bytesToHex(v.fileMd5) : "",
						fileName: v.fileName ?? "",
						width: v.fileWidth ?? 0,
						height: v.fileHeight ?? 0,
						time: v.fileTime ?? 0,
						type: {
							type: 2,
							videoFormat: v.fileFormat ?? 0
						}
					}
				}
			});
		}
		if (elem.groupFile) {
			const f = elem.groupFile;
			result.push({
				type: "file",
				fileId: f.fileId ?? "",
				fileName: f.filename ?? "",
				fileSize: f.fileSize !== void 0 ? Number(f.fileSize) : 0
			});
		}
		if (elem.transElem) {
			const te = elem.transElem;
			if ((te.elemType ?? 0) === 24 && te.elemValue && te.elemValue.length > 3) {
				const val = te.elemValue;
				const len = val[1] << 8 | val[2];
				if (val.length >= 3 + len) {
					const extra = protoDecode(val.subarray(3, 3 + len), GroupFileExtraSchema);
					if (extra?.inner?.info) {
						const info = extra.inner.info;
						result.push({
							type: "file",
							fileName: info.fileName ?? "",
							fileSize: info.fileSize !== void 0 ? Number(info.fileSize) : 0,
							fileId: info.fileId ?? ""
						});
					}
				}
			}
		}
		if (elem.richMsg) {
			const rm = elem.richMsg;
			if (rm.template1 && rm.template1.length > 0) {
				const content = decompressData(rm.template1);
				if (content) {
					const svcId = rm.serviceId ?? 0;
					if (svcId === 35) {
						const pos = content.indexOf("m_resid=\"");
						if (pos !== -1) {
							const start = pos + 9;
							const end = content.indexOf("\"", start);
							if (end !== -1) {
								result.push({
									type: "forward",
									resId: content.substring(start, end)
								});
								continue;
							}
						}
						result.push({
							type: "xml",
							text: content,
							subType: svcId
						});
					} else if (svcId === 1) result.push({
						type: "json",
						text: content
					});
					else result.push({
						type: "xml",
						text: content,
						subType: svcId
					});
				}
			}
		}
		if (elem.lightApp) {
			const la = elem.lightApp;
			if (la.data && la.data.length > 0) {
				const content = decompressData(la.data);
				if (content) result.push({
					type: "json",
					text: content
				});
			}
		}
		if (elem.commonElem) {
			const ce = elem.commonElem;
			const svcType = ce.serviceType ?? 0;
			const bizType = ce.businessType ?? 0;
			if (svcType === 2) result.push({
				type: "poke",
				subType: bizType
			});
			else if (svcType === 3 && ce.pbElem && ce.pbElem.length > 1) {
				const pb = ce.pbElem;
				let pos = 1;
				let length = 0, shift = 0;
				while (pos < pb.length) {
					const b = pb[pos++];
					length |= (b & 127) << shift;
					shift += 7;
					if ((b & 128) === 0) break;
				}
				if (pos + length <= pb.length) {
					const img = protoDecode(pb.subarray(pos, pos + length), NotOnlineImageSchema);
					if (img) {
						const me = {
							type: "image",
							fileId: img.filePath ?? "",
							fileSize: img.fileLen ?? 0,
							width: img.picWidth ?? 0,
							height: img.picHeight ?? 0,
							flash: true,
							summary: "[flash image]"
						};
						if (img.pbRes) me.subType = img.pbRes.subType ?? 0;
						if (img.picMd5 && img.picMd5.length > 0) me.imageUrl = "http://gchat.qpic.cn/gchatpic_new/0/0-0-" + bytesToHex(img.picMd5) + "/0";
						result.push(me);
					}
				}
				skipNext = true;
			} else if (ce.pbElem && (svcType === 48 || bizType === 10 || bizType === 20 || bizType === 11 || bizType === 21 || bizType === 12 || bizType === 22)) {
				const info = protoDecode(ce.pbElem, MsgInfoSchema);
				if (info?.msgInfoBody && info.msgInfoBody.length > 0) {
					const body = info.msgInfoBody[0];
					if (body.index?.info) {
						const idx = body.index;
						const fi = idx.info;
						if (bizType === 10 || bizType === 20) {
							let url = "";
							if (body.picture) {
								const domain = body.picture.domain ?? "multimedia.nt.qq.com.cn";
								const path = body.picture.urlPath ?? "";
								if (path) {
									url = "https://" + domain + path;
									if (body.picture.ext?.originalParameter) url += body.picture.ext.originalParameter;
								}
							}
							const me = {
								type: "image",
								fileId: fi.fileName ?? "",
								fileSize: fi.fileSize ?? 0,
								width: fi.width ?? 0,
								height: fi.height ?? 0,
								imageUrl: url
							};
							if (info.extBizInfo?.pic) {
								me.subType = info.extBizInfo.pic.bizType ?? 0;
								me.summary = info.extBizInfo.pic.textSummary || "[image]";
							}
							result.push(me);
						} else if (bizType === 12 || bizType === 22) result.push({
							type: "record",
							fileName: fi.fileName ?? "",
							fileId: idx.fileUuid ?? "",
							duration: fi.time ?? 0,
							fileHash: fi.fileHash ?? "",
							mediaNode: {
								fileUuid: idx.fileUuid,
								storeId: idx.storeId,
								uploadTime: idx.uploadTime,
								ttl: idx.ttl,
								subType: idx.subType,
								info: {
									fileSize: fi.fileSize,
									fileHash: fi.fileHash,
									fileSha1: fi.fileSha1,
									fileName: fi.fileName,
									width: fi.width,
									height: fi.height,
									time: fi.time,
									original: fi.original,
									type: {
										type: fi.type?.type,
										picFormat: fi.type?.picFormat,
										videoFormat: fi.type?.videoFormat,
										voiceFormat: fi.type?.voiceFormat
									}
								}
							}
						});
						else if (bizType === 11 || bizType === 21) result.push({
							type: "video",
							fileName: fi.fileName ?? "",
							fileId: idx.fileUuid ?? "",
							fileSize: fi.fileSize ?? 0,
							duration: fi.time ?? 0,
							fileHash: fi.fileHash ?? "",
							mediaNode: {
								fileUuid: idx.fileUuid,
								storeId: idx.storeId,
								uploadTime: idx.uploadTime,
								ttl: idx.ttl,
								subType: idx.subType,
								info: {
									fileSize: fi.fileSize,
									fileHash: fi.fileHash,
									fileSha1: fi.fileSha1,
									fileName: fi.fileName,
									width: fi.width,
									height: fi.height,
									time: fi.time,
									original: fi.original,
									type: {
										type: fi.type?.type,
										picFormat: fi.type?.picFormat,
										videoFormat: fi.type?.videoFormat,
										voiceFormat: fi.type?.voiceFormat
									}
								}
							}
						});
					}
				}
			} else if (svcType === 33 && ce.pbElem) {
				const extra = protoDecode(ce.pbElem, QSmallFaceExtraSchema);
				if (extra) result.push({
					type: "face",
					faceId: extra.faceId ?? 0
				});
			} else if (svcType === 37 && ce.pbElem) {
				const extra = protoDecode(ce.pbElem, QFaceExtraSchema);
				if (extra?.qsid !== void 0) result.push({
					type: "face",
					faceId: extra.qsid
				});
				skipNext = true;
			}
		}
	}
	return result;
}
function extractRichtextExtras(rt, elements, isGroup = false) {
	if (rt.ptt) {
		const p = rt.ptt;
		const me = {
			type: "record",
			fileName: p.fileName ?? "",
			fileSize: p.fileSize ?? 0,
			duration: p.time ?? 0,
			fileHash: p.fileMd5 && p.fileMd5.length > 0 ? bytesToHex(p.fileMd5) : ""
		};
		if (isGroup && (p.fileId ?? 0n) !== 0n) me.fileId = p.groupFileKey ?? "";
		else if (p.fileUuid && p.fileUuid.length > 0) me.fileId = Buffer.from(p.fileUuid).toString("utf8");
		me.mediaNode = {
			fileUuid: me.fileId ?? "",
			info: {
				fileSize: p.fileSize ?? 0,
				fileHash: p.fileMd5 && p.fileMd5.length > 0 ? bytesToHex(p.fileMd5) : "",
				fileName: p.fileName ?? "",
				time: p.time ?? 0,
				type: {
					type: 3,
					voiceFormat: p.format ?? 0
				}
			}
		};
		elements.push(me);
	}
	if (rt.notOnlineFile) {
		const f = rt.notOnlineFile;
		elements.push({
			type: "file",
			fileId: f.fileUuid ?? "",
			fileName: f.fileName ?? "",
			fileSize: f.fileSize !== void 0 ? Number(f.fileSize) : 0,
			fileHash: f.fileHash ?? ""
		});
	}
}
function extractMsgContent(msgContent, elements) {
	const extra = protoDecode(msgContent, FileExtraSchema);
	if (!extra?.file) return;
	const f = extra.file;
	if (f.fileSize !== void 0 && f.fileName && f.fileMd5 && f.fileUuid && f.fileHash) elements.push({
		type: "file",
		fileName: f.fileName,
		fileId: f.fileUuid,
		fileSize: f.fileSize !== void 0 ? Number(f.fileSize) : 0,
		fileHash: f.fileHash
	});
}
var MSG_PUSH_CMD = "trpc.msg.olpush.OlPushService.MsgPush";
function parseMsgPush(pkt, qqInfo) {
	if (pkt.body.length === 0) return [];
	const push = protoDecode(Buffer.from(pkt.body), PushMsgSchema);
	if (!push?.message) return [];
	const msg = push.message;
	if (!msg.contentHead) return [];
	const head = msg.contentHead;
	const msgType = head.msgType ?? 0;
	const subType = head.subType ?? 0;
	const sequence = head.sequence ?? 0;
	const timestamp = head.timestamp ?? 0;
	const msgId = head.msgId ?? 0;
	let fromUin = 0;
	if (msg.responseHead) {
		fromUin = msg.responseHead.fromUin ?? 0;
		msg.responseHead.fromUid;
	}
	let selfUin = 0;
	if (pkt.uin) {
		const n = parseInt(pkt.uin, 10);
		if (!isNaN(n)) selfUin = n;
	}
	const content = msg.body?.msgContent ? msg.body.msgContent : new Uint8Array(0);
	const buildElements = (isGroup) => {
		const elements = [];
		if (msg.body?.richText) {
			const rt = msg.body.richText;
			if (rt.elems) elements.push(...convertElements(rt.elems));
			extractRichtextExtras(rt, elements, isGroup);
		}
		if (msg.body?.msgContent && msg.body.msgContent.length > 0) extractMsgContent(msg.body.msgContent, elements);
		return elements;
	};
	switch (msgType) {
		case PkgType.GroupMemberIncreaseNotice: {
			const change = protoDecode(content, GroupChangeSchema);
			if (!change) return [];
			return [{
				kind: "group_member_join",
				time: timestamp,
				selfUin,
				groupId: change.groupUin ?? 0,
				userUin: resolveUidToUin(qqInfo, change.groupUin ?? 0, change.memberUid ?? "", fromUin),
				operatorUin: resolveUidToUin(qqInfo, change.groupUin ?? 0, decodeOperatorUid(change.operatorBytes ?? new Uint8Array(0)), fromUin)
			}];
		}
		case PkgType.GroupMemberDecreaseNotice: {
			const change = protoDecode(content, GroupChangeSchema);
			if (!change) return [];
			const dt = change.decreaseType ?? 0;
			return [{
				kind: "group_member_leave",
				time: timestamp,
				selfUin,
				groupId: change.groupUin ?? 0,
				userUin: resolveUidToUin(qqInfo, change.groupUin ?? 0, change.memberUid ?? "", fromUin),
				operatorUin: resolveUidToUin(qqInfo, change.groupUin ?? 0, decodeOperatorUid(change.operatorBytes ?? new Uint8Array(0)), fromUin),
				isKick: dt !== 0 && dt !== 130
			}];
		}
		case PkgType.GroupAdminChangedNotice: {
			const admin = protoDecode(content, GroupAdminSchema);
			if (!admin?.body) return [];
			const extra = admin.body.extraEnable ?? admin.body.extraDisable;
			if (!extra) return [];
			return [{
				kind: "group_admin",
				time: timestamp,
				selfUin,
				groupId: admin.groupUin ?? 0,
				userUin: resolveUidToUin(qqInfo, admin.groupUin ?? 0, extra.adminUid ?? "", fromUin),
				set: admin.body.extraEnable !== void 0
			}];
		}
		case PkgType.GroupRequestJoinNotice: {
			const join = protoDecode(content, GroupJoinSchema);
			if (!join) return [];
			return [{
				kind: "group_invite",
				time: timestamp,
				selfUin,
				groupId: join.groupUin ?? 0,
				fromUin: resolveUidToUin(qqInfo, join.groupUin ?? 0, join.targetUid ?? "", fromUin),
				subType: "add",
				message: "",
				flag: "add:" + (join.groupUin ?? 0) + ":" + (join.targetUid ?? "")
			}];
		}
		case PkgType.GroupRequestInvitationNotice: {
			const invitation = protoDecode(content, GroupInvitationSchema);
			if (!invitation?.info?.inner) return [];
			const inner = invitation.info.inner;
			return [{
				kind: "group_invite",
				time: timestamp,
				selfUin,
				groupId: inner.groupUin ?? 0,
				fromUin: resolveUidToUin(qqInfo, inner.groupUin ?? 0, inner.invitorUid ?? "", fromUin),
				subType: "invite",
				message: "",
				flag: "invite:" + (inner.groupUin ?? 0) + ":" + (inner.invitorUid ?? "")
			}];
		}
		case PkgType.GroupInviteNotice: {
			const invite = protoDecode(content, GroupInviteSchema);
			if (!invite) return [];
			return [{
				kind: "group_invite",
				time: timestamp,
				selfUin,
				groupId: invite.groupUin ?? 0,
				fromUin: resolveUidToUin(qqInfo, invite.groupUin ?? 0, invite.invitorUid ?? "", fromUin),
				subType: "invite",
				message: "",
				flag: "invite:" + (invite.groupUin ?? 0) + ":" + (invite.invitorUid ?? "")
			}];
		}
		case PkgType.Event0x210:
			switch (subType) {
				case Event0x210SubType.FriendRequestNotice: {
					const request = protoDecode(content, FriendRequestSchema);
					if (!request?.info) return [];
					const sourceUid = request.info.newSource || request.info.sourceUid || "";
					return [{
						kind: "friend_request",
						time: timestamp,
						selfUin,
						fromUin: resolveUidToUin(qqInfo, 0, sourceUid, fromUin),
						message: request.info.message ?? "",
						flag: sourceUid
					}];
				}
				case Event0x210SubType.FriendRecallNotice: {
					const recall = protoDecode(content, FriendRecallSchema);
					if (!recall?.info) return [];
					return [{
						kind: "friend_recall",
						time: recall.info.time ?? timestamp,
						selfUin,
						userUin: resolveUidToUin(qqInfo, 0, recall.info.fromUid ?? "", fromUin),
						msgSeq: recall.info.clientSequence ?? 0
					}];
				}
				case Event0x210SubType.FriendPokeNotice: {
					const grayTip = protoDecode(content, GeneralGrayTipInfoSchema);
					if (!grayTip || (grayTip.busiType ?? 0n) !== 12n) return [];
					const templates = buildTemplateMap(grayTip.msgTemplParam ?? []);
					const actor = findTemplateValue(templates, "uin_str1");
					const target = findTemplateValue(templates, "uin_str2");
					return [{
						kind: "friend_poke",
						time: timestamp,
						selfUin,
						userUin: resolveUidToUin(qqInfo, 0, actor, parseU64OrZero(actor)),
						targetUin: resolveUidToUin(qqInfo, 0, target, parseU64OrZero(target)),
						action: findTemplateValue(templates, "action_str", "alt_str1"),
						suffix: findTemplateValue(templates, "suffix_str"),
						actionImgUrl: findTemplateValue(templates, "action_img_url")
					}];
				}
			}
			break;
		case PkgType.Event0x2DC:
			switch (subType) {
				case Event0x2DCSubType.GroupMuteNotice: {
					const mute = protoDecode(content, GroupMuteSchema);
					if (!mute?.data?.state) return [];
					const duration = mute.data.state.duration ?? 0;
					return [{
						kind: "group_mute",
						time: mute.data.timestamp ?? timestamp,
						selfUin,
						groupId: mute.groupUin ?? 0,
						operatorUin: resolveUidToUin(qqInfo, mute.groupUin ?? 0, mute.operatorUid ?? "", fromUin),
						userUin: resolveUidToUin(qqInfo, mute.groupUin ?? 0, mute.data.state.targetUid ?? "", 0),
						duration: duration === 4294967295 ? 2147483647 : duration
					}];
				}
				case Event0x2DCSubType.GroupRecallNotice: {
					const payload = unwrapGroupNotifyPayload(content);
					if (!payload) return [];
					const notify = protoDecode(payload, NotifyMessageBodySchema);
					if (!notify?.recall?.recallMessages || notify.recall.recallMessages.length === 0) return [];
					const recalled = notify.recall.recallMessages[0];
					return [{
						kind: "group_recall",
						time: recalled.time ?? timestamp,
						selfUin,
						groupId: notify.groupUin ?? 0,
						operatorUin: resolveUidToUin(qqInfo, notify.groupUin ?? 0, notify.recall.operatorUid || notify.operatorUid || "", fromUin),
						authorUin: resolveUidToUin(qqInfo, notify.groupUin ?? 0, recalled.authorUid ?? "", fromUin),
						msgSeq: recalled.sequence ?? 0
					}];
				}
				case Event0x2DCSubType.GroupGreyTipNotice: {
					const payload = unwrapGroupNotifyPayload(content);
					if (!payload) return [];
					const notify = protoDecode(payload, NotifyMessageBodySchema);
					if (!notify?.generalGrayTip || (notify.generalGrayTip.busiType ?? 0n) !== 12n) return [];
					const templates = buildTemplateMap(notify.generalGrayTip.msgTemplParam ?? []);
					const actor = findTemplateValue(templates, "uin_str1");
					const target = findTemplateValue(templates, "uin_str2");
					return [{
						kind: "group_poke",
						time: timestamp,
						selfUin,
						groupId: notify.groupUin ?? 0,
						userUin: resolveUidToUin(qqInfo, notify.groupUin ?? 0, actor, parseU64OrZero(actor)),
						targetUin: resolveUidToUin(qqInfo, notify.groupUin ?? 0, target, parseU64OrZero(target)),
						action: findTemplateValue(templates, "action_str", "alt_str1"),
						suffix: findTemplateValue(templates, "suffix_str"),
						actionImgUrl: findTemplateValue(templates, "action_img_url")
					}];
				}
				case Event0x2DCSubType.GroupEssenceNotice: {
					const payload = unwrapGroupNotifyPayload(content);
					if (!payload) return [];
					const notify = protoDecode(payload, NotifyMessageBodySchema);
					if (!notify?.essenceMessage) return [];
					const essence = notify.essenceMessage;
					const setFlag = essence.setFlag ?? essence.setFlag2 ?? 0;
					return [{
						kind: "group_essence",
						time: essence.timestamp ?? timestamp,
						selfUin,
						groupId: essence.groupUin ?? notify.groupUin ?? 0,
						senderUin: essence.memberUin ?? 0,
						operatorUin: essence.operatorUin ?? fromUin,
						msgSeq: essence.msgSequence ?? essence.msgSequence2 ?? notify.msgSequence ?? 0,
						random: essence.random ?? 0,
						set: setFlag === 1
					}];
				}
			}
			break;
	}
	if (msgType === PkgType.GroupMessage) {
		const ev = {
			kind: "group_message",
			time: timestamp,
			selfUin,
			senderUin: fromUin,
			msgSeq: sequence,
			msgId: msgId & 2147483647,
			elements: buildElements(true),
			groupId: 0,
			senderNick: "",
			senderCard: "",
			senderRole: ""
		};
		if (msg.responseHead?.grp) {
			ev.groupId = msg.responseHead.grp.groupUin ?? 0;
			ev.senderNick = msg.responseHead.grp.memberName ?? "";
		}
		const member = qqInfo.findGroupMember(ev.groupId, fromUin);
		if (member) {
			if (!ev.senderNick) ev.senderNick = member.nickname;
			ev.senderCard = member.card;
			ev.senderRole = member.role;
		}
		return [ev];
	}
	if (msgType === PkgType.TempMessage) {
		const ev = {
			kind: "temp_message",
			time: timestamp,
			selfUin,
			senderUin: fromUin,
			msgSeq: sequence,
			elements: buildElements(false),
			groupId: 0,
			senderNick: ""
		};
		if (msg.responseHead?.grp) {
			ev.groupId = msg.responseHead.grp.groupUin ?? 0;
			ev.senderNick = msg.responseHead.grp.memberName ?? "";
		}
		if (!ev.senderNick) {
			const friend = qqInfo.findFriend(fromUin);
			if (friend) ev.senderNick = friend.nickname;
		}
		return [ev];
	}
	if (msgType === PkgType.PrivateMessage || msgType === PkgType.ForwardFakePrivateMessage || msgType === PkgType.PrivateRecordMessage || msgType === PkgType.PrivateFileMessage) {
		const ev = {
			kind: "friend_message",
			time: timestamp,
			selfUin,
			senderUin: fromUin,
			msgSeq: sequence,
			msgId: msgId & 2147483647,
			elements: buildElements(false),
			senderNick: ""
		};
		if (msg.responseHead?.forward?.friendName) ev.senderNick = msg.responseHead.forward.friendName;
		const friend = qqInfo.findFriend(fromUin);
		if (friend && !ev.senderNick) ev.senderNick = friend.nickname;
		return [ev];
	}
	return [];
}
var SendMessageRequestSchema = {
	routingHead: {
		field: 1,
		type: "message",
		schema: {
			c2c: {
				field: 1,
				type: "message",
				schema: {
					uin: {
						field: 1,
						type: "uint32"
					},
					uid: {
						field: 2,
						type: "string"
					}
				}
			},
			grp: {
				field: 2,
				type: "message",
				schema: { groupCode: {
					field: 1,
					type: "uint64"
				} }
			}
		}
	},
	contentHead: {
		field: 2,
		type: "message",
		schema: {
			type: {
				field: 1,
				type: "uint32"
			},
			subType: {
				field: 2,
				type: "uint32"
			},
			c2cCmd: {
				field: 3,
				type: "uint32"
			}
		}
	},
	messageBody: {
		field: 3,
		type: "message",
		schema: { richText: {
			field: 1,
			type: "message",
			schema: { elems: {
				field: 2,
				type: "repeated_message",
				schema: ElemSchema
			} }
		} }
	},
	clientSequence: {
		field: 4,
		type: "uint32"
	},
	random: {
		field: 5,
		type: "uint32"
	},
	syncCookie: {
		field: 6,
		type: "bytes"
	},
	via: {
		field: 8,
		type: "uint32"
	},
	dataStatist: {
		field: 9,
		type: "uint32"
	},
	ctrl: {
		field: 12,
		type: "message",
		schema: { msgFlag: {
			field: 1,
			type: "int32"
		} }
	},
	multiSendSeq: {
		field: 14,
		type: "uint32"
	}
};
var SendMessageResponseSchema = {
	result: {
		field: 1,
		type: "int32"
	},
	errMsg: {
		field: 2,
		type: "string"
	},
	timestamp1: {
		field: 3,
		type: "uint32"
	},
	field10: {
		field: 10,
		type: "uint32"
	},
	groupSequence: {
		field: 11,
		type: "uint32"
	},
	timestamp2: {
		field: 12,
		type: "uint32"
	},
	privateSequence: {
		field: 14,
		type: "uint32"
	}
};
var MentionExtraSendSchema = {
	type: {
		field: 3,
		type: "int32"
	},
	uin: {
		field: 4,
		type: "uint32"
	},
	field5: {
		field: 5,
		type: "int32"
	},
	uid: {
		field: 9,
		type: "string"
	}
};
var MarkdownDataSchema = { content: {
	field: 1,
	type: "string"
} };
//#endregion
//#region src/bridge/proto/oidb.ts
var OidbPropertySchema = {
	key: {
		field: 1,
		type: "string"
	},
	value: {
		field: 2,
		type: "bytes"
	}
};
function makeOidbBaseSchema(bodySchema) {
	return {
		command: {
			field: 1,
			type: "uint32"
		},
		subCommand: {
			field: 2,
			type: "uint32"
		},
		errorCode: {
			field: 3,
			type: "uint32"
		},
		body: {
			field: 4,
			type: "message",
			schema: bodySchema
		},
		errorMsg: {
			field: 5,
			type: "string"
		},
		properties: {
			field: 11,
			type: "repeated_message",
			schema: OidbPropertySchema
		},
		reserved: {
			field: 12,
			type: "int32"
		}
	};
}
var OidbFriendPropertySchema = {
	code: {
		field: 1,
		type: "uint32"
	},
	value: {
		field: 2,
		type: "string"
	}
};
var OidbSvcTrpcTcp0xFD4_1ResponseSchema = {
	next: {
		field: 2,
		type: "message",
		schema: { uin: {
			field: 1,
			type: "uint32"
		} }
	},
	displayFriendCount: {
		field: 3,
		type: "uint32"
	},
	timestamp: {
		field: 6,
		type: "uint32"
	},
	selfUin: {
		field: 7,
		type: "uint32"
	},
	friends: {
		field: 101,
		type: "repeated_message",
		schema: {
			uid: {
				field: 1,
				type: "string"
			},
			customGroup: {
				field: 2,
				type: "uint32"
			},
			uin: {
				field: 3,
				type: "uint32"
			},
			additional: {
				field: 10001,
				type: "repeated_message",
				schema: {
					type: {
						field: 1,
						type: "uint32"
					},
					layer1: {
						field: 2,
						type: "message",
						schema: { properties: {
							field: 2,
							type: "repeated_message",
							schema: OidbFriendPropertySchema
						} }
					}
				}
			}
		}
	},
	groups: {
		field: 102,
		type: "repeated_message",
		schema: OidbFriendPropertySchema
	}
};
var OidbSvcTrpcTcp0xFE5_2ResponseSchema = { groups: {
	field: 2,
	type: "repeated_message",
	schema: {
		groupUin: {
			field: 3,
			type: "uint32"
		},
		info: {
			field: 4,
			type: "message",
			schema: {
				groupOwner: {
					field: 1,
					type: "message",
					schema: { uid: {
						field: 2,
						type: "string"
					} }
				},
				createdTime: {
					field: 2,
					type: "uint32"
				},
				memberMax: {
					field: 3,
					type: "uint32"
				},
				memberCount: {
					field: 4,
					type: "uint32"
				},
				groupName: {
					field: 5,
					type: "string"
				},
				description: {
					field: 18,
					type: "string"
				},
				question: {
					field: 19,
					type: "string"
				},
				announcement: {
					field: 30,
					type: "string"
				}
			}
		},
		customInfo: {
			field: 5,
			type: "message",
			schema: { remark: {
				field: 3,
				type: "string"
			} }
		}
	}
} };
var OidbSvcTrpcTcp0xFE7_3ResponseSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	members: {
		field: 2,
		type: "repeated_message",
		schema: {
			uin: {
				field: 1,
				type: "message",
				schema: {
					uid: {
						field: 2,
						type: "string"
					},
					uin: {
						field: 4,
						type: "uint32"
					}
				}
			},
			memberName: {
				field: 10,
				type: "string"
			},
			specialTitle: {
				field: 17,
				type: "string"
			},
			memberCard: {
				field: 11,
				type: "message",
				schema: { memberCard: {
					field: 2,
					type: "string"
				} }
			},
			level: {
				field: 12,
				type: "message",
				schema: {
					infos: {
						field: 1,
						type: "repeated_uint32"
					},
					level: {
						field: 2,
						type: "uint32"
					}
				}
			},
			joinTimestamp: {
				field: 100,
				type: "uint32"
			},
			lastMsgTimestamp: {
				field: 101,
				type: "uint32"
			},
			shutUpTimestamp: {
				field: 102,
				type: "uint32"
			},
			permission: {
				field: 107,
				type: "uint32"
			}
		}
	},
	field3: {
		field: 3,
		type: "uint32"
	},
	memberChangeSeq: {
		field: 5,
		type: "uint32"
	},
	memberCardChangeSeq: {
		field: 6,
		type: "uint32"
	},
	token: {
		field: 15,
		type: "string"
	}
};
var OidbSvcTrpcTcp0x10C0ResponseUserSchema = {
	uid: {
		field: 1,
		type: "string"
	},
	name: {
		field: 2,
		type: "string"
	}
};
var OidbSvcTrpcTcp0x10C0ResponseSchema = {
	requests: {
		field: 1,
		type: "repeated_message",
		schema: {
			sequence: {
				field: 1,
				type: "uint64"
			},
			eventType: {
				field: 2,
				type: "uint32"
			},
			state: {
				field: 3,
				type: "uint32"
			},
			group: {
				field: 4,
				type: "message",
				schema: {
					groupUin: {
						field: 1,
						type: "uint32"
					},
					groupName: {
						field: 2,
						type: "string"
					}
				}
			},
			target: {
				field: 5,
				type: "message",
				schema: OidbSvcTrpcTcp0x10C0ResponseUserSchema
			},
			invitor: {
				field: 6,
				type: "message",
				schema: OidbSvcTrpcTcp0x10C0ResponseUserSchema
			},
			operatorUser: {
				field: 7,
				type: "message",
				schema: OidbSvcTrpcTcp0x10C0ResponseUserSchema
			},
			field9: {
				field: 9,
				type: "string"
			},
			comment: {
				field: 10,
				type: "string"
			}
		}
	},
	field2: {
		field: 2,
		type: "uint64"
	},
	newLatestSeq: {
		field: 3,
		type: "uint64"
	},
	field4: {
		field: 4,
		type: "uint32"
	},
	field5: {
		field: 5,
		type: "uint64"
	},
	field6: {
		field: 6,
		type: "uint32"
	}
};
//#endregion
//#region src/bridge/proto/highway.ts
var DataHighwayHeadSchema = {
	version: {
		field: 1,
		type: "uint32"
	},
	uin: {
		field: 2,
		type: "string"
	},
	command: {
		field: 3,
		type: "string"
	},
	seq: {
		field: 4,
		type: "uint32"
	},
	retryTimes: {
		field: 5,
		type: "uint32"
	},
	appId: {
		field: 6,
		type: "uint32"
	},
	dataFlag: {
		field: 7,
		type: "uint32"
	},
	commandId: {
		field: 8,
		type: "uint32"
	}
};
var SegHeadSchema = {
	serviceId: {
		field: 1,
		type: "uint32"
	},
	filesize: {
		field: 2,
		type: "uint64"
	},
	dataOffset: {
		field: 3,
		type: "uint64"
	},
	dataLength: {
		field: 4,
		type: "uint32"
	},
	retCode: {
		field: 5,
		type: "uint32"
	},
	serviceTicket: {
		field: 6,
		type: "bytes"
	},
	flag: {
		field: 7,
		type: "uint32"
	},
	md5: {
		field: 8,
		type: "bytes"
	},
	fileMd5: {
		field: 9,
		type: "bytes"
	},
	cacheAddr: {
		field: 10,
		type: "uint32"
	},
	cachePort: {
		field: 13,
		type: "uint32"
	}
};
var ReqDataHighwayHeadSchema = {
	msgBaseHead: {
		field: 1,
		type: "message",
		schema: DataHighwayHeadSchema
	},
	msgSegHead: {
		field: 2,
		type: "message",
		schema: SegHeadSchema
	},
	bytesReqExtendInfo: {
		field: 3,
		type: "bytes"
	},
	timestamp: {
		field: 4,
		type: "uint64"
	},
	msgLoginSigHead: {
		field: 5,
		type: "message",
		schema: {
			loginSigType: {
				field: 1,
				type: "uint32"
			},
			appId: {
				field: 3,
				type: "uint32"
			}
		}
	}
};
var RespDataHighwayHeadSchema = {
	msgBaseHead: {
		field: 1,
		type: "message",
		schema: DataHighwayHeadSchema
	},
	msgSegHead: {
		field: 2,
		type: "message",
		schema: SegHeadSchema
	},
	errorCode: {
		field: 3,
		type: "uint32"
	}
};
var HighwayNetworkSchema = { ipv4s: {
	field: 1,
	type: "repeated_message",
	schema: {
		domain: {
			field: 1,
			type: "message",
			schema: {
				isEnable: {
					field: 1,
					type: "bool"
				},
				ip: {
					field: 2,
					type: "string"
				}
			}
		},
		port: {
			field: 2,
			type: "uint32"
		}
	}
} };
var HighwayHashSchema = { fileSha1: {
	field: 1,
	type: "repeated_bytes"
} };
var HighwayMsgInfoBodySchema = {
	index: {
		field: 1,
		type: "message",
		schema: IndexNodeSchema
	},
	picture: {
		field: 2,
		type: "message",
		schema: PictureInfoSchema
	},
	fileExist: {
		field: 5,
		type: "bool"
	},
	hashSum: {
		field: 6,
		type: "message",
		schema: HashSumSchema
	}
};
var NTV2RichMediaHighwayExtSchema = {
	fileUuid: {
		field: 1,
		type: "string"
	},
	uKey: {
		field: 2,
		type: "string"
	},
	network: {
		field: 5,
		type: "message",
		schema: HighwayNetworkSchema
	},
	msgInfoBody: {
		field: 6,
		type: "repeated_message",
		schema: HighwayMsgInfoBodySchema
	},
	blockSize: {
		field: 10,
		type: "uint32"
	},
	hash: {
		field: 11,
		type: "message",
		schema: HighwayHashSchema
	}
};
var FileUploadExtSchema = {
	unknown1: {
		field: 1,
		type: "int32"
	},
	unknown2: {
		field: 2,
		type: "int32"
	},
	unknown3: {
		field: 3,
		type: "int32"
	},
	entry: {
		field: 100,
		type: "message",
		schema: {
			busiBuff: {
				field: 100,
				type: "message",
				schema: {
					busId: {
						field: 1,
						type: "int32"
					},
					senderUin: {
						field: 100,
						type: "uint64"
					},
					receiverUin: {
						field: 200,
						type: "uint64"
					},
					groupCode: {
						field: 400,
						type: "uint64"
					}
				}
			},
			fileEntry: {
				field: 200,
				type: "message",
				schema: {
					fileSize: {
						field: 100,
						type: "uint64"
					},
					md5: {
						field: 200,
						type: "bytes"
					},
					checkKey: {
						field: 300,
						type: "bytes"
					},
					md5S2: {
						field: 400,
						type: "bytes"
					},
					fileId: {
						field: 600,
						type: "string"
					},
					uploadKey: {
						field: 700,
						type: "bytes"
					}
				}
			},
			clientInfo: {
				field: 300,
				type: "message",
				schema: {
					clientType: {
						field: 100,
						type: "int32"
					},
					appId: {
						field: 200,
						type: "string"
					},
					terminalType: {
						field: 300,
						type: "int32"
					},
					clientVer: {
						field: 400,
						type: "string"
					},
					unknown: {
						field: 600,
						type: "int32"
					}
				}
			},
			fileNameInfo: {
				field: 400,
				type: "message",
				schema: { fileName: {
					field: 100,
					type: "string"
				} }
			},
			host: {
				field: 500,
				type: "message",
				schema: { hosts: {
					field: 200,
					type: "repeated_message",
					schema: {
						url: {
							field: 1,
							type: "message",
							schema: {
								unknown: {
									field: 1,
									type: "int32"
								},
								host: {
									field: 2,
									type: "string"
								}
							}
						},
						port: {
							field: 2,
							type: "uint32"
						}
					}
				} }
			}
		}
	},
	unknown200: {
		field: 200,
		type: "int32"
	}
};
var EncodableMediaMsgInfoSchema = {
	msgInfoBody: {
		field: 1,
		type: "repeated_message",
		schema: HighwayMsgInfoBodySchema
	},
	extBizInfo: {
		field: 2,
		type: "message",
		schema: {
			pic: {
				field: 1,
				type: "message",
				schema: PicExtBizInfoSchema
			},
			video: {
				field: 2,
				type: "message",
				schema: VideoExtBizInfoSchema
			},
			ptt: {
				field: 3,
				type: "message",
				schema: PttExtBizInfoSchema
			},
			busiType: {
				field: 10,
				type: "uint32"
			}
		}
	}
};
var HttpConn0x6FF501RequestSchema = { httpConn: {
	field: 1281,
	type: "message",
	schema: {
		field1: {
			field: 1,
			type: "int32"
		},
		field2: {
			field: 2,
			type: "int32"
		},
		field3: {
			field: 3,
			type: "int32"
		},
		field4: {
			field: 4,
			type: "int32"
		},
		field6: {
			field: 6,
			type: "int32"
		},
		serviceTypes: {
			field: 7,
			type: "repeated_uint32"
		},
		field9: {
			field: 9,
			type: "int32"
		},
		field10: {
			field: 10,
			type: "int32"
		},
		field11: {
			field: 11,
			type: "int32"
		},
		ver: {
			field: 15,
			type: "string"
		}
	}
} };
var HttpConn0x6FF501ResponseSchema = { httpConn: {
	field: 1281,
	type: "message",
	schema: {
		sigSession: {
			field: 1,
			type: "bytes"
		},
		sessionKey: {
			field: 2,
			type: "bytes"
		},
		serverInfos: {
			field: 3,
			type: "repeated_message",
			schema: {
				serviceType: {
					field: 1,
					type: "uint32"
				},
				serverAddrs: {
					field: 2,
					type: "repeated_message",
					schema: {
						type: {
							field: 1,
							type: "uint32"
						},
						ip: {
							field: 2,
							type: "uint32"
						},
						port: {
							field: 3,
							type: "uint32"
						},
						area: {
							field: 4,
							type: "uint32"
						}
					}
				}
			}
		}
	}
} };
var NTV2UploadInfoSchema = {
	fileInfo: {
		field: 1,
		type: "message",
		schema: {
			fileSize: {
				field: 1,
				type: "uint32"
			},
			fileHash: {
				field: 2,
				type: "string"
			},
			fileSha1: {
				field: 3,
				type: "string"
			},
			fileName: {
				field: 4,
				type: "string"
			},
			type: {
				field: 5,
				type: "message",
				schema: {
					type: {
						field: 1,
						type: "uint32"
					},
					picFormat: {
						field: 2,
						type: "uint32"
					},
					videoFormat: {
						field: 3,
						type: "uint32"
					},
					voiceFormat: {
						field: 4,
						type: "uint32"
					}
				}
			},
			width: {
				field: 6,
				type: "uint32"
			},
			height: {
				field: 7,
				type: "uint32"
			},
			time: {
				field: 8,
				type: "uint32"
			},
			original: {
				field: 9,
				type: "uint32"
			}
		}
	},
	subFileType: {
		field: 2,
		type: "uint32"
	}
};
var NTV2ExtBizInfoSchema = {
	pic: {
		field: 1,
		type: "message",
		schema: {
			bizType: {
				field: 1,
				type: "uint32"
			},
			textSummary: {
				field: 2,
				type: "string"
			},
			reserveC2c: {
				field: 11,
				type: "message",
				schema: { subType: {
					field: 1,
					type: "uint32"
				} }
			},
			reserveTroop: {
				field: 12,
				type: "message",
				schema: { subType: {
					field: 1,
					type: "uint32"
				} }
			}
		}
	},
	video: {
		field: 2,
		type: "message",
		schema: { bytesPbReserve: {
			field: 3,
			type: "bytes"
		} }
	},
	ptt: {
		field: 3,
		type: "message",
		schema: {
			bytesReserve: {
				field: 11,
				type: "bytes"
			},
			bytesPbReserve: {
				field: 12,
				type: "bytes"
			},
			bytesGeneralFlags: {
				field: 13,
				type: "bytes"
			}
		}
	},
	busiType: {
		field: 10,
		type: "uint32"
	}
};
var NTV2UploadReqSchema = {
	uploadInfo: {
		field: 1,
		type: "repeated_message",
		schema: NTV2UploadInfoSchema
	},
	tryFastUploadCompleted: {
		field: 2,
		type: "bool"
	},
	srvSendMsg: {
		field: 3,
		type: "bool"
	},
	clientRandomId: {
		field: 4,
		type: "uint64"
	},
	compatQmsgSceneType: {
		field: 5,
		type: "uint32"
	},
	extBizInfo: {
		field: 6,
		type: "message",
		schema: NTV2ExtBizInfoSchema
	},
	clientSeq: {
		field: 7,
		type: "uint32"
	},
	noNeedCompatMsg: {
		field: 8,
		type: "bool"
	}
};
var NTV2UploadSceneInfoSchema = {
	requestType: {
		field: 101,
		type: "uint32"
	},
	businessType: {
		field: 102,
		type: "uint32"
	},
	sceneType: {
		field: 200,
		type: "uint32"
	},
	c2c: {
		field: 201,
		type: "message",
		schema: {
			accountType: {
				field: 1,
				type: "uint32"
			},
			targetUid: {
				field: 2,
				type: "string"
			}
		}
	},
	group: {
		field: 202,
		type: "message",
		schema: { groupUin: {
			field: 1,
			type: "uint32"
		} }
	}
};
var NTV2CommonHeadSchema$1 = {
	requestId: {
		field: 1,
		type: "uint32"
	},
	command: {
		field: 2,
		type: "uint32"
	}
};
var NTV2UploadRichMediaReqSchema = {
	reqHead: {
		field: 1,
		type: "message",
		schema: {
			common: {
				field: 1,
				type: "message",
				schema: NTV2CommonHeadSchema$1
			},
			scene: {
				field: 2,
				type: "message",
				schema: NTV2UploadSceneInfoSchema
			},
			client: {
				field: 3,
				type: "message",
				schema: { agentType: {
					field: 1,
					type: "uint32"
				} }
			}
		}
	},
	upload: {
		field: 2,
		type: "message",
		schema: NTV2UploadReqSchema
	}
};
var NTV2IPv4Schema = {
	outIp: {
		field: 1,
		type: "uint32"
	},
	outPort: {
		field: 2,
		type: "uint32"
	}
};
var NTV2UploadRichMediaRespSchema = {
	respHead: {
		field: 1,
		type: "message",
		schema: {
			common: {
				field: 1,
				type: "message",
				schema: NTV2CommonHeadSchema$1
			},
			retCode: {
				field: 2,
				type: "uint32"
			},
			message: {
				field: 3,
				type: "string"
			}
		}
	},
	upload: {
		field: 2,
		type: "message",
		schema: {
			uKey: {
				field: 1,
				type: "string"
			},
			uKeyTtl: {
				field: 2,
				type: "uint32"
			},
			ipv4s: {
				field: 3,
				type: "repeated_message",
				schema: NTV2IPv4Schema
			},
			msgSeq: {
				field: 5,
				type: "uint64"
			},
			msgInfo: {
				field: 6,
				type: "message",
				schema: {
					msgInfoBody: {
						field: 1,
						type: "repeated_message",
						schema: HighwayMsgInfoBodySchema
					},
					extBizInfo: {
						field: 2,
						type: "message",
						schema: NTV2ExtBizInfoSchema
					}
				}
			},
			subFileInfos: {
				field: 10,
				type: "repeated_message",
				schema: {
					subType: {
						field: 1,
						type: "uint32"
					},
					uKey: {
						field: 2,
						type: "string"
					},
					uKeyTtl: {
						field: 3,
						type: "uint32"
					},
					ipv4s: {
						field: 4,
						type: "repeated_message",
						schema: NTV2IPv4Schema
					}
				}
			}
		}
	}
};
//#endregion
//#region src/bridge/highway/utils.ts
async function loadBinarySource(source, resourceName) {
	if (!source) throw new Error(`${resourceName} source is empty`);
	if (source.startsWith("base64://")) return {
		bytes: Buffer.from(source.slice(9), "base64"),
		fileName: ""
	};
	if (source.startsWith("http://") || source.startsWith("https://")) {
		const resp = await fetch(source);
		if (!resp.ok) throw new Error(`HTTP download failed: ${resp.status}`);
		return {
			bytes: new Uint8Array(await resp.arrayBuffer()),
			fileName: guessFileNameFromUrl(source)
		};
	}
	let filePath = source;
	if (filePath.startsWith("file://")) filePath = filePath.slice(7);
	if (/^\/[a-zA-Z]:/.test(filePath)) filePath = filePath.slice(1);
	return {
		bytes: fs.readFileSync(filePath),
		fileName: path.basename(filePath)
	};
}
function guessFileNameFromUrl(url) {
	const queryPos = url.search(/[?#]/);
	const pathPart = queryPos >= 0 ? url.slice(0, queryPos) : url;
	const lastSlash = pathPart.lastIndexOf("/");
	return lastSlash >= 0 ? pathPart.slice(lastSlash + 1) : "";
}
function computeHashes(data) {
	const md5 = createHash("md5").update(data).digest();
	const sha1 = createHash("sha1").update(data).digest();
	return {
		md5: new Uint8Array(md5),
		sha1: new Uint8Array(sha1),
		md5Hex: md5.toString("hex"),
		sha1Hex: sha1.toString("hex")
	};
}
function computeMd5(data) {
	return new Uint8Array(createHash("md5").update(data).digest());
}
function readBE16(data, offset) {
	return data[offset] << 8 | data[offset + 1];
}
function readBE32(data, offset) {
	return (data[offset] << 24 | data[offset + 1] << 16 | data[offset + 2] << 8 | data[offset + 3]) >>> 0;
}
function readLE16(data, offset) {
	return data[offset] | data[offset + 1] << 8;
}
function readLE32(data, offset) {
	return (data[offset] | data[offset + 1] << 8 | data[offset + 2] << 16 | data[offset + 3] << 24) >>> 0;
}
function readBE24(data, offset) {
	return data[offset] << 16 | data[offset + 1] << 8 | data[offset + 2];
}
function detectImageFormat(bytes) {
	let width = 0;
	let height = 0;
	if (bytes.length >= 24 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) {
		width = readBE32(bytes, 16);
		height = readBE32(bytes, 20);
		return {
			format: 1001,
			width,
			height
		};
	}
	if (bytes.length >= 10 && bytes[0] === 71 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 56 && (bytes[4] === 55 || bytes[4] === 57) && bytes[5] === 97) {
		width = readLE16(bytes, 6);
		height = readLE16(bytes, 8);
		return {
			format: 2e3,
			width,
			height
		};
	}
	if (bytes.length >= 26 && bytes[0] === 66 && bytes[1] === 77) {
		width = readLE32(bytes, 18);
		height = readLE32(bytes, 22);
		return {
			format: 1005,
			width,
			height
		};
	}
	if (bytes.length >= 30 && bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70 && bytes[8] === 87 && bytes[9] === 69 && bytes[10] === 66 && bytes[11] === 80) {
		if (bytes[12] === 86 && bytes[13] === 80 && bytes[14] === 56 && bytes[15] === 32) {
			width = readLE16(bytes, 26);
			height = readLE16(bytes, 28);
			return {
				format: 1002,
				width,
				height
			};
		}
		if (bytes[12] === 86 && bytes[13] === 80 && bytes[14] === 56 && bytes[15] === 76) {
			const bits = readLE32(bytes, 21);
			width = (bits & 16383) + 1;
			height = (bits >> 14 & 16383) + 1;
			return {
				format: 1002,
				width,
				height
			};
		}
		if (bytes[12] === 86 && bytes[13] === 80 && bytes[14] === 56 && bytes[15] === 88) {
			width = readBE24(bytes, 24) + 1;
			height = readBE24(bytes, 27) + 1;
			return {
				format: 1002,
				width,
				height
			};
		}
	}
	if (bytes.length >= 4 && bytes[0] === 255 && bytes[1] === 216) {
		let offset = 2;
		while (offset + 9 <= bytes.length) {
			if (bytes[offset] !== 255) {
				offset++;
				continue;
			}
			const marker = bytes[offset + 1];
			if (marker === 216 || marker === 217) {
				offset += 2;
				continue;
			}
			if (offset + 4 > bytes.length) break;
			const segLen = readBE16(bytes, offset + 2);
			if (segLen < 2 || offset + 2 + segLen > bytes.length) break;
			if ((marker & 252) === 192 && offset + 9 <= bytes.length) {
				height = readBE16(bytes, offset + 5);
				width = readBE16(bytes, offset + 7);
				return {
					format: 1e3,
					width,
					height
				};
			}
			offset += 2 + segLen;
		}
		return {
			format: 1e3,
			width: 0,
			height: 0
		};
	}
	return {
		format: 1e3,
		width: 0,
		height: 0
	};
}
function packHighwayFrame(head, body) {
	const frame = new Uint8Array(9 + head.length + body.length + 1);
	frame[0] = 40;
	const dv = new DataView(frame.buffer, frame.byteOffset);
	dv.setUint32(1, head.length, false);
	dv.setUint32(5, body.length, false);
	frame.set(head, 9);
	frame.set(body, 9 + head.length);
	frame[frame.length - 1] = 41;
	return frame;
}
function unpackHighwayFrame(frame) {
	if (frame.length < 10 || frame[0] !== 40 || frame[frame.length - 1] !== 41) throw new Error("invalid highway response frame");
	const dv = new DataView(frame.buffer, frame.byteOffset);
	const headLen = dv.getUint32(1, false);
	const bodyLen = dv.getUint32(5, false);
	return {
		head: frame.subarray(9, 9 + headLen),
		body: frame.subarray(9 + headLen, 9 + headLen + bodyLen)
	};
}
//#endregion
//#region src/bridge/highway/highway-client.ts
var HIGHWAY_APP_ID = 1600001604;
var HIGHWAY_BLOCK_SIZE = 1024 * 1024;
var PRIVATE_IMAGE_CMD_ID = 1003;
var GROUP_IMAGE_CMD_ID = 1004;
function ipv4ToString(value) {
	return `${value & 255}.${value >> 8 & 255}.${value >> 16 & 255}.${value >> 24 & 255}`;
}
async function fetchHighwaySession(bridge) {
	const request = protoEncode({ httpConn: {
		field1: 0,
		field2: 0,
		field3: 16,
		field4: 1,
		field6: 3,
		serviceTypes: [
			1,
			5,
			10,
			21
		],
		field9: 2,
		field10: 9,
		field11: 8,
		ver: "1.0.1"
	} }, HttpConn0x6FF501RequestSchema);
	const result = await bridge.sendRawPacket("HttpConn.0x6ff_501", request);
	if (!result.success || !result.gotResponse || !result.responseData) throw new Error(result.errorMessage || "HttpConn request failed");
	const resp = protoDecode(result.responseData, HttpConn0x6FF501ResponseSchema);
	if (!resp?.httpConn) throw new Error("HttpConn response body missing");
	if (!resp.httpConn.sigSession || resp.httpConn.sigSession.length === 0) throw new Error("HttpConn response missing sig_session");
	const session = {
		sigSession: resp.httpConn.sigSession,
		sessionKey: resp.httpConn.sessionKey ?? new Uint8Array(0),
		host: "htdata3.qq.com",
		port: 80
	};
	for (const si of resp.httpConn.serverInfos ?? []) {
		if ((si.serviceType ?? 0) !== 1 || !si.serverAddrs?.length) continue;
		for (const addr of si.serverAddrs) {
			const ip = addr.ip ?? 0;
			const port = addr.port ?? 0;
			if (ip && port) {
				session.host = ipv4ToString(ip);
				session.port = port;
			}
		}
	}
	console.log(`[Highway] session: ${session.host}:${session.port} sig=${session.sigSession.length}B`);
	return session;
}
function makeHighwayHead(uin, commandId, fileSize, offset, length, chunkMd5, fileMd5, sigSession, extend) {
	return protoEncode({
		msgBaseHead: {
			version: 1,
			uin,
			command: "PicUp.DataUp",
			seq: 0,
			retryTimes: 0,
			appId: HIGHWAY_APP_ID,
			dataFlag: 16,
			commandId
		},
		msgSegHead: {
			serviceId: 0,
			filesize: BigInt(fileSize),
			dataOffset: BigInt(offset),
			dataLength: length,
			retCode: 0,
			serviceTicket: sigSession,
			flag: 0,
			md5: chunkMd5,
			fileMd5,
			cacheAddr: 0,
			cachePort: 0
		},
		bytesReqExtendInfo: extend,
		timestamp: 0n,
		msgLoginSigHead: {
			loginSigType: 8,
			appId: HIGHWAY_APP_ID
		}
	}, ReqDataHighwayHeadSchema);
}
function buildHighwayExtend(uKey, msgInfo, ipv4s, sha1) {
	const msgInfoBody = msgInfo?.msgInfoBody ?? [];
	if (msgInfoBody.length === 0) throw new Error("upload response missing msg_info body");
	const first = msgInfoBody[0];
	const networkIpv4s = [];
	for (const ipv4 of ipv4s ?? []) {
		const ip = ipv4.outIp ?? 0;
		const port = ipv4.outPort ?? 0;
		if (ip && port) networkIpv4s.push({
			domain: {
				isEnable: true,
				ip: ipv4ToString(ip)
			},
			port
		});
	}
	return protoEncode({
		fileUuid: first?.index?.fileUuid ?? "",
		uKey,
		network: { ipv4s: networkIpv4s },
		msgInfoBody: msgInfoBody.map((b) => ({
			index: b.index,
			picture: b.picture,
			fileExist: b.fileExist,
			hashSum: b.hashSum
		})),
		blockSize: HIGHWAY_BLOCK_SIZE,
		hash: { fileSha1: [sha1] }
	}, NTV2RichMediaHighwayExtSchema);
}
function tcpConnect(host, port, timeoutMs = 1e4) {
	return new Promise((resolve, reject) => {
		const socket = net.createConnection({
			host,
			port
		}, () => resolve(socket));
		socket.setTimeout(timeoutMs);
		socket.on("timeout", () => {
			socket.destroy();
			reject(/* @__PURE__ */ new Error("TCP connect timeout"));
		});
		socket.on("error", reject);
	});
}
function socketWrite(socket, data) {
	return new Promise((resolve, reject) => {
		socket.write(data, (err) => err ? reject(err) : resolve());
	});
}
function readHttpResponseBody(socket) {
	return new Promise((resolve, reject) => {
		const chunks = [];
		let headerEnd = -1;
		let contentLength = 0;
		let totalNeeded = 0;
		const checkComplete = () => {
			const buf = Buffer.concat(chunks);
			if (headerEnd < 0) {
				const idx = buf.indexOf("\r\n\r\n");
				if (idx >= 0) {
					headerEnd = idx + 4;
					const clMatch = buf.subarray(0, headerEnd).toString("ascii").toLowerCase().match(/content-length:\s*(\d+)/);
					contentLength = clMatch ? parseInt(clMatch[1], 10) : 0;
					totalNeeded = headerEnd + contentLength;
				}
			}
			if (headerEnd >= 0 && buf.length >= totalNeeded) {
				socket.removeAllListeners("data");
				socket.removeAllListeners("error");
				resolve(new Uint8Array(buf.subarray(headerEnd, totalNeeded)));
			}
		};
		socket.on("data", (chunk) => {
			chunks.push(chunk);
			checkComplete();
		});
		socket.on("error", reject);
		socket.on("close", () => {
			const buf = Buffer.concat(chunks);
			if (headerEnd >= 0) resolve(new Uint8Array(buf.subarray(headerEnd)));
			else reject(/* @__PURE__ */ new Error("connection closed before response"));
		});
	});
}
async function httpPostFrame(socket, host, path, body) {
	const header = `POST ${path} HTTP/1.1\r\nHost: ${host}\r\nConnection: keep-alive\r\nAccept-Encoding: identity\r\nUser-Agent: Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2)\r\nContent-Length: ${body.length}\r\n\r\n`;
	await socketWrite(socket, Buffer.from(header, "ascii"));
	if (body.length > 0) await socketWrite(socket, body);
	return readHttpResponseBody(socket);
}
async function uploadHighwayHttp(bridge, session, commandId, bytes, fileMd5, extend) {
	const pathStr = `/cgi-bin/httpconn?htcmd=0x6FF0087&uin=${bridge.qqInfo.uin}`;
	const socket = await tcpConnect(session.host, session.port);
	try {
		let offset = 0;
		while (offset < bytes.length) {
			const chunkSize = Math.min(HIGHWAY_BLOCK_SIZE, bytes.length - offset);
			const chunk = bytes.subarray(offset, offset + chunkSize);
			const chunkMd5 = computeMd5(chunk);
			const frame = packHighwayFrame(makeHighwayHead(bridge.qqInfo.uin, commandId, bytes.length, offset, chunkSize, chunkMd5, fileMd5, session.sigSession, extend), chunk);
			const { head: respHead } = unpackHighwayFrame(await httpPostFrame(socket, session.host, pathStr, frame));
			const resp = protoDecode(respHead, RespDataHighwayHeadSchema);
			if (resp?.errorCode && resp.errorCode !== 0) throw new Error(`highway upload error_code=${resp.errorCode}`);
			offset += chunkSize;
			console.log(`[Highway] uploaded ${offset}/${bytes.length} bytes`);
		}
	} finally {
		socket.destroy();
	}
}
//#endregion
//#region src/bridge/highway/image-upload.ts
function loadImage(element) {
	return loadImageFromSource(element.url || element.fileId || "", element.fileName ?? "", element.subType ?? 0, element.summary ?? "");
}
async function loadImageFromSource(source, fileName, subType, summary) {
	const loaded = await loadBinarySource(source, "image");
	const hashes = computeHashes(loaded.bytes);
	const fmt = detectImageFormat(loaded.bytes);
	const ext = {
		1e3: ".jpg",
		1001: ".png",
		1002: ".webp",
		1005: ".bmp",
		2e3: ".gif"
	}[fmt.format] ?? ".jpg";
	let finalName = fileName || loaded.fileName;
	if (!finalName) finalName = hashes.md5Hex + ext;
	return {
		bytes: loaded.bytes,
		md5: hashes.md5,
		sha1: hashes.sha1,
		md5Hex: hashes.md5Hex,
		sha1Hex: hashes.sha1Hex,
		fileName: finalName,
		summary: summary || (subType === 0 ? "[image]" : "[sticker]"),
		subType,
		width: fmt.width,
		height: fmt.height,
		picFormat: fmt.format
	};
}
async function startImageUpload(bridge, isGroup, targetIdOrUid, image) {
	const body = {
		reqHead: {
			common: {
				requestId: 1,
				command: 100
			},
			scene: {
				requestType: 2,
				businessType: 1,
				sceneType: isGroup ? 2 : 1,
				...isGroup ? { group: { groupUin: Number(targetIdOrUid) } } : { c2c: {
					accountType: 2,
					targetUid: String(targetIdOrUid)
				} }
			},
			client: { agentType: 2 }
		},
		upload: {
			uploadInfo: [{
				fileInfo: {
					fileSize: image.bytes.length,
					fileHash: image.md5Hex,
					fileSha1: image.sha1Hex,
					fileName: image.fileName,
					type: {
						type: 1,
						picFormat: image.picFormat,
						videoFormat: 0,
						voiceFormat: 0
					},
					width: image.width,
					height: image.height,
					time: 0,
					original: 1
				},
				subFileType: 0
			}],
			tryFastUploadCompleted: true,
			srvSendMsg: false,
			clientRandomId: BigInt(Math.floor(Math.random() * 0x8000000000000000)),
			compatQmsgSceneType: isGroup ? 2 : 1,
			extBizInfo: {
				pic: {
					bizType: image.subType,
					textSummary: image.summary,
					...isGroup ? { reserveTroop: { subType: image.subType } } : { reserveC2c: { subType: image.subType } }
				},
				video: { bytesPbReserve: new Uint8Array(0) },
				ptt: {
					bytesReserve: new Uint8Array(0),
					bytesPbReserve: new Uint8Array(0),
					bytesGeneralFlags: new Uint8Array(0)
				}
			},
			clientSeq: 0,
			noNeedCompatMsg: false
		}
	};
	const oidbCmd = isGroup ? 4548 : 4549;
	const serviceCmd = isGroup ? "OidbSvcTrpcTcp.0x11c4_100" : "OidbSvcTrpcTcp.0x11c5_100";
	const baseSchema = makeOidbBaseSchema(NTV2UploadRichMediaReqSchema);
	const request = protoEncode({
		command: oidbCmd,
		subCommand: 100,
		errorCode: 0,
		body,
		errorMsg: "",
		reserved: 1
	}, baseSchema);
	const result = await bridge.sendRawPacket(serviceCmd, request);
	if (!result.success || !result.gotResponse || !result.responseData) throw new Error(result.errorMessage || "image upload request failed");
	const respBaseSchema = makeOidbBaseSchema(NTV2UploadRichMediaRespSchema);
	const resp = protoDecode(result.responseData, respBaseSchema);
	if (!resp) throw new Error("failed to decode upload response");
	if (resp.errorCode && resp.errorCode !== 0) throw new Error(`OIDB error ${resp.errorCode}: ${resp.errorMsg ?? ""}`);
	const uploadBody = resp.body;
	if (!uploadBody) throw new Error("upload response body missing");
	if (uploadBody.respHead?.retCode && uploadBody.respHead.retCode !== 0) throw new Error(uploadBody.respHead.message ?? "image upload failed");
	return uploadBody.upload;
}
function finalizeImageMsgInfo(upload, image) {
	if (!upload?.msgInfo) throw new Error("upload response missing msgInfo");
	const msgInfoBody = (upload.msgInfo.msgInfoBody ?? []).map((b) => ({
		index: b.index,
		picture: b.picture,
		fileExist: b.fileExist,
		hashSum: b.hashSum
	}));
	const extBizInfo = {};
	if (upload.msgInfo.extBizInfo?.pic) {
		extBizInfo.pic = { ...upload.msgInfo.extBizInfo.pic };
		extBizInfo.pic.bizType = extBizInfo.pic.bizType ?? image.subType;
		extBizInfo.pic.textSummary = extBizInfo.pic.textSummary ?? image.summary;
	} else extBizInfo.pic = {
		bizType: image.subType,
		textSummary: image.summary
	};
	if (upload.msgInfo.extBizInfo?.video) extBizInfo.video = upload.msgInfo.extBizInfo.video;
	if (upload.msgInfo.extBizInfo?.ptt) extBizInfo.ptt = upload.msgInfo.extBizInfo.ptt;
	if (upload.msgInfo.extBizInfo?.busiType !== void 0) extBizInfo.busiType = upload.msgInfo.extBizInfo.busiType;
	return protoEncode({
		msgInfoBody,
		extBizInfo
	}, EncodableMediaMsgInfoSchema);
}
/**
* Upload an image and return the encoded MsgInfo bytes to embed in a CommonElem.
*/
async function uploadImageMsgInfo(bridge, isGroup, targetIdOrUid, element) {
	const image = await loadImage(element);
	const upload = await startImageUpload(bridge, isGroup, targetIdOrUid, image);
	const uKey = upload?.uKey ?? "";
	if (uKey && upload?.msgInfo) {
		const session = await fetchHighwaySession(bridge);
		const extend = buildHighwayExtend(uKey, upload.msgInfo, upload.ipv4s ?? [], image.sha1);
		await uploadHighwayHttp(bridge, session, isGroup ? GROUP_IMAGE_CMD_ID : PRIVATE_IMAGE_CMD_ID, image.bytes, image.md5, extend);
	}
	return finalizeImageMsgInfo(upload, image);
}
//#endregion
//#region src/bridge/builders/element-builder.ts
function makeTextElem(text) {
	return { text: { str: text } };
}
function makeFaceElem(faceId) {
	return { face: { index: faceId } };
}
function makeMentionElem(element) {
	const mentionAll = element.uid === "all" || element.targetUin === 0;
	const extra = protoEncode({
		type: mentionAll ? 1 : 2,
		uin: mentionAll ? 0 : element.targetUin ?? 0,
		field5: 0,
		uid: mentionAll ? "all" : element.uid ?? ""
	}, MentionExtraSendSchema);
	return { text: {
		str: element.text || (mentionAll ? "@全体成员 " : `@${element.targetUin} `),
		pbReserve: extra
	} };
}
function makeReplyElem(element) {
	const srcMsg = { origSeqs: [element.replySeq & 4294967295] };
	if (element.replySenderUin) srcMsg.senderUin = BigInt(element.replySenderUin);
	if (element.replyTime) srcMsg.time = element.replyTime;
	return { srcMsg };
}
function makeJsonElem(element) {
	const content = element.text ?? "";
	const payload = new Uint8Array(content.length + 1);
	payload[0] = 0;
	const encoded = new TextEncoder().encode(content);
	payload.set(encoded, 1);
	return { richMsg: {
		serviceId: 1,
		template1: payload
	} };
}
function makeXmlElem(element) {
	const content = element.text ?? "";
	const payload = new Uint8Array(content.length + 1);
	payload[0] = 0;
	const encoded = new TextEncoder().encode(content);
	payload.set(encoded, 1);
	return { richMsg: {
		serviceId: element.subType === 0 ? 35 : element.subType ?? 35,
		template1: payload
	} };
}
function makeMarkdownElem(element) {
	return { commonElem: {
		serviceType: 45,
		pbElem: protoEncode({ content: element.text ?? "" }, MarkdownDataSchema),
		businessType: 1
	} };
}
function makeForwardElem(element) {
	const resId = (element.resId ?? "").trim();
	if (!resId) throw new Error("forward resId is required");
	const xml = `<?xml version="1.0" encoding="utf-8"?><msg templateID="1" action="viewMultiMsg" serviceID="35" brief="[聊天记录]" m_resid="${resId}" m_fileName="${resId}" actionData="${resId}" tSum="2" sourceMsgId="0" flag="3" adverSign="0" multiMsgFlag="0"><item layout="1"><title size="34" color="#000000">聊天记录</title><title size="26" color="#777777">查看转发消息</title><summary size="26" color="#808080">查看转发消息</summary></item><source name="" icon="" action="" appid="-1"/></msg>`;
	const encodedXml = new TextEncoder().encode(xml);
	const payload = new Uint8Array(encodedXml.length + 1);
	payload[0] = 0;
	payload.set(encodedXml, 1);
	return { richMsg: {
		serviceId: 35,
		template1: payload
	} };
}
async function makeImageElem(ctx, element) {
	const isGroup = ctx.groupId !== void 0;
	const targetIdOrUid = isGroup ? ctx.groupId : ctx.userUid ?? "";
	if (!isGroup && !targetIdOrUid) throw new Error("private image target uid is missing");
	return { commonElem: {
		serviceType: 48,
		pbElem: await uploadImageMsgInfo(ctx.bridge, isGroup, targetIdOrUid, element),
		businessType: isGroup ? 20 : 10
	} };
}
/**
* Build proto Elem objects from an array of MessageElements.
* Supports: text, face, at, reply, json, xml, markdown, image.
* Image elements trigger highway upload via the SendContext.
*/
async function buildSendElems(elements, ctx) {
	const result = [];
	for (const elem of elements) switch (elem.type) {
		case "text":
			if (elem.text) result.push(makeTextElem(elem.text));
			break;
		case "face":
			if (elem.faceId !== void 0) result.push(makeFaceElem(elem.faceId));
			break;
		case "at":
			result.push(makeMentionElem(elem));
			break;
		case "reply":
			if (elem.replySeq) result.push(makeReplyElem(elem));
			break;
		case "json":
			if (elem.text) result.push(makeJsonElem(elem));
			break;
		case "xml":
			if (elem.text) result.push(makeXmlElem(elem));
			break;
		case "markdown":
			if (elem.text) result.push(makeMarkdownElem(elem));
			break;
		case "image":
			if (ctx) result.push(await makeImageElem(ctx, elem));
			else console.warn("[ElemBuilder] image send requires SendContext");
			break;
		case "forward":
			if (elem.resId) result.push(makeForwardElem(elem));
			break;
		case "record":
		case "video":
			console.warn(`[ElemBuilder] ${elem.type} send not yet implemented`);
			break;
		default:
			console.warn(`[ElemBuilder] unsupported element type for send: ${elem.type}`);
			break;
	}
	return result;
}
//#endregion
//#region src/bridge/bridge-oidb.ts
/**
* Build a raw OIDB request buffer (base envelope wrapping a typed body).
*/
function makeOidbRequest(command, subCommand, body, bodySchema, isUid = false) {
	const baseSchema = makeOidbBaseSchema(bodySchema);
	return protoEncode({
		command,
		subCommand,
		errorCode: 0,
		body,
		errorMsg: "",
		reserved: isUid ? 1 : 0
	}, baseSchema);
}
/**
* Send an OIDB packet and verify it succeeded (no decode of body).
*/
async function sendOidbAndCheck(bridge, serviceCmd, command, subCommand, body, bodySchema, isUid = false) {
	const request = makeOidbRequest(command, subCommand, body, bodySchema, isUid);
	const result = await bridge.sendRawPacket(serviceCmd, request);
	if (!result.success) throw new Error(result.errorMessage || "packet send failed");
	if (!result.gotResponse) throw new Error(result.errorMessage || "no response");
	if (result.responseData && result.responseData.length > 0) {
		const emptyBase = makeOidbBaseSchema({ _dummy: {
			field: 99,
			type: "uint32"
		} });
		const resp = protoDecode(result.responseData, emptyBase);
		if (resp && resp.errorCode && resp.errorCode !== 0) throw new Error(`OIDB error ${resp.errorCode}: ${resp.errorMsg ?? ""}`);
	}
}
/**
* Send an OIDB packet and decode the response body with the given schema.
*/
async function sendOidbAndDecode(bridge, serviceCmd, command, subCommand, body, bodySchema, responseSchema, isUid = false) {
	const request = makeOidbRequest(command, subCommand, body, bodySchema, isUid);
	const result = await bridge.sendRawPacket(serviceCmd, request);
	if (!result.success) throw new Error(result.errorMessage || "packet send failed");
	if (!result.gotResponse || !result.responseData) throw new Error(result.errorMessage || "no response");
	const baseSchema = makeOidbBaseSchema(responseSchema);
	const resp = protoDecode(result.responseData, baseSchema);
	if (!resp) throw new Error("failed to decode OIDB response");
	if (resp.errorCode && resp.errorCode !== 0) throw new Error(`OIDB error ${resp.errorCode}: ${resp.errorMsg ?? ""}`);
	return resp.body;
}
/**
* Resolve a UIN to a UID string, using cache or fetching as needed.
* Mirrors C++ resolve_user_uid_for_action.
*/
async function resolveUserUid(bridge, uin, groupId) {
	if (groupId !== void 0) {
		const uid = bridge.qqInfo.findUidByUinInGroup(groupId, uin);
		if (uid) return uid;
		try {
			await bridge.fetchGroupMemberList(groupId);
		} catch {}
		const uid2 = bridge.qqInfo.findUidByUinInGroup(groupId, uin);
		if (uid2) return uid2;
	}
	const uid = bridge.qqInfo.findUidByUin(uin);
	if (uid) return uid;
	const profile = await bridge.fetchUserProfile(uin);
	if (profile.uid) return profile.uid;
	throw new Error(`failed to resolve UID for UIN ${uin}`);
}
var OidbMuteMemberSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	type: {
		field: 2,
		type: "uint32"
	},
	body: {
		field: 3,
		type: "message",
		schema: {
			targetUid: {
				field: 1,
				type: "string"
			},
			duration: {
				field: 2,
				type: "uint32"
			}
		}
	}
};
var OidbMuteAllSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	muteState: {
		field: 2,
		type: "message",
		schema: { state: {
			field: 17,
			type: "uint32"
		} }
	}
};
var OidbKickMemberSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	targetUid: {
		field: 3,
		type: "string"
	},
	rejectAddRequest: {
		field: 4,
		type: "bool"
	},
	reason: {
		field: 5,
		type: "string"
	}
};
var OidbLeaveGroupSchema = { groupUin: {
	field: 1,
	type: "uint32"
} };
var OidbFriendRequestActionSchema = {
	accept: {
		field: 1,
		type: "uint32"
	},
	targetUid: {
		field: 2,
		type: "string"
	}
};
var OidbDeleteFriendSchema = { field1: {
	field: 1,
	type: "message",
	schema: {
		targetUid: {
			field: 1,
			type: "string"
		},
		field2: {
			field: 2,
			type: "message",
			schema: {
				field1: {
					field: 1,
					type: "uint32"
				},
				field2: {
					field: 2,
					type: "uint32"
				},
				field3: {
					field: 3,
					type: "message",
					schema: {
						field1: {
							field: 1,
							type: "uint32"
						},
						field2: {
							field: 2,
							type: "uint32"
						},
						field3: {
							field: 3,
							type: "uint32"
						}
					}
				}
			}
		},
		block: {
			field: 3,
			type: "bool"
		},
		field4: {
			field: 4,
			type: "bool"
		}
	}
} };
var OidbGroupRequestActionSchema = {
	accept: {
		field: 1,
		type: "uint32"
	},
	body: {
		field: 2,
		type: "message",
		schema: {
			sequence: {
				field: 1,
				type: "uint64"
			},
			eventType: {
				field: 2,
				type: "uint32"
			},
			groupUin: {
				field: 3,
				type: "uint32"
			},
			message: {
				field: 4,
				type: "string"
			}
		}
	}
};
var OidbPokeSchema = {
	uin: {
		field: 1,
		type: "uint32"
	},
	groupUin: {
		field: 2,
		type: "uint32"
	},
	friendUin: {
		field: 5,
		type: "uint32"
	},
	ext: {
		field: 6,
		type: "uint32"
	}
};
var OidbEssenceSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	sequence: {
		field: 2,
		type: "uint32"
	},
	random: {
		field: 3,
		type: "uint32"
	}
};
var OidbSetAdminSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	uid: {
		field: 2,
		type: "string"
	},
	isAdmin: {
		field: 3,
		type: "bool"
	}
};
var OidbRenameMemberSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	body: {
		field: 2,
		type: "message",
		schema: {
			targetUid: {
				field: 1,
				type: "string"
			},
			targetName: {
				field: 2,
				type: "string"
			}
		}
	}
};
var OidbRenameGroupSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	body: {
		field: 2,
		type: "message",
		schema: { targetName: {
			field: 1,
			type: "string"
		} }
	}
};
var OidbSpecialTitleSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	body: {
		field: 2,
		type: "message",
		schema: {
			targetUid: {
				field: 1,
				type: "string"
			},
			specialTitle: {
				field: 5,
				type: "string"
			},
			expireTime: {
				field: 6,
				type: "int32"
			}
		}
	}
};
var OidbLikeSchema = {
	targetUin: {
		field: 1,
		type: "uint32"
	},
	count: {
		field: 2,
		type: "uint32"
	}
};
var OidbGroupRequestListSchema = {
	count: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	}
};
var OidbUserInfoRequestSchema = {
	uin: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	},
	keys: {
		field: 3,
		type: "repeated_message",
		schema: { key: {
			field: 1,
			type: "uint32"
		} }
	}
};
var OidbUserInfoResponseSchema = { body: {
	field: 1,
	type: "message",
	schema: {
		uid: {
			field: 1,
			type: "string"
		},
		properties: {
			field: 2,
			type: "message",
			schema: {
				numberProperties: {
					field: 1,
					type: "repeated_message",
					schema: {
						number1: {
							field: 1,
							type: "uint32"
						},
						number2: {
							field: 2,
							type: "uint32"
						}
					}
				},
				bytesProperties: {
					field: 2,
					type: "repeated_message",
					schema: {
						code: {
							field: 1,
							type: "uint32"
						},
						value: {
							field: 2,
							type: "bytes"
						}
					}
				}
			}
		},
		uin: {
			field: 3,
			type: "uint32"
		}
	}
} };
var AvatarInfoSchema = { url: {
	field: 5,
	type: "string"
} };
var OidbFriendListRequestSchema = {
	friendCount: {
		field: 2,
		type: "uint32"
	},
	field4: {
		field: 4,
		type: "uint32"
	},
	nextUin: {
		field: 5,
		type: "message",
		schema: { uin: {
			field: 1,
			type: "uint32"
		} }
	},
	field6: {
		field: 6,
		type: "uint32"
	},
	field7: {
		field: 7,
		type: "uint32"
	},
	body: {
		field: 10001,
		type: "repeated_message",
		schema: {
			type: {
				field: 1,
				type: "uint32"
			},
			number: {
				field: 2,
				type: "message",
				schema: { numbers: {
					field: 1,
					type: "repeated_uint32"
				} }
			}
		}
	},
	field10002: {
		field: 10002,
		type: "repeated_uint32"
	},
	field10003: {
		field: 10003,
		type: "uint32"
	}
};
var OidbGroupListRequestSchema = { config: {
	field: 1,
	type: "message",
	schema: {
		config1: {
			field: 1,
			type: "message",
			schema: {
				groupOwner: {
					field: 1,
					type: "bool"
				},
				field2: {
					field: 2,
					type: "bool"
				},
				memberMax: {
					field: 3,
					type: "bool"
				},
				memberCount: {
					field: 4,
					type: "bool"
				},
				groupName: {
					field: 5,
					type: "bool"
				},
				field8: {
					field: 8,
					type: "bool"
				},
				field9: {
					field: 9,
					type: "bool"
				},
				field10: {
					field: 10,
					type: "bool"
				},
				field11: {
					field: 11,
					type: "bool"
				},
				field12: {
					field: 12,
					type: "bool"
				},
				field13: {
					field: 13,
					type: "bool"
				},
				field14: {
					field: 14,
					type: "bool"
				},
				field15: {
					field: 15,
					type: "bool"
				},
				field16: {
					field: 16,
					type: "bool"
				},
				field17: {
					field: 17,
					type: "bool"
				},
				field18: {
					field: 18,
					type: "bool"
				},
				question: {
					field: 19,
					type: "bool"
				},
				field20: {
					field: 20,
					type: "bool"
				},
				field22: {
					field: 22,
					type: "bool"
				},
				field23: {
					field: 23,
					type: "bool"
				},
				field24: {
					field: 24,
					type: "bool"
				},
				field25: {
					field: 25,
					type: "bool"
				},
				field26: {
					field: 26,
					type: "bool"
				},
				field27: {
					field: 27,
					type: "bool"
				},
				field28: {
					field: 28,
					type: "bool"
				},
				field29: {
					field: 29,
					type: "bool"
				},
				field30: {
					field: 30,
					type: "bool"
				},
				field31: {
					field: 31,
					type: "bool"
				},
				field32: {
					field: 32,
					type: "bool"
				},
				field5001: {
					field: 5001,
					type: "bool"
				},
				field5002: {
					field: 5002,
					type: "bool"
				},
				field5003: {
					field: 5003,
					type: "bool"
				}
			}
		},
		config2: {
			field: 2,
			type: "message",
			schema: {
				field1: {
					field: 1,
					type: "bool"
				},
				field2: {
					field: 2,
					type: "bool"
				},
				field3: {
					field: 3,
					type: "bool"
				},
				field4: {
					field: 4,
					type: "bool"
				},
				field5: {
					field: 5,
					type: "bool"
				},
				field6: {
					field: 6,
					type: "bool"
				},
				field7: {
					field: 7,
					type: "bool"
				},
				field8: {
					field: 8,
					type: "bool"
				}
			}
		},
		config3: {
			field: 3,
			type: "message",
			schema: {
				field5: {
					field: 5,
					type: "bool"
				},
				field6: {
					field: 6,
					type: "bool"
				}
			}
		}
	}
} };
var OidbGroupMemberListRequestSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	},
	field3: {
		field: 3,
		type: "uint32"
	},
	body: {
		field: 4,
		type: "message",
		schema: {
			memberName: {
				field: 10,
				type: "bool"
			},
			memberCard: {
				field: 11,
				type: "bool"
			},
			level: {
				field: 12,
				type: "bool"
			},
			field13: {
				field: 13,
				type: "bool"
			},
			field16: {
				field: 16,
				type: "bool"
			},
			specialTitle: {
				field: 17,
				type: "bool"
			},
			field18: {
				field: 18,
				type: "bool"
			},
			field20: {
				field: 20,
				type: "bool"
			},
			field21: {
				field: 21,
				type: "bool"
			},
			joinTimestamp: {
				field: 100,
				type: "bool"
			},
			lastMsgTimestamp: {
				field: 101,
				type: "bool"
			},
			shutUpTimestamp: {
				field: 102,
				type: "bool"
			},
			field103: {
				field: 103,
				type: "bool"
			},
			field104: {
				field: 104,
				type: "bool"
			},
			field105: {
				field: 105,
				type: "bool"
			},
			field106: {
				field: 106,
				type: "bool"
			},
			permission: {
				field: 107,
				type: "bool"
			},
			field200: {
				field: 200,
				type: "bool"
			},
			field201: {
				field: 201,
				type: "bool"
			}
		}
	},
	token: {
		field: 15,
		type: "string"
	}
};
var GroupRecallRequestSchema = {
	type: {
		field: 1,
		type: "uint32"
	},
	groupUin: {
		field: 2,
		type: "uint32"
	},
	info: {
		field: 3,
		type: "message",
		schema: {
			sequence: {
				field: 1,
				type: "uint32"
			},
			random: {
				field: 2,
				type: "uint32"
			},
			field3: {
				field: 3,
				type: "uint32"
			}
		}
	},
	settings: {
		field: 4,
		type: "message",
		schema: { field1: {
			field: 1,
			type: "uint32"
		} }
	}
};
var C2CRecallRequestSchema = {
	type: {
		field: 1,
		type: "uint32"
	},
	targetUid: {
		field: 3,
		type: "string"
	},
	info: {
		field: 4,
		type: "message",
		schema: {
			clientSequence: {
				field: 1,
				type: "uint32"
			},
			random: {
				field: 2,
				type: "uint32"
			},
			messageId: {
				field: 3,
				type: "uint64"
			},
			timestamp: {
				field: 4,
				type: "uint32"
			},
			field5: {
				field: 5,
				type: "uint32"
			},
			messageSequence: {
				field: 6,
				type: "uint32"
			}
		}
	},
	settings: {
		field: 5,
		type: "message",
		schema: {
			field1: {
				field: 1,
				type: "bool"
			},
			field2: {
				field: 2,
				type: "bool"
			}
		}
	},
	field6: {
		field: 6,
		type: "bool"
	}
};
var OidbGroupReactionSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	sequence: {
		field: 2,
		type: "uint32"
	},
	code: {
		field: 3,
		type: "string"
	}
};
var OidbGroupFileViewReqSchema = { list: {
	field: 2,
	type: "message",
	schema: {
		groupUin: {
			field: 1,
			type: "uint32"
		},
		appId: {
			field: 2,
			type: "uint32"
		},
		targetDirectory: {
			field: 3,
			type: "string"
		},
		fileCount: {
			field: 5,
			type: "uint32"
		},
		sortBy: {
			field: 9,
			type: "uint32"
		},
		startIndex: {
			field: 13,
			type: "uint32"
		},
		field17: {
			field: 17,
			type: "uint32"
		},
		field18: {
			field: 18,
			type: "uint32"
		}
	}
} };
var OidbGroupFileViewRespSchema = { list: {
	field: 2,
	type: "message",
	schema: {
		retCode: {
			field: 1,
			type: "uint32"
		},
		retMsg: {
			field: 2,
			type: "string"
		},
		clientWording: {
			field: 3,
			type: "string"
		},
		isEnd: {
			field: 4,
			type: "bool"
		},
		items: {
			field: 5,
			type: "repeated_message",
			schema: {
				type: {
					field: 1,
					type: "uint32"
				},
				folderInfo: {
					field: 2,
					type: "message",
					schema: {
						folderId: {
							field: 1,
							type: "string"
						},
						parentDirectoryId: {
							field: 2,
							type: "string"
						},
						folderName: {
							field: 3,
							type: "string"
						},
						createTime: {
							field: 4,
							type: "uint32"
						},
						modifiedTime: {
							field: 5,
							type: "uint32"
						},
						creatorUin: {
							field: 6,
							type: "uint32"
						},
						creatorName: {
							field: 7,
							type: "string"
						},
						totalFileCount: {
							field: 8,
							type: "uint32"
						}
					}
				},
				fileInfo: {
					field: 3,
					type: "message",
					schema: {
						fileId: {
							field: 1,
							type: "string"
						},
						fileName: {
							field: 2,
							type: "string"
						},
						fileSize: {
							field: 3,
							type: "uint64"
						},
						busId: {
							field: 4,
							type: "uint32"
						},
						uploadedTime: {
							field: 6,
							type: "uint32"
						},
						expireTime: {
							field: 7,
							type: "uint32"
						},
						modifiedTime: {
							field: 8,
							type: "uint32"
						},
						downloadedTimes: {
							field: 9,
							type: "uint32"
						},
						uploaderName: {
							field: 14,
							type: "string"
						},
						uploaderUin: {
							field: 15,
							type: "uint32"
						},
						parentDirectory: {
							field: 16,
							type: "string"
						}
					}
				}
			}
		}
	}
} };
var OidbGroupFileReqSchema = {
	file: {
		field: 1,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			appId: {
				field: 2,
				type: "uint32"
			},
			busId: {
				field: 3,
				type: "uint32"
			},
			entrance: {
				field: 4,
				type: "uint32"
			},
			targetDirectory: {
				field: 5,
				type: "string"
			},
			fileName: {
				field: 6,
				type: "string"
			},
			localDirectory: {
				field: 7,
				type: "string"
			},
			fileSize: {
				field: 8,
				type: "uint64"
			},
			fileSha1: {
				field: 9,
				type: "bytes"
			},
			fileSha3: {
				field: 10,
				type: "bytes"
			},
			fileMd5: {
				field: 11,
				type: "bytes"
			},
			field15: {
				field: 15,
				type: "bool"
			}
		}
	},
	download: {
		field: 3,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			appId: {
				field: 2,
				type: "uint32"
			},
			busId: {
				field: 3,
				type: "uint32"
			},
			fileId: {
				field: 4,
				type: "string"
			}
		}
	},
	delete: {
		field: 4,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			busId: {
				field: 3,
				type: "uint32"
			},
			fileId: {
				field: 5,
				type: "string"
			}
		}
	},
	move: {
		field: 6,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			appId: {
				field: 2,
				type: "uint32"
			},
			busId: {
				field: 3,
				type: "uint32"
			},
			fileId: {
				field: 4,
				type: "string"
			},
			parentDirectory: {
				field: 5,
				type: "string"
			},
			targetDirectory: {
				field: 6,
				type: "string"
			}
		}
	}
};
var OidbGroupFileUploadRespSchema = {
	retCode: {
		field: 1,
		type: "int32"
	},
	retMsg: {
		field: 2,
		type: "string"
	},
	clientWording: {
		field: 3,
		type: "string"
	},
	uploadIp: {
		field: 4,
		type: "string"
	},
	serverDns: {
		field: 5,
		type: "string"
	},
	busId: {
		field: 6,
		type: "int32"
	},
	fileId: {
		field: 7,
		type: "string"
	},
	checkKey: {
		field: 8,
		type: "bytes"
	},
	fileKey: {
		field: 9,
		type: "bytes"
	},
	boolFileExist: {
		field: 10,
		type: "bool"
	},
	uploadPort: {
		field: 14,
		type: "uint32"
	}
};
var OidbGroupFileDownloadRespSchema = {
	retCode: {
		field: 1,
		type: "uint32"
	},
	retMsg: {
		field: 2,
		type: "string"
	},
	clientWording: {
		field: 3,
		type: "string"
	},
	downloadIp: {
		field: 4,
		type: "string"
	},
	downloadDns: {
		field: 5,
		type: "string"
	},
	downloadUrl: {
		field: 6,
		type: "bytes"
	},
	saveFileName: {
		field: 11,
		type: "string"
	}
};
var OidbGroupFileRetRespSchema = {
	retCode: {
		field: 1,
		type: "uint32"
	},
	retMsg: {
		field: 2,
		type: "string"
	},
	clientWording: {
		field: 3,
		type: "string"
	}
};
var OidbGroupFileRespSchema = {
	upload: {
		field: 1,
		type: "message",
		schema: OidbGroupFileUploadRespSchema
	},
	download: {
		field: 3,
		type: "message",
		schema: OidbGroupFileDownloadRespSchema
	},
	delete: {
		field: 4,
		type: "message",
		schema: OidbGroupFileRetRespSchema
	},
	move: {
		field: 6,
		type: "message",
		schema: OidbGroupFileRetRespSchema
	}
};
var OidbGroupFileFolderReqSchema = {
	create: {
		field: 1,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			rootDirectory: {
				field: 3,
				type: "string"
			},
			folderName: {
				field: 4,
				type: "string"
			}
		}
	},
	delete: {
		field: 2,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			folderId: {
				field: 3,
				type: "string"
			}
		}
	},
	rename: {
		field: 3,
		type: "message",
		schema: {
			groupUin: {
				field: 1,
				type: "uint32"
			},
			folderId: {
				field: 3,
				type: "string"
			},
			newFolderName: {
				field: 4,
				type: "string"
			}
		}
	}
};
var OidbGroupFileFolderRetRespSchema = {
	retcode: {
		field: 1,
		type: "uint32"
	},
	retMsg: {
		field: 2,
		type: "string"
	},
	clientWording: {
		field: 3,
		type: "string"
	}
};
var OidbGroupFileFolderRespSchema = {
	create: {
		field: 1,
		type: "message",
		schema: OidbGroupFileFolderRetRespSchema
	},
	delete: {
		field: 2,
		type: "message",
		schema: OidbGroupFileFolderRetRespSchema
	},
	rename: {
		field: 3,
		type: "message",
		schema: OidbGroupFileFolderRetRespSchema
	}
};
var OidbPrivateFileDownloadReqSchema = {
	subCommand: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	},
	body: {
		field: 14,
		type: "message",
		schema: {
			receiverUid: {
				field: 10,
				type: "string"
			},
			fileUuid: {
				field: 20,
				type: "string"
			},
			type: {
				field: 30,
				type: "uint32"
			},
			fileHash: {
				field: 60,
				type: "string"
			},
			t2: {
				field: 601,
				type: "uint32"
			}
		}
	},
	field101: {
		field: 101,
		type: "uint32"
	},
	field102: {
		field: 102,
		type: "uint32"
	},
	field200: {
		field: 200,
		type: "uint32"
	},
	field99999: {
		field: 99999,
		type: "bytes"
	}
};
var OidbPrivateFileDownloadRespSchema = { body: {
	field: 14,
	type: "message",
	schema: {
		state: {
			field: 20,
			type: "string"
		},
		result: {
			field: 30,
			type: "message",
			schema: {
				server: {
					field: 20,
					type: "string"
				},
				port: {
					field: 40,
					type: "uint32"
				},
				url: {
					field: 50,
					type: "string"
				}
			}
		}
	}
} };
var OidbPrivateFileUploadReqSchema = {
	command: {
		field: 1,
		type: "uint32"
	},
	seq: {
		field: 2,
		type: "int32"
	},
	upload: {
		field: 19,
		type: "message",
		schema: {
			senderUid: {
				field: 10,
				type: "string"
			},
			receiverUid: {
				field: 20,
				type: "string"
			},
			fileSize: {
				field: 30,
				type: "uint32"
			},
			fileName: {
				field: 40,
				type: "string"
			},
			md510MCheckSum: {
				field: 50,
				type: "bytes"
			},
			sha1CheckSum: {
				field: 60,
				type: "bytes"
			},
			localPath: {
				field: 70,
				type: "string"
			},
			md5CheckSum: {
				field: 110,
				type: "bytes"
			},
			sha3CheckSum: {
				field: 120,
				type: "bytes"
			}
		}
	},
	businessId: {
		field: 101,
		type: "int32"
	},
	clientType: {
		field: 102,
		type: "int32"
	},
	flagSupportMediaPlatform: {
		field: 200,
		type: "int32"
	}
};
var OidbPrivateFileUploadRespSchema = { upload: {
	field: 19,
	type: "message",
	schema: {
		retCode: {
			field: 10,
			type: "int32"
		},
		retMsg: {
			field: 20,
			type: "string"
		},
		uploadIp: {
			field: 60,
			type: "string"
		},
		uploadPort: {
			field: 80,
			type: "uint32"
		},
		uuid: {
			field: 90,
			type: "string"
		},
		uploadKey: {
			field: 100,
			type: "bytes"
		},
		boolFileExist: {
			field: 110,
			type: "bool"
		},
		fileAddon: {
			field: 200,
			type: "string"
		},
		mediaPlatformUploadKey: {
			field: 220,
			type: "bytes"
		}
	}
} };
var NTV2CommonHeadSchema = {
	requestId: {
		field: 1,
		type: "uint32"
	},
	command: {
		field: 2,
		type: "uint32"
	}
};
var NTV2RichMediaReqSchema = {
	reqHead: {
		field: 1,
		type: "message",
		schema: {
			common: {
				field: 1,
				type: "message",
				schema: NTV2CommonHeadSchema
			},
			scene: {
				field: 2,
				type: "message",
				schema: {
					requestType: {
						field: 101,
						type: "uint32"
					},
					businessType: {
						field: 102,
						type: "uint32"
					},
					sceneType: {
						field: 200,
						type: "uint32"
					},
					c2c: {
						field: 201,
						type: "message",
						schema: {
							accountType: {
								field: 1,
								type: "uint32"
							},
							targetUid: {
								field: 2,
								type: "string"
							}
						}
					},
					group: {
						field: 202,
						type: "message",
						schema: { groupUin: {
							field: 1,
							type: "uint32"
						} }
					}
				}
			},
			client: {
				field: 3,
				type: "message",
				schema: { agentType: {
					field: 1,
					type: "uint32"
				} }
			}
		}
	},
	download: {
		field: 3,
		type: "message",
		schema: {
			node: {
				field: 1,
				type: "message",
				schema: {
					info: {
						field: 1,
						type: "message",
						schema: {
							fileSize: {
								field: 1,
								type: "uint32"
							},
							fileHash: {
								field: 2,
								type: "string"
							},
							fileSha1: {
								field: 3,
								type: "string"
							},
							fileName: {
								field: 4,
								type: "string"
							},
							type: {
								field: 5,
								type: "message",
								schema: {
									type: {
										field: 1,
										type: "uint32"
									},
									picFormat: {
										field: 2,
										type: "uint32"
									},
									videoFormat: {
										field: 3,
										type: "uint32"
									},
									voiceFormat: {
										field: 4,
										type: "uint32"
									}
								}
							},
							width: {
								field: 6,
								type: "uint32"
							},
							height: {
								field: 7,
								type: "uint32"
							},
							time: {
								field: 8,
								type: "uint32"
							},
							original: {
								field: 9,
								type: "uint32"
							}
						}
					},
					fileUuid: {
						field: 2,
						type: "string"
					},
					storeId: {
						field: 3,
						type: "uint32"
					},
					uploadTime: {
						field: 4,
						type: "uint32"
					},
					ttl: {
						field: 5,
						type: "uint32"
					},
					subType: {
						field: 6,
						type: "uint32"
					}
				}
			},
			download: {
				field: 2,
				type: "message",
				schema: { video: {
					field: 2,
					type: "message",
					schema: {
						busiType: {
							field: 1,
							type: "uint32"
						},
						sceneType: {
							field: 2,
							type: "uint32"
						},
						subBusiType: {
							field: 3,
							type: "uint32"
						}
					}
				} }
			}
		}
	},
	downloadRkey: {
		field: 4,
		type: "message",
		schema: { types: {
			field: 1,
			type: "repeated_uint32"
		} }
	}
};
var NTV2RichMediaRespSchema = {
	respHead: {
		field: 1,
		type: "message",
		schema: {
			common: {
				field: 1,
				type: "message",
				schema: NTV2CommonHeadSchema
			},
			retCode: {
				field: 2,
				type: "uint32"
			},
			message: {
				field: 3,
				type: "string"
			}
		}
	},
	download: {
		field: 3,
		type: "message",
		schema: {
			rKeyParam: {
				field: 1,
				type: "string"
			},
			rKeyTtlSecond: {
				field: 2,
				type: "uint32"
			},
			info: {
				field: 3,
				type: "message",
				schema: {
					domain: {
						field: 1,
						type: "string"
					},
					urlPath: {
						field: 2,
						type: "string"
					},
					httpsPort: {
						field: 3,
						type: "uint32"
					}
				}
			},
			rKeyCreateTime: {
				field: 4,
				type: "uint32"
			}
		}
	},
	downloadRkey: {
		field: 4,
		type: "message",
		schema: { rkeys: {
			field: 1,
			type: "repeated_message",
			schema: {
				rkey: {
					field: 1,
					type: "string"
				},
				rkeyTtlSec: {
					field: 2,
					type: "uint64"
				},
				storeId: {
					field: 3,
					type: "uint32"
				},
				rkeyCreateTime: {
					field: 4,
					type: "uint32"
				},
				type: {
					field: 5,
					type: "uint32"
				}
			}
		} }
	}
};
var OidbSetFriendRemarkSchema = {
	targetUid: {
		field: 1,
		type: "string"
	},
	remark: {
		field: 2,
		type: "string"
	}
};
var OidbGroupFileCountReqSchema = {
	groupUin: {
		field: 1,
		type: "uint32"
	},
	appId: {
		field: 2,
		type: "uint32"
	},
	busId: {
		field: 3,
		type: "uint32"
	}
};
var OidbGroupFileCountRespSchema = {
	fileCount: {
		field: 1,
		type: "uint32"
	},
	maxCount: {
		field: 2,
		type: "uint32"
	},
	isEnd: {
		field: 3,
		type: "bool"
	}
};
var OidbGroupFileCountViewReqSchema = { count: {
	field: 3,
	type: "message",
	schema: OidbGroupFileCountReqSchema
} };
var OidbGroupFileCountViewRespSchema = { count: {
	field: 3,
	type: "message",
	schema: OidbGroupFileCountRespSchema
} };
//#endregion
//#region src/bridge/bridge-contacts.ts
function buildFriendProperties(raw) {
	const props = /* @__PURE__ */ new Map();
	for (const additional of raw.additional ?? []) {
		if ((additional.type ?? 0) !== 1 || !additional.layer1) continue;
		for (const property of additional.layer1.properties ?? []) props.set(property.code ?? 0, property.value ?? "");
	}
	return props;
}
function permissionToRole(permission) {
	switch (permission) {
		case 1: return "owner";
		case 2: return "admin";
		default: return "member";
	}
}
async function fetchFriendList(bridge) {
	const friends = [];
	let nextUin = null;
	do {
		const body = {
			friendCount: 300,
			field4: 0,
			field6: 1,
			field7: 2147483647,
			body: [{
				type: 1,
				number: { numbers: [
					103,
					102,
					20002,
					27394
				] }
			}, {
				type: 4,
				number: { numbers: [
					100,
					101,
					102
				] }
			}],
			field10002: [
				13578,
				13579,
				13573,
				13572,
				13568
			],
			field10003: 4051
		};
		if (nextUin !== null) body.nextUin = { uin: nextUin };
		const resp = await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0xfd4_1", 4052, 1, body, OidbFriendListRequestSchema, OidbSvcTrpcTcp0xFD4_1ResponseSchema);
		if (resp?.friends) for (const raw of resp.friends) {
			const props = buildFriendProperties(raw);
			friends.push({
				uin: raw.uin ?? 0,
				uid: raw.uid ?? "",
				nickname: props.get(20002) ?? String(raw.uin ?? 0),
				remark: props.get(103) ?? ""
			});
		}
		nextUin = resp?.next?.uin ?? null;
		if (nextUin === 0) nextUin = null;
	} while (nextUin !== null);
	bridge.qqInfo.setFriends(friends);
	return friends;
}
async function fetchGroupList(bridge) {
	const allTrue = true;
	const resp = await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0xfe5_2", 4069, 2, { config: {
		config1: {
			groupOwner: allTrue,
			field2: allTrue,
			memberMax: allTrue,
			memberCount: allTrue,
			groupName: allTrue,
			field8: allTrue,
			field9: allTrue,
			field10: allTrue,
			field11: allTrue,
			field12: allTrue,
			field13: allTrue,
			field14: allTrue,
			field15: allTrue,
			field16: allTrue,
			field17: allTrue,
			field18: allTrue,
			question: allTrue,
			field20: allTrue,
			field22: allTrue,
			field23: allTrue,
			field24: allTrue,
			field25: allTrue,
			field26: allTrue,
			field27: allTrue,
			field28: allTrue,
			field29: allTrue,
			field30: allTrue,
			field31: allTrue,
			field32: allTrue,
			field5001: allTrue,
			field5002: allTrue,
			field5003: allTrue
		},
		config2: {
			field1: allTrue,
			field2: allTrue,
			field3: allTrue,
			field4: allTrue,
			field5: allTrue,
			field6: allTrue,
			field7: allTrue,
			field8: allTrue
		},
		config3: {
			field5: allTrue,
			field6: allTrue
		}
	} }, OidbGroupListRequestSchema, OidbSvcTrpcTcp0xFE5_2ResponseSchema, true);
	const groups = [];
	if (resp?.groups) for (const raw of resp.groups) groups.push({
		groupId: raw.groupUin ?? 0,
		groupName: raw.info?.groupName ?? "",
		remark: raw.customInfo?.remark ?? "",
		memberCount: raw.info?.memberCount ?? 0,
		memberMax: raw.info?.memberMax ?? 0,
		members: /* @__PURE__ */ new Map()
	});
	bridge.qqInfo.setGroups(groups);
	return groups;
}
async function fetchGroupMemberList(bridge, groupId) {
	const members = [];
	let token = "";
	do {
		const body = {
			groupUin: groupId,
			field2: 5,
			field3: 2,
			body: {
				memberName: true,
				memberCard: true,
				level: true,
				field13: true,
				field16: true,
				specialTitle: true,
				field18: true,
				field20: true,
				field21: true,
				joinTimestamp: true,
				lastMsgTimestamp: true,
				shutUpTimestamp: true,
				field103: true,
				field104: true,
				field105: true,
				field106: true,
				permission: true,
				field200: true,
				field201: true
			}
		};
		if (token) body.token = token;
		const resp = await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0xfe7_3", 4071, 3, body, OidbGroupMemberListRequestSchema, OidbSvcTrpcTcp0xFE7_3ResponseSchema);
		if (resp?.members) for (const raw of resp.members) members.push({
			uin: raw.uin?.uin ?? 0,
			uid: raw.uin?.uid ?? "",
			nickname: raw.memberName ?? "",
			card: raw.memberCard?.memberCard ?? "",
			role: permissionToRole(raw.permission ?? 0),
			level: raw.level?.level ?? 0,
			title: raw.specialTitle ?? "",
			joinTime: raw.joinTimestamp ?? 0,
			lastSentTime: raw.lastMsgTimestamp ?? 0,
			shutUpTime: raw.shutUpTimestamp ?? 0
		});
		token = resp?.token ?? "";
	} while (token);
	bridge.qqInfo.setGroupMembers(groupId, members);
	return members;
}
async function fetchUserProfile(bridge, uin) {
	const resp = await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0xfe1_2", 4065, 2, {
		uin,
		field2: 0,
		keys: [
			20002,
			27394,
			20009,
			20031,
			101,
			103,
			102,
			20020,
			20003,
			20026,
			105,
			27372,
			27406,
			20037
		].map((k) => ({ key: k }))
	}, OidbUserInfoRequestSchema, OidbUserInfoResponseSchema);
	if (!resp?.body) throw new Error("user info response body missing");
	const info = {
		uin: resp.body.uin ?? uin,
		uid: resp.body.uid ?? "",
		nickname: "",
		remark: "",
		qid: "",
		sex: "unknown",
		age: 0,
		sign: "",
		avatar: ""
	};
	if (resp.body.properties) {
		const bytesMap = /* @__PURE__ */ new Map();
		const numMap = /* @__PURE__ */ new Map();
		for (const bp of resp.body.properties.bytesProperties ?? []) bytesMap.set(bp.code ?? 0, bp.value ?? new Uint8Array(0));
		for (const np of resp.body.properties.numberProperties ?? []) numMap.set(np.number1 ?? 0, np.number2 ?? 0);
		const getString = (code) => {
			const b = bytesMap.get(code);
			return b ? Buffer.from(b).toString("utf8") : "";
		};
		info.nickname = getString(20002);
		info.remark = getString(103);
		info.qid = getString(27394);
		info.sign = getString(102);
		const avatarBytes = bytesMap.get(101);
		if (avatarBytes) {
			const av = protoDecode(avatarBytes, AvatarInfoSchema);
			if (av?.url) info.avatar = av.url + "640";
		}
		const sexNum = numMap.get(20009) ?? 0;
		info.sex = sexNum === 1 ? "male" : sexNum === 2 ? "female" : "unknown";
		info.age = numMap.get(20037) ?? 0;
	}
	bridge.qqInfo.setUserProfile(info);
	const selfUin = parseInt(bridge.qqInfo.uin, 10) || 0;
	if (info.uin === selfUin) bridge.qqInfo.setSelfProfile(info);
	return info;
}
async function fetchGroupRequests(bridge, filtered = false) {
	const resp = await sendOidbAndDecode(bridge, filtered ? "OidbSvcTrpcTcp.0x10c0_2" : "OidbSvcTrpcTcp.0x10c0_1", 4288, filtered ? 2 : 1, {
		count: 20,
		field2: 0
	}, OidbGroupRequestListSchema, OidbSvcTrpcTcp0x10C0ResponseSchema);
	const requests = [];
	for (const raw of resp?.requests ?? []) requests.push({
		groupId: raw.group?.groupUin ?? 0,
		groupName: raw.group?.groupName ?? "",
		targetUid: raw.target?.uid ?? "",
		targetUin: 0,
		targetName: raw.target?.name ?? "",
		invitorUid: raw.invitor?.uid ?? "",
		invitorUin: 0,
		invitorName: raw.invitor?.name ?? "",
		operatorUid: raw.operatorUser?.uid ?? "",
		operatorUin: 0,
		operatorName: raw.operatorUser?.name ?? "",
		sequence: Number(raw.sequence ?? 0),
		state: raw.state ?? 0,
		eventType: raw.eventType ?? 0,
		comment: raw.comment ?? "",
		filtered
	});
	return requests;
}
async function fetchDownloadRKeys(bridge) {
	const resp = await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x9067_202", 36967, 202, {
		reqHead: {
			common: {
				requestId: 1,
				command: 202
			},
			scene: {
				requestType: 2,
				businessType: 1,
				sceneType: 0
			},
			client: { agentType: 2 }
		},
		downloadRkey: { types: [
			10,
			20,
			2
		] }
	}, NTV2RichMediaReqSchema, NTV2RichMediaRespSchema, true);
	if (resp?.respHead?.retCode && resp.respHead.retCode !== 0) throw new Error(resp.respHead.message ?? "fetch download rkey failed");
	const result = [];
	for (const entry of resp?.downloadRkey?.rkeys ?? []) {
		const rkey = entry.rkey ?? "";
		const type = entry.type ?? 0;
		if (rkey && type) result.push({
			rkey,
			ttlSeconds: Number(entry.rkeyTtlSec ?? 0),
			storeId: entry.storeId ?? 0,
			createTime: entry.rkeyCreateTime ?? 0,
			type
		});
	}
	return result;
}
//#endregion
//#region src/bridge/proto/longmsg.ts
var LongMsgUidSchema = { uid: {
	field: 2,
	type: "string"
} };
var LongMsgSettingsSchema = {
	field1: {
		field: 1,
		type: "uint32"
	},
	field2: {
		field: 2,
		type: "uint32"
	},
	field3: {
		field: 3,
		type: "uint32"
	},
	field4: {
		field: 4,
		type: "uint32"
	}
};
var SendLongMsgReqSchema = {
	info: {
		field: 2,
		type: "message",
		schema: {
			type: {
				field: 1,
				type: "uint32"
			},
			uid: {
				field: 2,
				type: "message",
				schema: LongMsgUidSchema
			},
			groupUin: {
				field: 3,
				type: "uint32"
			},
			payload: {
				field: 4,
				type: "bytes"
			}
		}
	},
	settings: {
		field: 15,
		type: "message",
		schema: LongMsgSettingsSchema
	}
};
var SendLongMsgRespSchema = {
	result: {
		field: 2,
		type: "message",
		schema: { resId: {
			field: 3,
			type: "string"
		} }
	},
	settings: {
		field: 15,
		type: "message",
		schema: LongMsgSettingsSchema
	}
};
var RecvLongMsgReqSchema = {
	info: {
		field: 1,
		type: "message",
		schema: {
			uid: {
				field: 1,
				type: "message",
				schema: LongMsgUidSchema
			},
			resId: {
				field: 2,
				type: "string"
			},
			acquire: {
				field: 3,
				type: "bool"
			}
		}
	},
	settings: {
		field: 15,
		type: "message",
		schema: LongMsgSettingsSchema
	}
};
var RecvLongMsgRespSchema = {
	result: {
		field: 1,
		type: "message",
		schema: {
			resId: {
				field: 3,
				type: "string"
			},
			payload: {
				field: 4,
				type: "bytes"
			}
		}
	},
	settings: {
		field: 15,
		type: "message",
		schema: LongMsgSettingsSchema
	}
};
var LongMsgResultSchema = { action: {
	field: 2,
	type: "repeated_message",
	schema: {
		actionCommand: {
			field: 1,
			type: "string"
		},
		actionData: {
			field: 2,
			type: "message",
			schema: { msgBody: {
				field: 1,
				type: "repeated_message",
				schema: PushMsgBodySchema
			} }
		}
	}
} };
//#endregion
//#region src/bridge/bridge-actions.ts
var forwardResCache = /* @__PURE__ */ new Map();
function toInt$2(value) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.trunc(value);
	if (typeof value === "bigint") {
		const n = Number(value);
		return Number.isFinite(n) ? Math.trunc(n) : 0;
	}
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		return Number.isFinite(n) ? Math.trunc(n) : 0;
	}
	return 0;
}
function ensureRetCodeZero(operation, code, msg, wording) {
	const retCode = toInt$2(code);
	if (retCode === 0) return;
	throw new Error(`${operation} failed: code=${retCode} msg=${typeof wording === "string" && wording || typeof msg === "string" && msg || "unknown error"}`);
}
function normalizeDirectory(dir) {
	if (!dir || !dir.trim()) return "/";
	return dir;
}
function bytesToHexUpper(data) {
	if (!(data instanceof Uint8Array) || data.length === 0) return "";
	return Buffer.from(data).toString("hex").toUpperCase();
}
function normalizeUploadFileName(name, fallback) {
	const trimmed = name.trim();
	if (trimmed) return trimmed;
	return fallback.trim() || "file.bin";
}
function md5First10MB(bytes) {
	const limit = Math.min(bytes.length, 10 * 1024 * 1024);
	return computeMd5(bytes.subarray(0, limit));
}
function buildGroupFileUploadExt(senderUin, groupId, fileName, fileSize, md5, fileId, uploadKey, checkKey, uploadHost, uploadPort) {
	return protoEncode({
		unknown1: 100,
		unknown2: 1,
		entry: {
			busiBuff: {
				busId: 102,
				senderUin: BigInt(senderUin),
				receiverUin: BigInt(groupId),
				groupCode: BigInt(groupId)
			},
			fileEntry: {
				fileSize: BigInt(Math.max(0, fileSize)),
				md5,
				md5S2: md5,
				checkKey,
				fileId,
				uploadKey
			},
			clientInfo: {
				clientType: 3,
				appId: "100",
				terminalType: 3,
				clientVer: "1.1.1",
				unknown: 4
			},
			fileNameInfo: { fileName },
			host: { hosts: [{
				url: {
					host: uploadHost,
					unknown: 1
				},
				port: uploadPort
			}] }
		},
		unknown200: 0
	}, FileUploadExtSchema);
}
function buildPrivateFileUploadExt(senderUin, fileName, fileSize, md5, sha1, fileId, uploadKey, uploadHost, uploadPort) {
	return protoEncode({
		unknown1: 100,
		unknown2: 1,
		entry: {
			busiBuff: {
				busId: 102,
				senderUin: BigInt(senderUin),
				receiverUin: 0n,
				groupCode: 0n
			},
			fileEntry: {
				fileSize: BigInt(Math.max(0, fileSize)),
				md5,
				md5S2: md5,
				checkKey: sha1,
				fileId,
				uploadKey
			},
			clientInfo: {
				clientType: 3,
				appId: "100",
				terminalType: 3,
				clientVer: "1.1.1",
				unknown: 4
			},
			fileNameInfo: { fileName },
			host: { hosts: [{
				url: {
					host: uploadHost,
					unknown: 1
				},
				port: uploadPort
			}] }
		},
		unknown3: 0,
		unknown200: 1
	}, FileUploadExtSchema);
}
async function resolveSelfUid(bridge) {
	let selfUid = bridge.qqInfo.selfUid;
	if (selfUid) return selfUid;
	const selfUin = toInt$2(bridge.qqInfo.uin);
	if (selfUin <= 0) throw new Error("self uid is unavailable");
	selfUid = await resolveUserUid(bridge, selfUin);
	return selfUid;
}
function normalizeMediaNode(node) {
	const fileUuid = typeof node.fileUuid === "string" ? node.fileUuid : "";
	if (!fileUuid) throw new Error("media node fileUuid is required");
	const info = node.info ?? {};
	const type = info.type ?? {};
	return {
		info: {
			fileSize: toInt$2(info.fileSize),
			fileHash: typeof info.fileHash === "string" ? info.fileHash : "",
			fileSha1: typeof info.fileSha1 === "string" ? info.fileSha1 : "",
			fileName: typeof info.fileName === "string" ? info.fileName : "",
			type: {
				type: toInt$2(type.type),
				picFormat: toInt$2(type.picFormat),
				videoFormat: toInt$2(type.videoFormat),
				voiceFormat: toInt$2(type.voiceFormat)
			},
			width: toInt$2(info.width),
			height: toInt$2(info.height),
			time: toInt$2(info.time),
			original: toInt$2(info.original)
		},
		fileUuid,
		storeId: toInt$2(node.storeId),
		uploadTime: toInt$2(node.uploadTime),
		ttl: toInt$2(node.ttl),
		subType: toInt$2(node.subType)
	};
}
async function fetchNtv2DownloadUrl(bridge, serviceCmd, oidbCmd, payload) {
	const resp = await sendOidbAndDecode(bridge, serviceCmd, oidbCmd, 200, payload, NTV2RichMediaReqSchema, NTV2RichMediaRespSchema, true);
	ensureRetCodeZero("ntv2 download", resp?.respHead?.retCode, resp?.respHead?.message, void 0);
	const domain = typeof resp?.download?.info?.domain === "string" ? resp.download.info.domain : "";
	const path = typeof resp?.download?.info?.urlPath === "string" ? resp.download.info.urlPath : "";
	const rKeyParam = typeof resp?.download?.rKeyParam === "string" ? resp.download.rKeyParam : "";
	if (!domain || !path) throw new Error("ntv2 download response invalid");
	return `https://${domain}${path}${rKeyParam}`;
}
async function buildForwardPushBody(bridge, node) {
	const fromUin = node.userUin > 0 ? node.userUin : toInt$2(bridge.qqInfo.uin);
	if (fromUin <= 0) throw new Error("forward node user uin is invalid");
	const nickname = node.nickname.trim() || String(fromUin);
	const elems = await buildSendElems(node.elements);
	const now = Math.floor(Date.now() / 1e3);
	const random = Math.floor(Math.random() * 2147483647) >>> 0;
	const seq = Math.floor(Math.random() * 9e6) + 1e6;
	return {
		responseHead: {
			fromUin,
			toUid: bridge.qqInfo.selfUid ?? "",
			forward: { friendName: nickname }
		},
		contentHead: {
			msgType: 9,
			subType: 4,
			msgId: random,
			sequence: seq,
			timestamp: now,
			divSeq: 0
		},
		body: { richText: { elems } }
	};
}
async function setFriendRemark(bridge, userId, remark) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0xb6e_2", 2926, 2, {
		targetUid: await resolveUserUid(bridge, userId),
		remark
	}, OidbSetFriendRemarkSchema);
}
async function fetchGroupFileCount(bridge, groupId) {
	const resp = await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d8_3", 1752, 3, { count: {
		groupUin: groupId,
		appId: 7,
		busId: 0
	} }, OidbGroupFileCountViewReqSchema, OidbGroupFileCountViewRespSchema);
	return {
		fileCount: toInt$2(resp?.count?.fileCount ?? 0),
		maxCount: toInt$2(resp?.count?.maxCount ?? 1e4)
	};
}
async function muteGroupMember(bridge, groupId, userId, duration) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x1253_1", 4691, 1, {
		groupUin: groupId,
		type: 1,
		body: {
			targetUid: await resolveUserUid(bridge, userId, groupId),
			duration
		}
	}, OidbMuteMemberSchema);
}
async function muteGroupAll(bridge, groupId, enable) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x89a_0", 2202, 0, {
		groupUin: groupId,
		muteState: { state: enable ? 4294967295 : 0 }
	}, OidbMuteAllSchema);
}
async function kickGroupMember(bridge, groupId, userId, reject, reason = "") {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x8a0_1", 2208, 1, {
		groupUin: groupId,
		targetUid: await resolveUserUid(bridge, userId, groupId),
		rejectAddRequest: reject,
		reason
	}, OidbKickMemberSchema);
}
async function leaveGroup(bridge, groupId) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x1097_1", 4247, 1, { groupUin: groupId }, OidbLeaveGroupSchema);
}
async function setGroupAdmin(bridge, groupId, userId, enable) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x1096_1", 4246, 1, {
		groupUin: groupId,
		uid: await resolveUserUid(bridge, userId, groupId),
		isAdmin: enable
	}, OidbSetAdminSchema);
}
async function setGroupCard(bridge, groupId, userId, card) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x8fc_3", 2300, 3, {
		groupUin: groupId,
		body: {
			targetUid: await resolveUserUid(bridge, userId, groupId),
			targetName: card
		}
	}, OidbRenameMemberSchema);
}
async function setGroupName(bridge, groupId, name) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x89a_15", 2202, 15, {
		groupUin: groupId,
		body: { targetName: name }
	}, OidbRenameGroupSchema);
}
async function setGroupSpecialTitle(bridge, groupId, userId, title) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x8fc_2", 2300, 2, {
		groupUin: groupId,
		body: {
			targetUid: await resolveUserUid(bridge, userId, groupId),
			specialTitle: title,
			expireTime: -1
		}
	}, OidbSpecialTitleSchema);
}
async function setFriendAddRequest(bridge, uidOrFlag, approve) {
	let targetUid = uidOrFlag;
	if (/^\d+$/.test(uidOrFlag)) targetUid = await resolveUserUid(bridge, parseInt(uidOrFlag, 10));
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0xb5d_44", 2909, 44, {
		accept: approve ? 3 : 5,
		targetUid
	}, OidbFriendRequestActionSchema);
}
async function deleteFriend(bridge, userId, block = false) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x126b_0", 4715, 0, { field1: {
		targetUid: await resolveUserUid(bridge, userId),
		field2: {
			field1: 130,
			field2: 109,
			field3: {
				field1: 8,
				field2: 8,
				field3: 50
			}
		},
		block,
		field4: false
	} }, OidbDeleteFriendSchema);
	try {
		await bridge.fetchFriendList();
	} catch {}
}
async function uploadGroupFile(bridge, groupId, source, name = "", folderId = "/", uploadFile = true) {
	const loaded = await loadBinarySource(source, "file");
	if (!loaded.bytes.length) throw new Error("group file is empty");
	const fileName = normalizeUploadFileName(name, loaded.fileName);
	const hashes = computeHashes(loaded.bytes);
	const upload = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d6_0", 1750, 0, { file: {
		groupUin: groupId,
		appId: 4,
		busId: 102,
		entrance: 6,
		targetDirectory: normalizeDirectory(folderId),
		fileName,
		localDirectory: `/${fileName}`,
		fileSize: BigInt(loaded.bytes.length),
		fileSha1: hashes.sha1,
		fileSha3: new Uint8Array(0),
		fileMd5: hashes.md5,
		field15: true
	} }, OidbGroupFileReqSchema, OidbGroupFileRespSchema, true))?.upload;
	if (!upload) throw new Error("group file upload response missing");
	ensureRetCodeZero("group file upload", upload.retCode, upload.retMsg, upload.clientWording);
	const fileId = typeof upload.fileId === "string" && upload.fileId ? upload.fileId : null;
	if (!fileId) throw new Error("group file upload response missing file_id");
	if (!upload.boolFileExist && uploadFile) {
		const senderUin = toInt$2(bridge.qqInfo.uin);
		if (senderUin <= 0) throw new Error("invalid self uin for group file upload");
		const uploadHost = typeof upload.uploadIp === "string" && upload.uploadIp || typeof upload.serverDns === "string" && upload.serverDns || "";
		const uploadPort = toInt$2(upload.uploadPort);
		if (!uploadHost || uploadPort <= 0) throw new Error("group file upload host is invalid");
		const ext = buildGroupFileUploadExt(senderUin, groupId, fileName, loaded.bytes.length, hashes.md5, fileId, upload.fileKey instanceof Uint8Array ? upload.fileKey : new Uint8Array(0), upload.checkKey instanceof Uint8Array ? upload.checkKey : new Uint8Array(0), uploadHost, uploadPort);
		await uploadHighwayHttp(bridge, await fetchHighwaySession(bridge), 71, loaded.bytes, hashes.md5, ext);
	}
	return { fileId };
}
async function uploadPrivateFile(bridge, userId, source, name = "", uploadFile = true) {
	const loaded = await loadBinarySource(source, "file");
	if (!loaded.bytes.length) throw new Error("private file is empty");
	const targetUid = await resolveUserUid(bridge, userId);
	let selfUid = bridge.qqInfo.selfUid;
	if (!selfUid) {
		const selfUin = toInt$2(bridge.qqInfo.uin);
		if (selfUin > 0) selfUid = await resolveUserUid(bridge, selfUin);
	}
	if (!selfUid) throw new Error("self uid is unavailable");
	const senderUin = toInt$2(bridge.qqInfo.uin);
	if (senderUin <= 0) throw new Error("invalid self uin for private file upload");
	const fileName = normalizeUploadFileName(name, loaded.fileName);
	const hashes = computeHashes(loaded.bytes);
	const upload = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0xe37_1700", 3639, 1700, {
		command: 1700,
		seq: 0,
		upload: {
			senderUid: selfUid,
			receiverUid: targetUid,
			fileSize: loaded.bytes.length,
			fileName,
			md510MCheckSum: md5First10MB(loaded.bytes),
			sha1CheckSum: hashes.sha1,
			localPath: "/",
			md5CheckSum: hashes.md5,
			sha3CheckSum: new Uint8Array(0)
		},
		businessId: 3,
		clientType: 1,
		flagSupportMediaPlatform: 1
	}, OidbPrivateFileUploadReqSchema, OidbPrivateFileUploadRespSchema))?.upload;
	if (!upload) throw new Error("private file upload response missing");
	ensureRetCodeZero("private file upload", upload.retCode, upload.retMsg, void 0);
	const fileId = typeof upload.uuid === "string" && upload.uuid ? upload.uuid : null;
	const fileHash = typeof upload.fileAddon === "string" && upload.fileAddon ? upload.fileAddon : null;
	if (!fileId) throw new Error("private file upload response missing file_id");
	if (!upload.boolFileExist && uploadFile) {
		const uploadHost = typeof upload.uploadIp === "string" && upload.uploadIp || "";
		const uploadPort = toInt$2(upload.uploadPort);
		if (!uploadHost || uploadPort <= 0) throw new Error("private file upload host is invalid");
		const ext = buildPrivateFileUploadExt(senderUin, fileName, loaded.bytes.length, hashes.md5, hashes.sha1, fileId, upload.mediaPlatformUploadKey instanceof Uint8Array ? upload.mediaPlatformUploadKey : upload.uploadKey instanceof Uint8Array ? upload.uploadKey : new Uint8Array(0), uploadHost, uploadPort);
		await uploadHighwayHttp(bridge, await fetchHighwaySession(bridge), 95, loaded.bytes, hashes.md5, ext);
	}
	return {
		fileId,
		fileHash
	};
}
async function fetchGroupFiles(bridge, groupId, folderId = "/") {
	const targetDirectory = normalizeDirectory(folderId);
	const files = [];
	const folders = [];
	const pageSize = 20;
	let startIndex = 0;
	for (let page = 0; page < 200; page++) {
		const list = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d8_1", 1752, 1, { list: {
			groupUin: groupId,
			appId: 7,
			targetDirectory,
			fileCount: pageSize,
			sortBy: 1,
			startIndex,
			field17: 2,
			field18: 0
		} }, OidbGroupFileViewReqSchema, OidbGroupFileViewRespSchema, true))?.list;
		if (!list) break;
		ensureRetCodeZero("group file list", list.retCode, list.retMsg, list.clientWording);
		for (const item of list.items ?? []) {
			const type = toInt$2(item?.type);
			if (type === 1 && item?.fileInfo) {
				const file = item.fileInfo;
				const uploader = toInt$2(file.uploaderUin);
				const cached = bridge.qqInfo.findGroupMember(groupId, uploader);
				files.push({
					fileId: typeof file.fileId === "string" ? file.fileId : "",
					fileName: typeof file.fileName === "string" ? file.fileName : "",
					busId: toInt$2(file.busId),
					fileSize: toInt$2(file.fileSize),
					uploadTime: toInt$2(file.uploadedTime),
					deadTime: toInt$2(file.expireTime),
					modifyTime: toInt$2(file.modifiedTime),
					downloadTimes: toInt$2(file.downloadedTimes),
					uploader,
					uploaderName: typeof file.uploaderName === "string" && file.uploaderName || cached?.card || cached?.nickname || ""
				});
			} else if (type === 2 && item?.folderInfo) {
				const folder = item.folderInfo;
				const creator = toInt$2(folder.creatorUin);
				const cached = bridge.qqInfo.findGroupMember(groupId, creator);
				folders.push({
					folderId: typeof folder.folderId === "string" ? folder.folderId : "",
					folderName: typeof folder.folderName === "string" ? folder.folderName : "",
					createTime: toInt$2(folder.createTime),
					creator,
					creatorName: typeof folder.creatorName === "string" && folder.creatorName || cached?.card || cached?.nickname || "",
					totalFileCount: toInt$2(folder.totalFileCount)
				});
			}
		}
		if (list.isEnd) break;
		startIndex += pageSize;
	}
	return {
		files,
		folders
	};
}
async function fetchGroupFileUrl(bridge, groupId, fileId, busId = 102) {
	const download = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d6_2", 1750, 2, { download: {
		groupUin: groupId,
		appId: 7,
		busId,
		fileId
	} }, OidbGroupFileReqSchema, OidbGroupFileRespSchema, true))?.download;
	if (!download) throw new Error("group file url response missing");
	ensureRetCodeZero("group file url", download.retCode, download.retMsg, download.clientWording);
	const dns = typeof download.downloadDns === "string" && download.downloadDns || typeof download.downloadIp === "string" && download.downloadIp || "";
	const hexUrl = bytesToHexUpper(download.downloadUrl);
	if (!dns || !hexUrl) throw new Error("group file url response invalid");
	return `https://${dns}/ftn_handler/${hexUrl}/?fname=${fileId}`;
}
async function deleteGroupFile(bridge, groupId, fileId) {
	const result = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d6_3", 1750, 3, { delete: {
		groupUin: groupId,
		busId: 102,
		fileId
	} }, OidbGroupFileReqSchema, OidbGroupFileRespSchema, true))?.delete;
	if (!result) throw new Error("group file delete response missing");
	ensureRetCodeZero("group file delete", result.retCode, result.retMsg, result.clientWording);
}
async function moveGroupFile(bridge, groupId, fileId, parentDirectory, targetDirectory) {
	const result = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d6_5", 1750, 5, { move: {
		groupUin: groupId,
		appId: 7,
		busId: 102,
		fileId,
		parentDirectory,
		targetDirectory
	} }, OidbGroupFileReqSchema, OidbGroupFileRespSchema, true))?.move;
	if (!result) throw new Error("group file move response missing");
	ensureRetCodeZero("group file move", result.retCode, result.retMsg, result.clientWording);
}
async function createGroupFileFolder(bridge, groupId, name, parentId = "/") {
	const result = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d7_0", 1751, 0, { create: {
		groupUin: groupId,
		rootDirectory: normalizeDirectory(parentId),
		folderName: name
	} }, OidbGroupFileFolderReqSchema, OidbGroupFileFolderRespSchema, true))?.create;
	if (!result) throw new Error("group folder create response missing");
	ensureRetCodeZero("group folder create", result.retcode, result.retMsg, result.clientWording);
}
async function deleteGroupFileFolder(bridge, groupId, folderId) {
	const result = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d7_1", 1751, 1, { delete: {
		groupUin: groupId,
		folderId
	} }, OidbGroupFileFolderReqSchema, OidbGroupFileFolderRespSchema, true))?.delete;
	if (!result) throw new Error("group folder delete response missing");
	ensureRetCodeZero("group folder delete", result.retcode, result.retMsg, result.clientWording);
}
async function renameGroupFileFolder(bridge, groupId, folderId, newFolderName) {
	const result = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0x6d7_2", 1751, 2, { rename: {
		groupUin: groupId,
		folderId,
		newFolderName
	} }, OidbGroupFileFolderReqSchema, OidbGroupFileFolderRespSchema, true))?.rename;
	if (!result) throw new Error("group folder rename response missing");
	ensureRetCodeZero("group folder rename", result.retcode, result.retMsg, result.clientWording);
}
async function fetchPrivateFileUrl(bridge, userId, fileId, fileHash) {
	const result = (await sendOidbAndDecode(bridge, "OidbSvcTrpcTcp.0xe37_1200", 3639, 1200, {
		subCommand: 1200,
		field2: 1,
		body: {
			receiverUid: await resolveUserUid(bridge, userId),
			fileUuid: fileId,
			type: 2,
			fileHash,
			t2: 0
		},
		field101: 3,
		field102: 103,
		field200: 1,
		field99999: new Uint8Array([
			192,
			133,
			44,
			1
		])
	}, OidbPrivateFileDownloadReqSchema, OidbPrivateFileDownloadRespSchema))?.body?.result;
	const server = typeof result?.server === "string" ? result.server : "";
	const port = toInt$2(result?.port);
	const url = typeof result?.url === "string" ? result.url : "";
	if (!server || !port || !url) throw new Error("private file url response invalid");
	return `http://${server}:${port}${url}&isthumb=0`;
}
async function fetchGroupPttUrlByNode(bridge, groupId, node) {
	const normalizedNode = normalizeMediaNode(node);
	return fetchNtv2DownloadUrl(bridge, "OidbSvcTrpcTcp.0x126e_200", 4718, {
		reqHead: {
			common: {
				requestId: 4,
				command: 200
			},
			scene: {
				requestType: 1,
				businessType: 3,
				sceneType: 2,
				group: { groupUin: groupId }
			},
			client: { agentType: 2 }
		},
		download: {
			node: normalizedNode,
			download: { video: {
				busiType: 0,
				sceneType: 0
			} }
		}
	});
}
async function fetchPrivatePttUrlByNode(bridge, node) {
	const selfUid = await resolveSelfUid(bridge);
	const normalizedNode = normalizeMediaNode(node);
	return fetchNtv2DownloadUrl(bridge, "OidbSvcTrpcTcp.0x126d_200", 4717, {
		reqHead: {
			common: {
				requestId: 1,
				command: 200
			},
			scene: {
				requestType: 1,
				businessType: 3,
				sceneType: 1,
				c2c: {
					accountType: 2,
					targetUid: selfUid
				}
			},
			client: { agentType: 2 }
		},
		download: {
			node: normalizedNode,
			download: { video: {
				busiType: 0,
				sceneType: 0
			} }
		}
	});
}
async function fetchGroupVideoUrlByNode(bridge, groupId, node) {
	const normalizedNode = normalizeMediaNode(node);
	return fetchNtv2DownloadUrl(bridge, "OidbSvcTrpcTcp.0x11ea_200", 4586, {
		reqHead: {
			common: {
				requestId: 1,
				command: 200
			},
			scene: {
				requestType: 2,
				businessType: 2,
				sceneType: 2,
				group: { groupUin: groupId }
			},
			client: { agentType: 2 }
		},
		download: {
			node: normalizedNode,
			download: { video: {
				busiType: 0,
				sceneType: 0
			} }
		}
	});
}
async function fetchPrivateVideoUrlByNode(bridge, node) {
	const selfUid = await resolveSelfUid(bridge);
	const normalizedNode = normalizeMediaNode(node);
	return fetchNtv2DownloadUrl(bridge, "OidbSvcTrpcTcp.0x11e9_200", 4585, {
		reqHead: {
			common: {
				requestId: 1,
				command: 200
			},
			scene: {
				requestType: 2,
				businessType: 2,
				sceneType: 1,
				c2c: {
					accountType: 2,
					targetUid: selfUid
				}
			},
			client: { agentType: 2 }
		},
		download: {
			node: normalizedNode,
			download: { video: {
				busiType: 0,
				sceneType: 0
			} }
		}
	});
}
async function uploadForwardNodes(bridge, nodes, groupId) {
	if (!Array.isArray(nodes) || nodes.length === 0) throw new Error("forward nodes are required");
	const longMsgResult = protoEncode({ action: [{
		actionCommand: "MultiMsg",
		actionData: { msgBody: await Promise.all(nodes.map((node) => buildForwardPushBody(bridge, node))) }
	}] }, LongMsgResultSchema);
	const selfUid = await resolveSelfUid(bridge);
	const info = {
		type: groupId ? 3 : 1,
		uid: { uid: groupId ? String(groupId) : selfUid },
		payload: gzipSync(Buffer.from(longMsgResult))
	};
	if (groupId) info.groupUin = groupId;
	const request = protoEncode({
		info,
		settings: {
			field1: 4,
			field2: 1,
			field3: 7,
			field4: 0
		}
	}, SendLongMsgReqSchema);
	const result = await bridge.sendRawPacket("trpc.group.long_msg_interface.MsgService.SsoSendLongMsg", request);
	if (!result.success || !result.gotResponse || !result.responseData) throw new Error(result.errorMessage || "upload forward message failed");
	const resp = protoDecode(result.responseData, SendLongMsgRespSchema);
	const resId = typeof resp?.result?.resId === "string" ? resp.result.resId : "";
	if (!resId) throw new Error("upload forward message response missing res_id");
	forwardResCache.set(resId, nodes.map((node) => ({
		userUin: node.userUin,
		nickname: node.nickname,
		elements: [...node.elements]
	})));
	return resId;
}
async function fetchForwardNodes(bridge, resId) {
	const cached = forwardResCache.get(resId);
	if (cached) return cached.map((node) => ({
		userUin: node.userUin,
		nickname: node.nickname,
		elements: [...node.elements]
	}));
	const request = protoEncode({
		info: {
			uid: { uid: await resolveSelfUid(bridge) },
			resId,
			acquire: true
		},
		settings: {
			field1: 2,
			field2: 0,
			field3: 0,
			field4: 0
		}
	}, RecvLongMsgReqSchema);
	const result = await bridge.sendRawPacket("trpc.group.long_msg_interface.MsgService.SsoRecvLongMsg", request);
	if (!result.success || !result.gotResponse || !result.responseData) throw new Error(result.errorMessage || "download forward message failed");
	const payload = protoDecode(result.responseData, RecvLongMsgRespSchema)?.result?.payload;
	if (!(payload instanceof Uint8Array) || payload.length === 0) throw new Error("download forward message payload is empty");
	const action = protoDecode(gunzipSync(Buffer.from(payload)), LongMsgResultSchema)?.action?.find((item) => item?.actionCommand === "MultiMsg");
	const msgBodyList = Array.isArray(action?.actionData?.msgBody) ? action.actionData.msgBody : [];
	const nodes = [];
	for (const msgBody of msgBodyList) {
		const wrapped = protoEncode({ message: msgBody }, PushMsgSchema);
		const event = parseMsgPush({
			pid: 0,
			uin: bridge.qqInfo.uin,
			serviceCmd: "trpc.msg.olpush.OlPushService.MsgPush",
			seqId: 0,
			retCode: 0,
			fromClient: false,
			body: wrapped
		}, bridge.qqInfo).find((e) => e.kind === "friend_message" || e.kind === "group_message" || e.kind === "temp_message");
		if (!event) continue;
		if (event.kind === "group_message") nodes.push({
			userUin: event.senderUin,
			nickname: event.senderCard || event.senderNick,
			elements: event.elements
		});
		else if (event.kind === "friend_message") nodes.push({
			userUin: event.senderUin,
			nickname: event.senderNick,
			elements: event.elements
		});
		else nodes.push({
			userUin: event.senderUin,
			nickname: event.senderNick,
			elements: event.elements
		});
	}
	if (nodes.length > 0) forwardResCache.set(resId, nodes.map((node) => ({
		userUin: node.userUin,
		nickname: node.nickname,
		elements: [...node.elements]
	})));
	return nodes;
}
async function setGroupAddRequest(bridge, groupId, sequence, eventType, approve, reason = "", filtered = false) {
	await sendOidbAndCheck(bridge, filtered ? "OidbSvcTrpcTcp.0x10c8_2" : "OidbSvcTrpcTcp.0x10c8_1", 4296, filtered ? 2 : 1, {
		accept: approve ? 1 : 2,
		body: {
			sequence: BigInt(sequence),
			eventType,
			groupUin: groupId,
			message: reason
		}
	}, OidbGroupRequestActionSchema, true);
}
async function sendPoke(bridge, isGroup, peerUin, targetUin) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0xed3_1", 3795, 1, {
		uin: targetUin ?? peerUin,
		groupUin: isGroup ? peerUin : 0,
		friendUin: isGroup ? 0 : peerUin,
		ext: 0
	}, OidbPokeSchema);
}
async function sendLike(bridge, userId, count) {
	await sendOidbAndCheck(bridge, "OidbSvcTrpcTcp.0x7e5_104", 2021, 104, {
		targetUin: userId,
		count
	}, OidbLikeSchema);
}
async function setGroupEssence(bridge, groupId, sequence, random, enable) {
	await sendOidbAndCheck(bridge, enable ? "OidbSvcTrpcTcp.0xeac_1" : "OidbSvcTrpcTcp.0xeac_2", 3756, enable ? 1 : 2, {
		groupUin: groupId,
		sequence,
		random
	}, OidbEssenceSchema);
}
async function setGroupReaction(bridge, groupId, sequence, code, isSet) {
	await sendOidbAndCheck(bridge, isSet ? "OidbSvcTrpcTcp.0x9082_1" : "OidbSvcTrpcTcp.0x9082_2", 36994, isSet ? 1 : 2, {
		groupUin: groupId,
		sequence,
		code
	}, OidbGroupReactionSchema);
}
async function recallGroupMessage(bridge, groupId, sequence) {
	const request = protoEncode({
		type: 1,
		groupUin: groupId,
		info: {
			sequence,
			random: 0,
			field3: 0
		},
		settings: { field1: 0 }
	}, GroupRecallRequestSchema);
	const result = await bridge.sendRawPacket("trpc.msg.msg_svc.MsgService.SsoGroupRecallMsg", request);
	if (!result.success) throw new Error(result.errorMessage || "recall group message failed");
}
async function recallPrivateMessage(bridge, userUin, clientSeq, msgSeq, random, timestamp) {
	const request = protoEncode({
		type: 1,
		targetUid: await resolveUserUid(bridge, userUin),
		info: {
			clientSequence: clientSeq,
			random,
			messageId: BigInt(16777216 * 4294967296 + random),
			timestamp,
			field5: 0,
			messageSequence: msgSeq
		},
		settings: {
			field1: false,
			field2: false
		},
		field6: false
	}, C2CRecallRequestSchema);
	const result = await bridge.sendRawPacket("trpc.msg.msg_svc.MsgService.SsoC2CRecallMsg", request);
	if (!result.success) throw new Error(result.errorMessage || "recall private message failed");
}
//#endregion
//#region src/bridge/bridge.ts
var log$9 = createLogger("Bridge");
var eventLog = createLogger("Event");
var Bridge = class Bridge {
	static SEND_MSG_CMD = "MessageSvc.PbSendMsg";
	qqInfo_;
	pids_ = /* @__PURE__ */ new Set();
	eventCallback_ = null;
	cmdHandlers_ = /* @__PURE__ */ new Map();
	packetClient_ = null;
	memberRefreshTasks_ = /* @__PURE__ */ new Map();
	memberListInflight_ = /* @__PURE__ */ new Map();
	memberListLastFetch_ = /* @__PURE__ */ new Map();
	clientSeq_ = 1e8 + Date.now() % 1e9;
	msgRandom_ = (Date.now() & 4294967295) >>> 0;
	constructor(qqInfo) {
		this.qqInfo_ = qqInfo;
		this.registerDefaultHandlers();
	}
	get qqInfo() {
		return this.qqInfo_;
	}
	setPacketClient(client) {
		this.packetClient_ = client;
	}
	registerDefaultHandlers() {
		this.registerCmd(MSG_PUSH_CMD, parseMsgPush);
	}
	registerCmd(cmd, parser) {
		const arr = this.cmdHandlers_.get(cmd) ?? [];
		arr.push(parser);
		this.cmdHandlers_.set(cmd, arr);
	}
	setEventCallback(cb) {
		this.eventCallback_ = cb;
	}
	handlesCmd(cmd) {
		return this.cmdHandlers_.has(cmd);
	}
	attachPid(pid) {
		this.pids_.add(pid);
	}
	detachPid(pid) {
		this.pids_.delete(pid);
	}
	hasPid(pid) {
		return this.pids_.has(pid);
	}
	get empty() {
		return this.pids_.size === 0;
	}
	get activePid() {
		for (const pid of this.pids_) return pid;
		return null;
	}
	onPacket(pkt) {
		const handlers = this.cmdHandlers_.get(pkt.serviceCmd);
		if (!handlers) return;
		for (const handler of handlers) try {
			const events = handler(pkt, this.qqInfo_);
			for (const event of events) {
				this.triggerMemberCacheRefresh(event);
				printEvent(event);
				this.emitEvent(event);
			}
		} catch (e) {
			log$9.error("handler error for %s: %s", pkt.serviceCmd, e instanceof Error ? e.stack ?? e.message : String(e));
		}
	}
	emitEvent(event) {
		if (this.eventCallback_) try {
			this.eventCallback_(event);
		} catch (e) {
			log$9.error("event callback error: %s", e instanceof Error ? e.stack ?? e.message : String(e));
		}
	}
	triggerMemberCacheRefresh(event) {
		let groupId = 0;
		let reason = "";
		switch (event.kind) {
			case "group_member_join":
				groupId = event.groupId;
				reason = "group_member_join";
				break;
			case "group_member_leave":
				groupId = event.groupId;
				reason = "group_member_leave";
				break;
			case "group_admin":
				groupId = event.groupId;
				reason = "group_admin";
				break;
			default: return;
		}
		if (groupId <= 0) return;
		if (this.memberRefreshTasks_.has(groupId)) return;
		const task = (async () => {
			try {
				if (!this.qqInfo_.findGroup(groupId)) try {
					await this.fetchGroupList();
				} catch {}
				await this.fetchGroupMemberList(groupId);
				log$9.debug("member cache refreshed: group=%d reason=%s", groupId, reason);
			} catch (e) {
				log$9.warn("failed to refresh member cache: group=%d reason=%s err=%s", groupId, reason, e instanceof Error ? e.message : String(e));
			} finally {
				this.memberRefreshTasks_.delete(groupId);
			}
		})();
		this.memberRefreshTasks_.set(groupId, task);
	}
	nextClientSequence() {
		return ++this.clientSeq_;
	}
	nextMessageRandom() {
		this.msgRandom_ = this.msgRandom_ + 2654435769 >>> 0;
		return this.msgRandom_ & 2147483647;
	}
	async sendRawPacket(serviceCmd, body, timeoutMs = 15e3) {
		if (!this.packetClient_) return {
			success: false,
			gotResponse: false,
			errorCode: -1,
			errorMessage: "no packet sender attached",
			responseData: null
		};
		return this.packetClient_.sendPacket(serviceCmd, Buffer.from(body), timeoutMs);
	}
	async sendGroupMessage(groupId, elements) {
		if (elements.length === 0) throw new Error("message is empty");
		const protoElems = await buildSendElems(elements, {
			bridge: this,
			groupId
		});
		const random = this.nextMessageRandom();
		const request = protoEncode({
			routingHead: { grp: { groupCode: BigInt(groupId) } },
			contentHead: { type: 1 },
			messageBody: { richText: { elems: protoElems } },
			clientSequence: 0,
			random,
			syncCookie: new Uint8Array(0),
			via: 0,
			dataStatist: 0,
			multiSendSeq: 0
		}, SendMessageRequestSchema);
		const result = await this.sendRawPacket(Bridge.SEND_MSG_CMD, request);
		if (!result.success || !result.gotResponse || !result.responseData) throw new Error(`send group message failed: ${result.errorMessage || "no response"}`);
		const response = protoDecode(result.responseData, SendMessageResponseSchema);
		if (!response) throw new Error("failed to decode SendMessageResponse");
		if (response.result !== void 0 && response.result !== 0) throw new Error(`send group message rejected: result=${response.result} err=${response.errMsg ?? ""}`);
		const seq = response.groupSequence ?? 0;
		return {
			messageId: random & 2147483647 || seq,
			sequence: seq,
			clientSequence: 0,
			random,
			timestamp: response.timestamp1 ?? Math.floor(Date.now() / 1e3)
		};
	}
	async sendPrivateMessage(userUin, elements) {
		if (elements.length === 0) throw new Error("message is empty");
		let userUid = "";
		if (elements.some((e) => e.type === "image" || e.type === "record" || e.type === "video")) userUid = await this.resolveUserUid(userUin);
		const protoElems = await buildSendElems(elements, {
			bridge: this,
			userUid
		});
		const random = this.nextMessageRandom();
		const clientSeq = this.nextClientSequence();
		const request = protoEncode({
			routingHead: { c2c: { uin: userUin } },
			contentHead: {
				type: 1,
				subType: 0,
				c2cCmd: 11
			},
			messageBody: { richText: { elems: protoElems } },
			clientSequence: clientSeq,
			random,
			syncCookie: new Uint8Array(0),
			via: 0,
			dataStatist: 0,
			ctrl: { msgFlag: Math.floor(Date.now() / 1e3) },
			multiSendSeq: 0
		}, SendMessageRequestSchema);
		const result = await this.sendRawPacket(Bridge.SEND_MSG_CMD, request);
		if (!result.success || !result.gotResponse || !result.responseData) throw new Error(`send private message failed: ${result.errorMessage || "no response"}`);
		const response = protoDecode(result.responseData, SendMessageResponseSchema);
		if (!response) throw new Error("failed to decode SendMessageResponse");
		if (response.result !== void 0 && response.result !== 0) throw new Error(`send private message rejected: result=${response.result} err=${response.errMsg ?? ""}`);
		const seq = response.privateSequence ?? 0;
		return {
			messageId: random & 2147483647 || seq,
			sequence: seq,
			clientSequence: clientSeq,
			random,
			timestamp: response.timestamp1 ?? Math.floor(Date.now() / 1e3)
		};
	}
	async resolveUserUid(uin, groupId) {
		return resolveUserUid(this, uin, groupId);
	}
	async fetchFriendList() {
		return fetchFriendList(this);
	}
	async fetchGroupList() {
		return fetchGroupList(this);
	}
	async fetchGroupMemberList(groupId) {
		const kMemberListTtlMs = 6e4;
		const now = Date.now();
		const last = this.memberListLastFetch_.get(groupId);
		if (last && now - last.at < kMemberListTtlMs) return last.data;
		const inflight = this.memberListInflight_.get(groupId);
		if (inflight) return inflight;
		const task = (async () => {
			try {
				const data = await fetchGroupMemberList(this, groupId);
				this.memberListLastFetch_.set(groupId, {
					at: Date.now(),
					data
				});
				return data;
			} finally {
				this.memberListInflight_.delete(groupId);
			}
		})();
		this.memberListInflight_.set(groupId, task);
		return task;
	}
	async fetchUserProfile(uin) {
		return fetchUserProfile(this, uin);
	}
	async fetchGroupRequests(filtered = false) {
		return fetchGroupRequests(this, filtered);
	}
	async fetchDownloadRKeys() {
		return fetchDownloadRKeys(this);
	}
	async muteGroupMember(groupId, userId, duration) {
		return muteGroupMember(this, groupId, userId, duration);
	}
	async muteGroupAll(groupId, enable) {
		return muteGroupAll(this, groupId, enable);
	}
	async kickGroupMember(groupId, userId, reject, reason = "") {
		return kickGroupMember(this, groupId, userId, reject, reason);
	}
	async leaveGroup(groupId) {
		return leaveGroup(this, groupId);
	}
	async setGroupAdmin(groupId, userId, enable) {
		return setGroupAdmin(this, groupId, userId, enable);
	}
	async setGroupCard(groupId, userId, card) {
		return setGroupCard(this, groupId, userId, card);
	}
	async setGroupName(groupId, name) {
		return setGroupName(this, groupId, name);
	}
	async setGroupSpecialTitle(groupId, userId, title) {
		return setGroupSpecialTitle(this, groupId, userId, title);
	}
	async setFriendAddRequest(uidOrFlag, approve) {
		return setFriendAddRequest(this, uidOrFlag, approve);
	}
	async deleteFriend(userId, block = false) {
		return deleteFriend(this, userId, block);
	}
	async uploadGroupFile(groupId, file, name = "", folderId = "/", uploadFile = true) {
		return uploadGroupFile(this, groupId, file, name, folderId, uploadFile);
	}
	async uploadPrivateFile(userId, file, name = "", uploadFile = true) {
		return uploadPrivateFile(this, userId, file, name, uploadFile);
	}
	async fetchGroupFiles(groupId, folderId = "/") {
		return fetchGroupFiles(this, groupId, folderId);
	}
	async fetchGroupFileUrl(groupId, fileId, busId = 102) {
		return fetchGroupFileUrl(this, groupId, fileId, busId);
	}
	async fetchPrivateFileUrl(userId, fileId, fileHash) {
		return fetchPrivateFileUrl(this, userId, fileId, fileHash);
	}
	async fetchGroupPttUrlByNode(groupId, node) {
		return fetchGroupPttUrlByNode(this, groupId, node);
	}
	async fetchPrivatePttUrlByNode(node) {
		return fetchPrivatePttUrlByNode(this, node);
	}
	async fetchGroupVideoUrlByNode(groupId, node) {
		return fetchGroupVideoUrlByNode(this, groupId, node);
	}
	async fetchPrivateVideoUrlByNode(node) {
		return fetchPrivateVideoUrlByNode(this, node);
	}
	async uploadForwardNodes(nodes, groupId) {
		return uploadForwardNodes(this, nodes, groupId);
	}
	async fetchForwardNodes(resId) {
		return fetchForwardNodes(this, resId);
	}
	async deleteGroupFile(groupId, fileId) {
		return deleteGroupFile(this, groupId, fileId);
	}
	async moveGroupFile(groupId, fileId, parentDirectory, targetDirectory) {
		return moveGroupFile(this, groupId, fileId, parentDirectory, targetDirectory);
	}
	async createGroupFileFolder(groupId, name, parentId = "/") {
		return createGroupFileFolder(this, groupId, name, parentId);
	}
	async deleteGroupFileFolder(groupId, folderId) {
		return deleteGroupFileFolder(this, groupId, folderId);
	}
	async renameGroupFileFolder(groupId, folderId, newFolderName) {
		return renameGroupFileFolder(this, groupId, folderId, newFolderName);
	}
	async setGroupAddRequest(groupId, sequence, eventType, approve, reason = "", filtered = false) {
		return setGroupAddRequest(this, groupId, sequence, eventType, approve, reason, filtered);
	}
	async sendPoke(isGroup, peerUin, targetUin) {
		return sendPoke(this, isGroup, peerUin, targetUin);
	}
	async sendLike(userId, count) {
		return sendLike(this, userId, count);
	}
	async setGroupEssence(groupId, sequence, random, enable) {
		return setGroupEssence(this, groupId, sequence, random, enable);
	}
	async setGroupReaction(groupId, sequence, code, isSet) {
		return setGroupReaction(this, groupId, sequence, code, isSet);
	}
	async recallGroupMessage(groupId, sequence) {
		return recallGroupMessage(this, groupId, sequence);
	}
	async recallPrivateMessage(userUin, clientSeq, msgSeq, random, timestamp) {
		return recallPrivateMessage(this, userUin, clientSeq, msgSeq, random, timestamp);
	}
	async setFriendRemark(userId, remark) {
		return setFriendRemark(this, userId, remark);
	}
	async fetchGroupFileCount(groupId) {
		return fetchGroupFileCount(this, groupId);
	}
};
function printEvent(event) {
	switch (event.kind) {
		case "group_message":
		case "friend_message":
		case "temp_message": break;
		case "group_recall":
			eventLog.warn("群撤回 %d | %d 被 %d 撤回", event.groupId, event.authorUin, event.operatorUin);
			break;
		case "friend_recall":
			eventLog.warn("私聊撤回 %d 撤回了消息", event.userUin);
			break;
		case "group_member_join":
			eventLog.info("入群 %d 加入 %d", event.userUin, event.groupId);
			break;
		case "group_member_leave":
			eventLog.warn("退群 %d %s %d", event.userUin, event.isKick ? "被踢出" : "退出", event.groupId);
			break;
		case "group_mute":
			eventLog.warn("禁言 %d | %d %d秒", event.groupId, event.userUin, event.duration);
			break;
		case "group_admin":
			eventLog.info("管理 %d | %d %s管理员", event.groupId, event.userUin, event.set ? "+" : "-");
			break;
		case "friend_poke":
			eventLog.info("戳一戳 %d -> %d", event.userUin, event.targetUin);
			break;
		case "group_poke":
			eventLog.info("群戳 %d | %d -> %d", event.groupId, event.userUin, event.targetUin);
			break;
		case "friend_request":
			eventLog.warn("好友请求 %d: %s", event.fromUin, event.message);
			break;
		case "group_invite":
			eventLog.warn("群邀请 %d -> 群%d", event.fromUin, event.groupId);
			break;
		case "group_essence":
			eventLog.info("精华 %d | %s精华", event.groupId, event.set ? "+" : "-");
			break;
	}
}
//#endregion
//#region src/bridge/qq-info.ts
var QQInfo = class {
	uin_;
	nickname_ = "";
	selfProfile_ = null;
	userProfiles_ = /* @__PURE__ */ new Map();
	friends_ = [];
	groups_ = /* @__PURE__ */ new Map();
	constructor(uin) {
		this.uin_ = uin;
	}
	get uin() {
		return this.uin_;
	}
	get nickname() {
		return this.nickname_;
	}
	set nickname(v) {
		this.nickname_ = v;
	}
	setSelfProfile(info) {
		this.selfProfile_ = info;
	}
	get selfProfile() {
		return this.selfProfile_;
	}
	get selfUid() {
		return this.selfProfile_?.uid ?? null;
	}
	setUserProfile(info) {
		this.userProfiles_.set(info.uin, info);
	}
	findUserProfile(uin) {
		return this.userProfiles_.get(uin) ?? null;
	}
	setFriends(friends) {
		this.friends_ = friends;
	}
	get friends() {
		return this.friends_;
	}
	findFriend(uin) {
		return this.friends_.find((f) => f.uin === uin) ?? null;
	}
	setGroups(groups) {
		this.groups_.clear();
		for (const g of groups) this.groups_.set(g.groupId, g);
	}
	get groups() {
		return [...this.groups_.values()];
	}
	findGroup(groupId) {
		return this.groups_.get(groupId) ?? null;
	}
	findGroupMember(groupId, uin) {
		return this.groups_.get(groupId)?.members.get(uin) ?? null;
	}
	setGroupMembers(groupId, members) {
		const g = this.groups_.get(groupId);
		if (!g) return;
		g.members.clear();
		for (const m of members) g.members.set(m.uin, m);
	}
	updateGroupMember(groupId, member) {
		const g = this.groups_.get(groupId);
		if (!g) return;
		g.members.set(member.uin, member);
	}
	resolveUid(uid) {
		if (this.selfProfile_?.uid === uid) return this.selfProfile_.uin || parseInt(this.uin_, 10) || null;
		for (const f of this.friends_) if (f.uid === uid) return f.uin;
		for (const [, p] of this.userProfiles_) if (p.uid === uid) return p.uin;
		for (const [, g] of this.groups_) for (const [, m] of g.members) if (m.uid === uid) return m.uin;
		return null;
	}
	resolveGroupMemberUid(groupId, uid) {
		const g = this.groups_.get(groupId);
		if (!g) return null;
		for (const [, m] of g.members) if (m.uid === uid) return m.uin;
		return null;
	}
	findUidByUin(uin) {
		if (this.selfProfile_ && this.selfProfile_.uin === uin && this.selfProfile_.uid) return this.selfProfile_.uid;
		for (const f of this.friends_) if (f.uin === uin && f.uid) return f.uid;
		for (const [, p] of this.userProfiles_) if (p.uin === uin && p.uid) return p.uid;
		for (const [, g] of this.groups_) for (const [, m] of g.members) if (m.uin === uin && m.uid) return m.uid;
		return null;
	}
	findUidByUinInGroup(groupId, uin) {
		const g = this.groups_.get(groupId);
		if (!g) return null;
		for (const [, m] of g.members) if (m.uin === uin && m.uid) return m.uid;
		return null;
	}
};
//#endregion
//#region src/bridge/manager.ts
var log$8 = createLogger("Bridge");
var BridgeManager = class BridgeManager {
	sessions_ = /* @__PURE__ */ new Map();
	pidToUin_ = /* @__PURE__ */ new Map();
	pidPacketClients_ = /* @__PURE__ */ new Map();
	onSessionStarted_ = null;
	onSessionClosed_ = null;
	onBridgeEvent_ = null;
	setSessionStartedCallback(cb) {
		this.onSessionStarted_ = cb;
	}
	setSessionClosedCallback(cb) {
		this.onSessionClosed_ = cb;
	}
	setEventCallback(cb) {
		this.onBridgeEvent_ = cb;
	}
	bind(ntqq) {
		ntqq.registerCmdAll((pkt) => this.onPacket(pkt));
	}
	onPidDisconnected(pid) {
		this.pidPacketClients_.delete(pid);
		const uin = this.pidToUin_.get(pid);
		if (!uin) return;
		this.pidToUin_.delete(pid);
		const session = this.sessions_.get(uin);
		if (!session) return;
		session.bridge.detachPid(pid);
		if (session.bridge.empty) {
			this.sessions_.delete(uin);
			log$8.debug("session closed: UIN=%s", uin);
			if (this.onSessionClosed_) this.onSessionClosed_(uin);
		}
	}
	static isRealUin(uin) {
		if (!uin || uin === "0") return false;
		return /^\d+$/.test(uin) && uin.length >= 5;
	}
	onHookLogin(pid, uin, packetClient) {
		if (!BridgeManager.isRealUin(uin)) return;
		this.pidPacketClients_.set(pid, packetClient);
		const { session, created } = this.ensureSession(uin);
		session.bridge.attachPid(pid);
		session.bridge.setPacketClient(packetClient);
		this.pidToUin_.set(pid, uin);
		if (created) {
			log$8.debug("session started: UIN=%s", uin);
			if (this.onSessionStarted_) this.onSessionStarted_(uin, session.qqInfo, session.bridge);
		}
	}
	onPacket(pkt) {
		if (!pkt.uin || !BridgeManager.isRealUin(pkt.uin)) return;
		const uin = pkt.uin;
		const { session, created } = this.ensureSession(uin);
		if (pkt.pid && this.pidPacketClients_.has(pkt.pid)) {
			session.bridge.attachPid(pkt.pid);
			this.pidToUin_.set(pkt.pid, uin);
			const client = this.pidPacketClients_.get(pkt.pid);
			if (client) session.bridge.setPacketClient(client);
		}
		if (created) {
			log$8.debug("session started: UIN=%s", uin);
			if (this.onSessionStarted_) this.onSessionStarted_(uin, session.qqInfo, session.bridge);
		}
		session.bridge.onPacket(pkt);
	}
	ensureSession(uin) {
		let session = this.sessions_.get(uin);
		if (session) return {
			session,
			created: false
		};
		const qqInfo = new QQInfo(uin);
		const bridge = new Bridge(qqInfo);
		session = {
			qqInfo,
			bridge
		};
		this.sessions_.set(uin, session);
		bridge.setEventCallback((event) => {
			if (this.onBridgeEvent_) this.onBridgeEvent_(uin, event);
		});
		return {
			session,
			created: true
		};
	}
	getSession(uin) {
		return this.sessions_.get(uin) ?? null;
	}
	get sessions() {
		return this.sessions_;
	}
};
//#endregion
//#region src/onebot/types.ts
var RETCODE = {
	ACTION_FAILED: 100,
	INTERNAL_ERROR: 1200,
	BAD_REQUEST: 1400,
	UNKNOWN_ACTION: 1404
};
function okResponse(data = null) {
	return {
		status: "ok",
		retcode: 0,
		data
	};
}
function failedResponse(retcode, wording) {
	return {
		status: "failed",
		retcode,
		data: null,
		wording
	};
}
//#endregion
//#region src/onebot/actions/info.ts
function register$7(h, ctx) {
	h.registerAction("get_login_info", async () => {
		const login = ctx.getLoginInfo();
		return okResponse({
			user_id: login.userId,
			nickname: login.nickname
		});
	});
	h.registerAction("get_status", async () => {
		const online = ctx.isOnline();
		return okResponse({
			online,
			good: online
		});
	});
	h.registerAction("get_version_info", async () => {
		return okResponse({
			app_name: "SnowLuma",
			app_version: "0.1.0-node",
			protocol_version: "v11"
		});
	});
	h.registerAction("can_send_image", async () => {
		return okResponse({ yes: ctx.canSendImage?.() ?? false });
	});
	h.registerAction("can_send_record", async () => {
		return okResponse({ yes: ctx.canSendRecord?.() ?? false });
	});
}
//#endregion
//#region src/onebot/actions/message.ts
function register$6(h, ctx) {
	h.registerAction("send_msg", async (params) => {
		const messageType = asString(params.message_type);
		const message = asMessage(params.message);
		const autoEscape = asBoolean(params.auto_escape, false);
		if (message === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message is required");
		if (messageType === "group" || params.group_id !== void 0) {
			const groupId = asNumber(params.group_id);
			if (!Number.isInteger(groupId) || groupId <= 0) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
			if (!ctx.sendGroupMessage) return failedResponse(RETCODE.ACTION_FAILED, "send_group_msg is not implemented");
			return okResponse({ message_id: (await ctx.sendGroupMessage(groupId, message, autoEscape)).messageId });
		}
		const userId = asNumber(params.user_id);
		if (!Number.isInteger(userId) || userId <= 0) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (!ctx.sendPrivateMessage) return failedResponse(RETCODE.ACTION_FAILED, "send_private_msg is not implemented");
		return okResponse({ message_id: (await ctx.sendPrivateMessage(userId, message, autoEscape)).messageId });
	});
	h.registerAction("send_private_msg", async (params) => {
		const userId = asNumber(params.user_id);
		const message = asMessage(params.message);
		const autoEscape = asBoolean(params.auto_escape, false);
		if (!Number.isInteger(userId) || userId <= 0) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (message === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message is required");
		if (!ctx.sendPrivateMessage) return failedResponse(RETCODE.ACTION_FAILED, "send_private_msg is not implemented");
		return okResponse({ message_id: (await ctx.sendPrivateMessage(userId, message, autoEscape)).messageId });
	});
	h.registerAction("send_group_msg", async (params) => {
		const groupId = asNumber(params.group_id);
		const message = asMessage(params.message);
		const autoEscape = asBoolean(params.auto_escape, false);
		if (!Number.isInteger(groupId) || groupId <= 0) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (message === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message is required");
		if (!ctx.sendGroupMessage) return failedResponse(RETCODE.ACTION_FAILED, "send_group_msg is not implemented");
		return okResponse({ message_id: (await ctx.sendGroupMessage(groupId, message, autoEscape)).messageId });
	});
	h.registerAction("get_msg", async (params) => {
		const messageId = asNumber(params.message_id);
		if (!Number.isInteger(messageId) || messageId === 0) return failedResponse(RETCODE.BAD_REQUEST, "message_id is required");
		const data = ctx.getMessage(messageId);
		if (!data) return failedResponse(RETCODE.ACTION_FAILED, "message not found");
		const result = { ...data };
		delete result.post_type;
		delete result.self_id;
		result.real_id = result.message_id ?? messageId;
		return okResponse(result);
	});
	h.registerAction("delete_msg", async (params) => {
		const messageId = asNumber(params.message_id);
		if (!Number.isInteger(messageId) || messageId === 0) return failedResponse(RETCODE.BAD_REQUEST, "message_id is required");
		if (!ctx.deleteMessage) return failedResponse(RETCODE.ACTION_FAILED, "delete_msg is not implemented");
		const meta = ctx.getMessageMeta(messageId);
		if (!meta) return failedResponse(RETCODE.ACTION_FAILED, "message not found or not retractable");
		await ctx.deleteMessage(messageId, meta);
		return okResponse();
	});
}
//#endregion
//#region src/onebot/actions/friend.ts
function register$5(h, ctx) {
	h.registerAction("get_friend_list", async () => {
		if (ctx.getFriendList) return okResponse(await ctx.getFriendList());
		return okResponse([]);
	});
	h.registerAction("get_stranger_info", async (params) => {
		const userId = asNumber(params.user_id);
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (ctx.getStrangerInfo) return okResponse(await ctx.getStrangerInfo(userId) ?? {
			user_id: userId,
			nickname: "",
			sex: "unknown",
			age: 0
		});
		return okResponse({
			user_id: userId,
			nickname: "",
			sex: "unknown",
			age: 0
		});
	});
	h.registerAction("delete_friend", async (params) => {
		const userId = asNumber(params.user_id);
		const block = asBoolean(params.block, false);
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (!ctx.handleDeleteFriend) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.handleDeleteFriend(userId, block);
		return okResponse();
	});
}
//#endregion
//#region src/onebot/actions/group-info.ts
function register$4(h, ctx) {
	h.registerAction("get_group_list", async (params) => {
		const noCache = asBoolean(params.no_cache, false);
		if (ctx.getGroupList) return okResponse(await ctx.getGroupList(noCache));
		return okResponse([]);
	});
	h.registerAction("get_group_info", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		const noCache = asBoolean(params.no_cache, false);
		if (ctx.getGroupInfo) return okResponse(await ctx.getGroupInfo(groupId, noCache) ?? {
			group_id: groupId,
			group_name: "",
			member_count: 0,
			max_member_count: 0
		});
		return okResponse({
			group_id: groupId,
			group_name: "",
			member_count: 0,
			max_member_count: 0
		});
	});
	h.registerAction("get_group_member_list", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		const noCache = asBoolean(params.no_cache, false);
		if (ctx.getGroupMemberList) return okResponse(await ctx.getGroupMemberList(groupId, noCache));
		return okResponse([]);
	});
	h.registerAction("get_group_member_info", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		const noCache = asBoolean(params.no_cache, false);
		if (ctx.getGroupMemberInfo) return okResponse(await ctx.getGroupMemberInfo(groupId, userId, noCache) ?? {
			group_id: groupId,
			user_id: userId,
			nickname: "",
			card: "",
			sex: "unknown",
			age: 0,
			join_time: 0,
			last_sent_time: 0,
			level: "0",
			role: "member",
			title: ""
		});
		return okResponse({
			group_id: groupId,
			user_id: userId,
			nickname: "",
			card: "",
			sex: "unknown",
			age: 0,
			join_time: 0,
			last_sent_time: 0,
			level: "0",
			role: "member",
			title: ""
		});
	});
	h.registerAction("get_group_honor_info", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		return okResponse({
			group_id: groupId,
			current_talkative: null,
			talkative_list: [],
			performer_list: [],
			legend_list: [],
			strong_newbie_list: [],
			emotion_list: []
		});
	});
	h.registerAction("get_group_system_msg", async () => {
		if (ctx.handleGetGroupSystemMsg) return okResponse(await ctx.handleGetGroupSystemMsg());
		return okResponse([]);
	});
}
//#endregion
//#region src/onebot/actions/group-admin.ts
function register$3(h, ctx) {
	h.registerAction("set_group_kick", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		const reject = asBoolean(params.reject_add_request, false);
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		if (!ctx.setGroupKick) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupKick(groupId, userId, reject);
		return okResponse();
	});
	h.registerAction("set_group_ban", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		const duration = asNumber(params.duration) || 1800;
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		if (!ctx.setGroupBan) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupBan(groupId, userId, duration);
		return okResponse();
	});
	h.registerAction("set_group_whole_ban", async (params) => {
		const groupId = asNumber(params.group_id);
		const enable = asBoolean(params.enable, true);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (!ctx.setGroupWholeBan) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupWholeBan(groupId, enable);
		return okResponse();
	});
	h.registerAction("set_group_admin", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		const enable = asBoolean(params.enable, true);
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		if (!ctx.setGroupAdmin) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupAdmin(groupId, userId, enable);
		return okResponse();
	});
	h.registerAction("set_group_card", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		const card = asString(params.card);
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		if (!ctx.setGroupCard) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupCard(groupId, userId, card);
		return okResponse();
	});
	h.registerAction("set_group_name", async (params) => {
		const groupId = asNumber(params.group_id);
		const name = asString(params.group_name);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (!ctx.setGroupName) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupName(groupId, name);
		return okResponse();
	});
	h.registerAction("set_group_leave", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (!ctx.setGroupLeave) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupLeave(groupId);
		return okResponse();
	});
	h.registerAction("set_group_special_title", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		const title = asString(params.special_title);
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		if (!ctx.setGroupSpecialTitle) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupSpecialTitle(groupId, userId, title);
		return okResponse();
	});
	h.registerAction("set_group_anonymous", async () => {
		return okResponse();
	});
	h.registerAction("set_group_anonymous_ban", async () => {
		return okResponse();
	});
	h.registerAction("set_group_portrait", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
}
//#endregion
//#region src/onebot/actions/group-file.ts
function register$2(h, ctx) {
	h.registerAction("upload_group_file", async (params) => {
		const groupId = asNumber(params.group_id);
		const file = asString(params.file);
		const name = asString(params.name);
		const folderId = asString(params.folder) || asString(params.folder_id) || "/";
		const uploadFile = asBoolean(params.upload_file, true);
		if (!groupId || !file) return failedResponse(RETCODE.BAD_REQUEST, "group_id and file are required");
		if (!ctx.uploadGroupFile) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ file_id: await ctx.uploadGroupFile(groupId, file, name, folderId, uploadFile) });
	});
	h.registerAction("upload_private_file", async (params) => {
		const userId = asNumber(params.user_id);
		const file = asString(params.file);
		const name = asString(params.name);
		const uploadFile = asBoolean(params.upload_file, true);
		if (!userId || !file) return failedResponse(RETCODE.BAD_REQUEST, "user_id and file are required");
		if (!ctx.uploadPrivateFile) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ file_id: await ctx.uploadPrivateFile(userId, file, name, uploadFile) });
	});
	h.registerAction("get_group_file_url", async (params) => {
		const groupId = asNumber(params.group_id);
		const fileId = asString(params.file_id);
		const busId = asNumber(params.busid) || 102;
		if (!groupId || !fileId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and file_id are required");
		if (!ctx.getGroupFileUrl) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ url: await ctx.getGroupFileUrl(groupId, fileId, busId) });
	});
	h.registerAction("get_group_root_files", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (!ctx.getGroupFiles) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse(await ctx.getGroupFiles(groupId, "/"));
	});
	h.registerAction("get_group_files_by_folder", async (params) => {
		const groupId = asNumber(params.group_id);
		const folderId = asString(params.folder_id) || asString(params.folder) || "/";
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (!ctx.getGroupFiles) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse(await ctx.getGroupFiles(groupId, folderId));
	});
	h.registerAction("delete_group_file", async (params) => {
		const groupId = asNumber(params.group_id);
		const fileId = asString(params.file_id);
		if (!groupId || !fileId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and file_id are required");
		if (!ctx.deleteGroupFile) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.deleteGroupFile(groupId, fileId);
		return okResponse();
	});
	h.registerAction("move_group_file", async (params) => {
		const groupId = asNumber(params.group_id);
		const fileId = asString(params.file_id);
		const parentDirectory = asString(params.parent_directory);
		const targetDirectory = asString(params.target_directory);
		if (!groupId || !fileId || !parentDirectory || !targetDirectory) return failedResponse(RETCODE.BAD_REQUEST, "group_id, file_id, parent_directory and target_directory are required");
		if (!ctx.moveGroupFile) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.moveGroupFile(groupId, fileId, parentDirectory, targetDirectory);
		return okResponse();
	});
	h.registerAction("create_group_file_folder", async (params) => {
		const groupId = asNumber(params.group_id);
		const name = asString(params.name);
		const parentId = asString(params.parent_id) || "/";
		if (!groupId || !name) return failedResponse(RETCODE.BAD_REQUEST, "group_id and name are required");
		if (!ctx.createGroupFileFolder) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.createGroupFileFolder(groupId, name, parentId);
		return okResponse();
	});
	h.registerAction("delete_group_file_folder", async (params) => {
		const groupId = asNumber(params.group_id);
		const folderId = asString(params.folder_id);
		if (!groupId || !folderId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and folder_id are required");
		if (!ctx.deleteGroupFileFolder) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.deleteGroupFileFolder(groupId, folderId);
		return okResponse();
	});
	h.registerAction("rename_group_file_folder", async (params) => {
		const groupId = asNumber(params.group_id);
		const folderId = asString(params.folder_id);
		const newName = asString(params.new_folder_name) || asString(params.name);
		if (!groupId || !folderId || !newName) return failedResponse(RETCODE.BAD_REQUEST, "group_id, folder_id and new_folder_name are required");
		if (!ctx.renameGroupFileFolder) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.renameGroupFileFolder(groupId, folderId, newName);
		return okResponse();
	});
	h.registerAction("get_private_file_url", async (params) => {
		const userId = asNumber(params.user_id);
		const fileId = asString(params.file_id);
		const fileHash = asString(params.file_hash);
		if (!userId || !fileId || !fileHash) return failedResponse(RETCODE.BAD_REQUEST, "user_id, file_id and file_hash are required");
		if (!ctx.getPrivateFileUrl) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ url: await ctx.getPrivateFileUrl(userId, fileId, fileHash) });
	});
}
//#endregion
//#region src/onebot/actions/request.ts
function register$1(h, ctx) {
	h.registerAction("set_friend_add_request", async (params) => {
		const flag = asString(params.flag);
		const approve = asBoolean(params.approve, true);
		if (!flag) return failedResponse(RETCODE.BAD_REQUEST, "flag is required");
		if (!ctx.handleFriendRequest) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.handleFriendRequest(flag, approve);
		return okResponse();
	});
	h.registerAction("set_group_add_request", async (params) => {
		const flag = asString(params.flag);
		const subType = asString(params.sub_type, asString(params.type, "add"));
		const approve = asBoolean(params.approve, true);
		const reason = asString(params.reason);
		if (!flag) return failedResponse(RETCODE.BAD_REQUEST, "flag is required");
		if (!ctx.handleGroupRequest) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.handleGroupRequest(flag, subType, approve, reason);
		return okResponse();
	});
}
//#endregion
//#region src/onebot/actions/extended.ts
function register(h, ctx) {
	h.registerAction("send_like", async (params) => {
		const userId = asNumber(params.user_id);
		const times = asNumber(params.times) || 1;
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (!ctx.sendLike) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.sendLike(userId, times);
		return okResponse();
	});
	h.registerAction("friend_poke", async (params) => {
		const userId = asNumber(params.user_id);
		const targetId = asNumber(params.target_id) || void 0;
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (!ctx.sendFriendPoke) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.sendFriendPoke(userId, targetId);
		return okResponse();
	});
	h.registerAction("group_poke", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		if (!groupId || !userId) return failedResponse(RETCODE.BAD_REQUEST, "group_id and user_id are required");
		if (!ctx.sendGroupPoke) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.sendGroupPoke(groupId, userId);
		return okResponse();
	});
	h.registerAction("send_poke", async (params) => {
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (groupId) {
			if (!ctx.sendGroupPoke) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
			await ctx.sendGroupPoke(groupId, userId);
		} else {
			if (!ctx.sendFriendPoke) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
			await ctx.sendFriendPoke(userId);
		}
		return okResponse();
	});
	h.registerAction("set_essence_msg", async (params) => {
		const messageId = asNumber(params.message_id);
		if (!Number.isInteger(messageId) || messageId === 0) return failedResponse(RETCODE.BAD_REQUEST, "message_id is required");
		if (!ctx.setEssenceMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setEssenceMsg(messageId);
		return okResponse();
	});
	h.registerAction("delete_essence_msg", async (params) => {
		const messageId = asNumber(params.message_id);
		if (!Number.isInteger(messageId) || messageId === 0) return failedResponse(RETCODE.BAD_REQUEST, "message_id is required");
		if (!ctx.deleteEssenceMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.deleteEssenceMsg(messageId);
		return okResponse();
	});
	h.registerAction("get_essence_msg_list", async (params) => {
		if (!asNumber(params.group_id)) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		return okResponse([]);
	});
	h.registerAction("set_group_reaction", async (params) => {
		const groupId = asNumber(params.group_id);
		const messageId = asNumber(params.message_id);
		const code = asString(params.code);
		const isSet = asBoolean(params.is_set, true);
		if (!Number.isInteger(messageId) || messageId === 0 || !code) return failedResponse(RETCODE.BAD_REQUEST, "message_id and code are required");
		const meta = ctx.getMessageMeta(messageId);
		if (!meta || !meta.isGroup) return failedResponse(RETCODE.ACTION_FAILED, "message not found or not a group message");
		if (groupId && groupId !== meta.targetId) return failedResponse(RETCODE.BAD_REQUEST, "group_id does not match message session");
		if (!ctx.setGroupReaction) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setGroupReaction(meta.targetId, meta.sequence, code, isSet);
		return okResponse();
	});
	h.registerAction("get_group_msg_history", async (params) => {
		const groupId = asNumber(params.group_id);
		const messageId = asNumber(params.message_id) || 0;
		const count = asNumber(params.count) || 20;
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (!ctx.getGroupMsgHistory) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ messages: await ctx.getGroupMsgHistory(groupId, messageId, count) });
	});
	h.registerAction("get_friend_msg_history", async (params) => {
		const userId = asNumber(params.user_id);
		const messageId = asNumber(params.message_id) || 0;
		const count = asNumber(params.count) || 20;
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (!ctx.getFriendMsgHistory) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ messages: await ctx.getFriendMsgHistory(userId, messageId, count) });
	});
	h.registerAction("mark_msg_as_read", async () => {
		return okResponse();
	});
	h.registerAction("get_rkey", async () => {
		if (ctx.getDownloadRKeys) return okResponse(await ctx.getDownloadRKeys());
		return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
	});
	h.registerAction("ocr_image", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction(".ocr_image", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("_send_group_notice", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("_get_group_notice", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("_del_group_notice", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("upload_forward_msg", async (params) => {
		const messages = asMessage(params.messages ?? params.message);
		const groupId = asNumber(params.group_id);
		if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
		if (!ctx.sendForwardMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		const result = await ctx.sendForwardMsg(messages);
		const data = {
			res_id: result.forwardId,
			forward_id: result.forwardId,
			message_id: 0
		};
		if (groupId > 0) data.group_id = groupId;
		return okResponse(data);
	});
	h.registerAction("upload_foward_msg", async (params) => {
		const messages = asMessage(params.messages ?? params.message);
		if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
		if (!ctx.sendForwardMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		const result = await ctx.sendForwardMsg(messages);
		return okResponse({
			res_id: result.forwardId,
			forward_id: result.forwardId,
			message_id: 0
		});
	});
	h.registerAction("send_forward_msg", async (params) => {
		const messageType = asString(params.message_type);
		const groupId = asNumber(params.group_id);
		const userId = asNumber(params.user_id);
		const messages = asMessage(params.messages ?? params.message);
		if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
		if ((messageType === "group" || groupId > 0) && ctx.sendGroupForwardMsg) {
			if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
			const result = await ctx.sendGroupForwardMsg(groupId, messages);
			return okResponse({
				message_id: result.messageId,
				res_id: result.forwardId,
				forward_id: result.forwardId
			});
		}
		if ((messageType === "private" || userId > 0) && ctx.sendPrivateForwardMsg) {
			if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
			const result = await ctx.sendPrivateForwardMsg(userId, messages);
			return okResponse({
				message_id: result.messageId,
				res_id: result.forwardId,
				forward_id: result.forwardId
			});
		}
		if (!ctx.sendForwardMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		const result = await ctx.sendForwardMsg(messages);
		return okResponse({
			message_id: 0,
			res_id: result.forwardId,
			forward_id: result.forwardId
		});
	});
	h.registerAction("send_group_forward_msg", async (params) => {
		const groupId = asNumber(params.group_id);
		const messages = asMessage(params.messages ?? params.message);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
		if (!ctx.sendGroupForwardMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		const result = await ctx.sendGroupForwardMsg(groupId, messages);
		return okResponse({
			message_id: result.messageId,
			res_id: result.forwardId,
			forward_id: result.forwardId
		});
	});
	h.registerAction("send_private_forward_msg", async (params) => {
		const userId = asNumber(params.user_id);
		const messages = asMessage(params.messages ?? params.message);
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
		if (!ctx.sendPrivateForwardMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		const result = await ctx.sendPrivateForwardMsg(userId, messages);
		return okResponse({
			message_id: result.messageId,
			res_id: result.forwardId,
			forward_id: result.forwardId
		});
	});
	h.registerAction("get_forward_msg", async (params) => {
		let id = asString(params.id);
		if (!id) {
			const rawMessageId = params.message_id;
			const numericMessageId = asNumber(rawMessageId);
			if (numericMessageId > 0) {
				const event = ctx.getMessage(numericMessageId);
				const segments = Array.isArray(event?.message) ? event.message : [];
				for (const seg of segments) {
					if (typeof seg !== "object" || seg === null || Array.isArray(seg)) continue;
					const so = seg;
					if (String(so.type ?? "") !== "forward") continue;
					const data = typeof so.data === "object" && so.data !== null && !Array.isArray(so.data) ? so.data : null;
					const candidate = asString(data?.id) || asString(data?.res_id) || asString(data?.forward_id);
					if (candidate) {
						id = candidate;
						break;
					}
				}
			}
			if (!id) id = asString(rawMessageId);
		}
		if (!id) return failedResponse(RETCODE.BAD_REQUEST, "id or message_id is required");
		if (!ctx.getForwardMsg) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		return okResponse({ messages: await ctx.getForwardMsg(id) });
	});
	h.registerAction("get_image", async (params) => {
		const file = asString(params.file);
		if (!file) return failedResponse(RETCODE.BAD_REQUEST, "file is required");
		const imageInfo = findMediaInStore("image", file, ctx);
		if (imageInfo) return okResponse(imageInfo);
		return failedResponse(RETCODE.ACTION_FAILED, "image not found in cache");
	});
	h.registerAction("get_record", async (params) => {
		const file = asString(params.file);
		if (!file) return failedResponse(RETCODE.BAD_REQUEST, "file is required");
		const recordInfo = findMediaInStore("record", file, ctx);
		if (recordInfo) return okResponse(recordInfo);
		return failedResponse(RETCODE.ACTION_FAILED, "record not found in cache");
	});
	h.registerAction("get_cookies", async () => {
		return okResponse({ cookies: "" });
	});
	h.registerAction("get_csrf_token", async () => {
		return okResponse({ token: 0 });
	});
	h.registerAction("get_credentials", async () => {
		return okResponse({
			cookies: "",
			csrf_token: 0
		});
	});
	h.registerAction("set_restart", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not supported");
	});
	h.registerAction("clean_cache", async () => {
		return okResponse();
	});
	h.registerAction(".handle_quick_operation", async (params) => {
		const context = params.context;
		const operation = params.operation;
		if (!context || !operation) return failedResponse(RETCODE.BAD_REQUEST, "context and operation are required");
		const { executeQuickOperation } = await import("./http-post-transport-Cv2FtwNQ.js").then((n) => n.n);
		await executeQuickOperation(context, operation, h);
		return okResponse();
	});
	h.registerAction("set_friend_remark", async (params) => {
		const userId = asNumber(params.user_id);
		const remark = asString(params.remark) ?? "";
		if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
		if (!ctx.setFriendRemark) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setFriendRemark(userId, remark);
		return okResponse();
	});
	h.registerAction("set_msg_emoji_like", async (params) => {
		const messageId = asNumber(params.message_id);
		const emojiId = asString(params.emoji_id);
		const set = asBoolean(params.set, true);
		if (!Number.isInteger(messageId) || messageId === 0 || !emojiId) return failedResponse(RETCODE.BAD_REQUEST, "message_id and emoji_id are required");
		if (!ctx.setMsgEmojiLike) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		await ctx.setMsgEmojiLike(messageId, emojiId, set);
		return okResponse();
	});
	h.registerAction("mark_private_msg_as_read", async () => {
		return okResponse();
	});
	h.registerAction("mark_group_msg_as_read", async () => {
		return okResponse();
	});
	h.registerAction("_mark_all_as_read", async () => {
		return okResponse();
	});
	h.registerAction("get_group_file_system_info", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (ctx.getGroupFileCount) {
			const info = await ctx.getGroupFileCount(groupId);
			return okResponse({
				file_count: info.fileCount,
				limit_count: info.maxCount,
				used_space: 0,
				total_space: 10737418240
			});
		}
		return okResponse({
			file_count: 0,
			limit_count: 1e4,
			used_space: 0,
			total_space: 10737418240
		});
	});
	h.registerAction("check_url_safely", async () => {
		return okResponse({ level: 1 });
	});
	h.registerAction("download_file", async (params) => {
		const url = asString(params.url);
		const base64 = asString(params.base64);
		const name = asString(params.name);
		if (!url && !base64) return failedResponse(RETCODE.BAD_REQUEST, "url or base64 is required");
		const fs = await import("fs");
		const pathMod = await import("path");
		const cryptoMod = await import("crypto");
		const tempDir = pathMod.join("data", "downloads");
		if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
		let filePath;
		if (base64) {
			const buf = Buffer.from(base64, "base64");
			const fileName = name || cryptoMod.createHash("md5").update(buf).digest("hex");
			filePath = pathMod.join(tempDir, fileName);
			fs.writeFileSync(filePath, buf);
		} else {
			const response = await fetch(url, { headers: parseDownloadHeaders(params.headers) });
			if (!response.ok) return failedResponse(RETCODE.ACTION_FAILED, `download failed: ${response.status}`);
			const buf = Buffer.from(await response.arrayBuffer());
			const fileName = name || cryptoMod.createHash("md5").update(buf).digest("hex");
			filePath = pathMod.join(tempDir, fileName);
			fs.writeFileSync(filePath, buf);
		}
		return okResponse({ file: pathMod.resolve(filePath) });
	});
	h.registerAction("set_qq_profile", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("set_online_status", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_group_ignored_notifies", async () => {
		return okResponse([]);
	});
	h.registerAction("get_group_shut_list", async () => {
		return okResponse([]);
	});
	h.registerAction("forward_friend_single_msg", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("forward_group_single_msg", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_recent_contact", async () => {
		return okResponse([]);
	});
	h.registerAction("get_profile_like", async () => {
		return okResponse({});
	});
	h.registerAction("get_friends_with_category", async () => {
		if (ctx.getFriendList) return okResponse(await ctx.getFriendList());
		return okResponse([]);
	});
	h.registerAction("get_online_clients", async () => {
		return okResponse({ clients: [] });
	});
	h.registerAction("_get_model_show", async () => {
		return okResponse({ variants: [] });
	});
	h.registerAction("_set_model_show", async () => {
		return okResponse();
	});
	h.registerAction(".get_word_slices", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_group_at_all_remain", async () => {
		return okResponse({
			can_at_all: false,
			remain_at_all_count_for_group: 0,
			remain_at_all_count_for_uin: 0
		});
	});
	h.registerAction("get_unidirectional_friend_list", async () => {
		return okResponse([]);
	});
	h.registerAction("set_self_longnick", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_collection_list", async () => {
		return okResponse([]);
	});
	h.registerAction("create_collection", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("set_qq_avatar", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("set_input_status", async () => {
		return okResponse();
	});
	h.registerAction("translate_en2zh", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_clientkey", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_mini_app_ark", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("click_inline_keyboard_button", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("set_group_sign", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("send_group_sign", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_group_info_ex", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (ctx.getGroupInfo) return okResponse(await ctx.getGroupInfo(groupId));
		return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
	});
	h.registerAction("get_group_detail_info", async (params) => {
		const groupId = asNumber(params.group_id);
		if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
		if (ctx.getGroupInfo) return okResponse(await ctx.getGroupInfo(groupId));
		return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
	});
	h.registerAction("trans_group_file", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("rename_group_file", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction("get_file", async (params) => {
		if (!(asString(params.file_id) || asString(params.file))) return failedResponse(RETCODE.BAD_REQUEST, "file_id is required");
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
	h.registerAction(".send_packet", async () => {
		return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
	});
}
/**
* Search through cached message segments to find a media element (image/record)
* that matches the given file identifier.
*/
function findMediaInStore(mediaType, file, ctx) {
	return null;
}
/**
* Parse download_file headers parameter into a Record.
*/
function parseDownloadHeaders(headers) {
	const result = {};
	if (!headers) return result;
	const headerList = [];
	if (typeof headers === "string") headerList.push(...headers.split(/\r?\n/).filter(Boolean));
	else if (Array.isArray(headers)) {
		for (const h of headers) if (typeof h === "string") headerList.push(h);
	}
	for (const line of headerList) {
		const idx = line.indexOf("=");
		if (idx > 0) result[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
	}
	return result;
}
//#endregion
//#region src/onebot/api-handler.ts
var ApiHandler = class {
	handlers = /* @__PURE__ */ new Map();
	constructor(context) {
		register$7(this, context);
		register$6(this, context);
		register$5(this, context);
		register$4(this, context);
		register$3(this, context);
		register$2(this, context);
		register$1(this, context);
		register(this, context);
	}
	registerAction(action, handler) {
		this.handlers.set(action, handler);
	}
	async handle(action, params) {
		const handler = this.handlers.get(action);
		if (!handler) return failedResponse(RETCODE.UNKNOWN_ACTION, "unknown action");
		try {
			return await handler(params);
		} catch (error) {
			const message = error instanceof Error ? error.message : "internal error";
			return failedResponse(RETCODE.INTERNAL_ERROR, message);
		}
	}
	async processRequest(rawRequest) {
		if (!rawRequest.trim()) return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
		try {
			const parsed = JSON.parse(rawRequest);
			if (!isJsonObject(parsed)) return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
			const action = asString(parsed.action);
			if (!action) return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
			const params = isJsonObject(parsed.params) ? parsed.params : {};
			const echo = parsed.echo;
			const response = await this.handle(action, params);
			if (echo !== void 0) response.echo = toJsonValue(echo);
			return JSON.stringify(response);
		} catch {
			return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
		}
	}
};
function isJsonObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asString(value, fallback = "") {
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	return fallback;
}
function asNumber(value) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.trunc(value);
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return Math.trunc(n);
	}
	return 0;
}
function asBoolean(value, fallback) {
	if (typeof value === "boolean") return value;
	if (typeof value === "number") return value !== 0;
	if (typeof value === "string") {
		const text = value.trim().toLowerCase();
		if (text === "true" || text === "1" || text === "yes" || text === "on") return true;
		if (text === "false" || text === "0" || text === "no" || text === "off") return false;
	}
	return fallback;
}
function toJsonValue(value) {
	if (value === null) return null;
	if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
	if (Array.isArray(value)) return value.map(toJsonValue);
	if (isJsonObject(value)) {
		const obj = {};
		for (const [key, item] of Object.entries(value)) obj[key] = toJsonValue(item);
		return obj;
	}
	return String(value);
}
function asMessage(value) {
	if (value === void 0) return void 0;
	if (typeof value === "string") {
		const trimmed = value.trim();
		if (trimmed.startsWith("[") && trimmed.endsWith("]")) try {
			const parsed = JSON.parse(trimmed);
			if (Array.isArray(parsed)) return toJsonValue(parsed);
		} catch {}
	}
	return toJsonValue(value);
}
//#endregion
//#region src/onebot/message-id.ts
var GROUP_MESSAGE_EVENT = "group_message";
var PRIVATE_MESSAGE_EVENT = "private_message";
function hashMessageIdInt32(sequence, sessionId, eventName) {
	const key = `${Number.isFinite(sequence) ? Math.trunc(sequence) : 0}:${Number.isFinite(sessionId) ? Math.trunc(sessionId) : 0}:${eventName}`;
	let id = createHash$1("sha1").update(key).digest().readInt32BE(0);
	if (id === 0) id = 1;
	return id;
}
//#endregion
//#region src/onebot/event-converter.ts
var EventConverter = class {
	imageUrlResolver_ = null;
	mediaUrlResolver_ = null;
	messageIdResolver_ = null;
	setImageUrlResolver(resolver) {
		this.imageUrlResolver_ = resolver;
	}
	setMediaUrlResolver(resolver) {
		this.mediaUrlResolver_ = resolver;
	}
	setMessageIdResolver(resolver) {
		this.messageIdResolver_ = resolver;
	}
	async convert(instanceUin, event) {
		const selfId = parseSelfId(instanceUin);
		switch (event.kind) {
			case "friend_message": {
				const postType = event.senderUin === selfId ? "message_sent" : "message";
				const messageId = this.resolveMessageId(false, event.senderUin, event.msgSeq, PRIVATE_MESSAGE_EVENT);
				const segments = await elementsToJson(event.elements, false, event.senderUin, this.imageUrlResolver_, this.mediaUrlResolver_, this.messageIdResolver_);
				return {
					time: event.time,
					self_id: selfId,
					post_type: postType,
					message_type: "private",
					sub_type: "friend",
					message_id: messageId,
					message_seq: event.msgSeq,
					user_id: event.senderUin,
					message: segments,
					raw_message: segmentsToRawMessage(segments),
					font: 0,
					sender: {
						user_id: event.senderUin,
						nickname: event.senderNick,
						sex: "unknown",
						age: 0
					}
				};
			}
			case "group_message": {
				const postType = event.senderUin === selfId ? "message_sent" : "message";
				const messageId = this.resolveMessageId(true, event.groupId, event.msgSeq, GROUP_MESSAGE_EVENT);
				const segments = await elementsToJson(event.elements, true, event.groupId, this.imageUrlResolver_, this.mediaUrlResolver_, this.messageIdResolver_);
				return {
					time: event.time,
					self_id: selfId,
					post_type: postType,
					message_type: "group",
					sub_type: "normal",
					message_id: messageId,
					message_seq: event.msgSeq,
					group_id: event.groupId,
					user_id: event.senderUin,
					message: segments,
					raw_message: segmentsToRawMessage(segments),
					font: 0,
					sender: {
						user_id: event.senderUin,
						nickname: event.senderNick,
						card: event.senderCard,
						role: event.senderRole || "member",
						sex: "unknown",
						age: 0
					},
					anonymous: null
				};
			}
			case "temp_message": {
				const postType = event.senderUin === selfId ? "message_sent" : "message";
				const messageId = this.resolveMessageId(false, event.senderUin, event.msgSeq, PRIVATE_MESSAGE_EVENT);
				const segments = await elementsToJson(event.elements, false, event.senderUin, this.imageUrlResolver_, this.mediaUrlResolver_, this.messageIdResolver_);
				return {
					time: event.time,
					self_id: selfId,
					post_type: postType,
					message_type: "private",
					sub_type: "group",
					message_id: messageId,
					message_seq: event.msgSeq,
					user_id: event.senderUin,
					message: segments,
					raw_message: segmentsToRawMessage(segments),
					font: 0,
					sender: {
						user_id: event.senderUin,
						nickname: event.senderNick,
						sex: "unknown",
						age: 0
					}
				};
			}
			case "group_member_join": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "group_increase",
				sub_type: event.operatorUin === event.userUin ? "approve" : "invite",
				group_id: event.groupId,
				operator_id: event.operatorUin,
				user_id: event.userUin
			};
			case "group_member_leave": {
				let subType;
				if (event.isKick) subType = event.userUin === parseSelfId(instanceUin) ? "kick_me" : "kick";
				else subType = "leave";
				return {
					time: event.time,
					self_id: selfId,
					post_type: "notice",
					notice_type: "group_decrease",
					sub_type: subType,
					group_id: event.groupId,
					operator_id: event.operatorUin,
					user_id: event.userUin
				};
			}
			case "group_mute": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "group_ban",
				sub_type: event.duration > 0 ? "ban" : "lift_ban",
				group_id: event.groupId,
				operator_id: event.operatorUin,
				user_id: event.userUin,
				duration: event.duration
			};
			case "group_admin": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "group_admin",
				sub_type: event.set ? "set" : "unset",
				group_id: event.groupId,
				user_id: event.userUin
			};
			case "friend_recall": {
				const messageId = this.resolveMessageId(false, event.userUin, event.msgSeq, PRIVATE_MESSAGE_EVENT);
				return {
					time: event.time,
					self_id: selfId,
					post_type: "notice",
					notice_type: "friend_recall",
					user_id: event.userUin,
					message_id: messageId
				};
			}
			case "group_recall": {
				const messageId = this.resolveMessageId(true, event.groupId, event.msgSeq, GROUP_MESSAGE_EVENT);
				return {
					time: event.time,
					self_id: selfId,
					post_type: "notice",
					notice_type: "group_recall",
					group_id: event.groupId,
					operator_id: event.operatorUin,
					user_id: event.authorUin,
					message_id: messageId
				};
			}
			case "friend_request": return {
				time: event.time,
				self_id: selfId,
				post_type: "request",
				request_type: "friend",
				user_id: event.fromUin,
				comment: event.message,
				flag: event.flag
			};
			case "group_invite": return {
				time: event.time,
				self_id: selfId,
				post_type: "request",
				request_type: "group",
				sub_type: event.subType || "invite",
				group_id: event.groupId,
				user_id: event.fromUin,
				comment: event.message,
				flag: event.flag
			};
			case "friend_poke": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "notify",
				sub_type: "poke",
				user_id: event.userUin,
				target_id: event.targetUin,
				action: event.action,
				suffix: event.suffix,
				action_img_url: event.actionImgUrl
			};
			case "group_poke": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "notify",
				sub_type: "poke",
				group_id: event.groupId,
				user_id: event.userUin,
				target_id: event.targetUin,
				action: event.action,
				suffix: event.suffix,
				action_img_url: event.actionImgUrl
			};
			case "group_essence": {
				const messageId = this.resolveMessageId(true, event.groupId, event.msgSeq, GROUP_MESSAGE_EVENT);
				return {
					time: event.time,
					self_id: selfId,
					post_type: "notice",
					notice_type: "essence",
					sub_type: event.set ? "add" : "delete",
					group_id: event.groupId,
					user_id: event.senderUin,
					sender_id: event.senderUin,
					operator_id: event.operatorUin,
					message_id: messageId,
					message_seq: event.msgSeq,
					random: event.random
				};
			}
			case "group_file_upload": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "group_upload",
				group_id: event.groupId,
				user_id: event.userUin,
				file: {
					id: event.fileId,
					name: event.fileName,
					size: event.fileSize,
					busid: event.busId
				}
			};
			case "friend_add": return {
				time: event.time,
				self_id: selfId,
				post_type: "notice",
				notice_type: "friend_add",
				user_id: event.userUin
			};
			default: return null;
		}
	}
	resolveMessageId(isGroup, sessionId, sequence, eventName) {
		if (this.messageIdResolver_) {
			const resolved = this.messageIdResolver_(isGroup, sessionId, sequence, eventName);
			if (Number.isInteger(resolved) && resolved !== 0) return resolved;
		}
		const seq = Math.trunc(sequence);
		return seq === 0 ? 0 : seq;
	}
};
function parseSelfId(instanceUin) {
	const parsed = Number.parseInt(instanceUin, 10);
	return Number.isNaN(parsed) ? 0 : parsed;
}
async function elementsToJson(elements, isGroup, sessionId, resolver, mediaResolver, messageIdResolver) {
	const result = [];
	for (const element of elements) result.push(await elementToSegment(element, isGroup, sessionId, resolver, mediaResolver, messageIdResolver));
	return result;
}
async function elementsToOneBotSegments(elements, isGroup, sessionId, resolver, mediaResolver, messageIdResolver) {
	return elementsToJson(elements, isGroup, sessionId, resolver, mediaResolver, messageIdResolver);
}
async function elementToSegment(element, isGroup, sessionId, resolver, mediaResolver, messageIdResolver) {
	if (element.type === "text") return {
		type: "text",
		data: { text: element.text ?? "" }
	};
	if (element.type === "face") return {
		type: "face",
		data: { id: String(element.faceId ?? 0) }
	};
	if (element.type === "image") return {
		type: "image",
		data: {
			url: resolver ? resolver(element, isGroup) : element.imageUrl ?? "",
			file: element.fileId ?? ""
		}
	};
	if (element.type === "at") return {
		type: "at",
		data: { qq: element.uid === "all" || element.targetUin === 0 ? "all" : String(element.targetUin ?? 0) }
	};
	if (element.type === "reply") {
		const id = resolveReplyId(isGroup, sessionId, element.replySeq ?? 0, messageIdResolver);
		return {
			type: "reply",
			data: { id: String(id) }
		};
	}
	if (element.type === "record") {
		const url = mediaResolver ? await mediaResolver(element, isGroup, sessionId) : element.url ?? "";
		return {
			type: "record",
			data: {
				file: element.fileName ?? element.fileId ?? "",
				url
			}
		};
	}
	if (element.type === "video") {
		const url = mediaResolver ? await mediaResolver(element, isGroup, sessionId) : element.url ?? "";
		return {
			type: "video",
			data: {
				file: element.fileName ?? element.fileId ?? "",
				url
			}
		};
	}
	if (element.type === "json") return {
		type: "json",
		data: { data: element.text ?? "" }
	};
	if (element.type === "xml") return {
		type: "xml",
		data: {
			data: element.text ?? "",
			resid: element.subType ?? 35
		}
	};
	if (element.type === "file") {
		const url = mediaResolver ? await mediaResolver(element, isGroup, sessionId) : element.url ?? "";
		return {
			type: "file",
			data: {
				name: element.fileName ?? "",
				size: element.fileSize ?? 0,
				id: element.fileId ?? "",
				url,
				file_hash: element.fileHash ?? ""
			}
		};
	}
	if (element.type === "mface") return {
		type: "mface",
		data: {
			name: element.text ?? "",
			tab_id: element.faceId ?? 0,
			sub_type: element.subType ?? 0
		}
	};
	if (element.type === "poke") return {
		type: "poke",
		data: { type: element.subType ?? 0 }
	};
	if (!isGroup && element.type === "at") return {
		type: "text",
		data: { text: element.text ?? "" }
	};
	return {
		type: element.type,
		data: {}
	};
}
function cqEscape(text) {
	return text.replace(/&/g, "&amp;").replace(/\[/g, "&#91;").replace(/\]/g, "&#93;").replace(/,/g, "&#44;");
}
function segmentsToRawMessage(segments) {
	return segments.map((seg) => segmentToCQ(seg)).join("");
}
function segmentToCQ(seg) {
	const type = String(seg.type ?? "");
	const data = seg.data ?? {};
	switch (type) {
		case "text": return cqEscape(String(data.text ?? ""));
		case "face": return `[CQ:face,id=${data.id ?? 0}]`;
		case "image": return `[CQ:image,file=${cqEscape(String(data.file ?? ""))},url=${cqEscape(String(data.url ?? ""))}]`;
		case "at": return `[CQ:at,qq=${data.qq ?? ""}]`;
		case "reply": return `[CQ:reply,id=${data.id ?? 0}]`;
		case "record": return `[CQ:record,file=${cqEscape(String(data.file ?? ""))},url=${cqEscape(String(data.url ?? ""))}]`;
		case "video": return `[CQ:video,file=${cqEscape(String(data.file ?? ""))},url=${cqEscape(String(data.url ?? ""))}]`;
		case "json": return `[CQ:json,data=${cqEscape(String(data.data ?? ""))}]`;
		case "xml": return `[CQ:xml,data=${cqEscape(String(data.data ?? ""))}]`;
		case "forward": return `[CQ:forward,id=${cqEscape(String(data.id ?? ""))}]`;
		case "mface": return `[CQ:mface,name=${cqEscape(String(data.name ?? ""))}]`;
		case "poke": return `[CQ:poke,type=${data.type ?? 0}]`;
		case "file": return `[CQ:file,name=${cqEscape(String(data.name ?? ""))},size=${data.size ?? 0},id=${cqEscape(String(data.id ?? ""))},url=${cqEscape(String(data.url ?? ""))}]`;
		default: return `[CQ:${type}]`;
	}
}
function resolveReplyId(isGroup, sessionId, sequence, resolver) {
	const seq = Math.trunc(sequence);
	if (seq === 0) return 0;
	if (resolver) {
		const resolved = resolver(isGroup, sessionId, seq, isGroup ? GROUP_MESSAGE_EVENT : PRIVATE_MESSAGE_EVENT);
		if (Number.isInteger(resolved) && resolved !== 0) return resolved;
	}
	return seq;
}
//#endregion
//#region src/onebot/message-store.ts
var MessageStore = class {
	db;
	constructor(dbPath) {
		const dir = path.dirname(dbPath);
		fs.mkdirSync(dir, { recursive: true });
		this.db = new DatabaseSync(dbPath.replace(/\.json$/, ".db"));
		this.db.exec("PRAGMA journal_mode = WAL");
		this.db.exec("PRAGMA synchronous = NORMAL");
		this.initSchema();
	}
	close() {
		this.db.close();
	}
	storeEvent(messageId, isGroup, sessionId, sequence, eventName, event) {
		if (!isValidMessageId(messageId)) return;
		const json = JSON.stringify(event);
		const timestamp = toInt$1(event.time);
		this.db.prepare(`INSERT INTO messages
       (message_hash, is_group, session_id, sequence, event_name, client_sequence, random, timestamp, data)
       VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)
       ON CONFLICT(message_hash) DO UPDATE SET
         is_group = excluded.is_group,
         session_id = excluded.session_id,
         sequence = excluded.sequence,
         event_name = excluded.event_name,
         timestamp = excluded.timestamp,
         data = excluded.data`).run(messageId, isGroup ? 1 : 0, sessionId, sequence, eventName, timestamp, json);
	}
	storeMeta(messageId, meta) {
		if (!isValidMessageId(messageId)) return;
		this.db.prepare(`INSERT INTO messages
       (message_hash, is_group, session_id, sequence, event_name, client_sequence, random, timestamp)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(message_hash) DO UPDATE SET
         is_group = excluded.is_group,
         session_id = excluded.session_id,
         sequence = excluded.sequence,
         event_name = excluded.event_name,
         client_sequence = excluded.client_sequence,
         random = excluded.random,
         timestamp = excluded.timestamp`).run(messageId, meta.isGroup ? 1 : 0, meta.targetId, meta.sequence, meta.eventName, meta.clientSequence, meta.random, meta.timestamp);
	}
	findEvent(messageId) {
		if (!isValidMessageId(messageId)) return null;
		const row = this.db.prepare("SELECT data FROM messages WHERE message_hash = ? AND data IS NOT NULL").get(messageId);
		if (!row?.data) return null;
		try {
			return JSON.parse(row.data);
		} catch {
			return null;
		}
	}
	findMeta(messageId) {
		if (!isValidMessageId(messageId)) return null;
		const row = this.db.prepare("SELECT is_group, session_id, sequence, event_name, client_sequence, random, timestamp FROM messages WHERE message_hash = ?").get(messageId);
		if (!row) return null;
		return {
			isGroup: row.is_group === 1,
			targetId: row.session_id,
			sequence: row.sequence,
			eventName: row.event_name,
			clientSequence: row.client_sequence,
			random: row.random,
			timestamp: row.timestamp
		};
	}
	resolveReplySequence(isGroup, sessionId, messageId) {
		if (!Number.isInteger(sessionId) || sessionId <= 0 || !isValidMessageId(messageId)) return null;
		const row = isGroup ? this.db.prepare(`SELECT sequence
           FROM messages
           WHERE is_group = 1 AND session_id = ? AND message_hash = ?
           LIMIT 1`).get(sessionId, messageId) : this.db.prepare(`SELECT sequence
           FROM messages
           WHERE is_group = 0 AND message_hash = ?
           LIMIT 1`).get(messageId);
		if (!row || !Number.isInteger(row.sequence) || row.sequence <= 0) return null;
		return row.sequence;
	}
	listSessionEvents(isGroup, sessionId, count = 20, anchorSequence) {
		if (!Number.isInteger(sessionId) || sessionId <= 0) return [];
		const limit = normalizePositiveInt(count, 20, 200);
		const hasAnchor = Number.isInteger(anchorSequence) && anchorSequence > 0;
		const anchor = hasAnchor ? anchorSequence : 0;
		const rows = hasAnchor ? this.db.prepare(`SELECT data
         FROM messages
         WHERE is_group = ? AND session_id = ? AND data IS NOT NULL AND sequence <= ?
         ORDER BY sequence DESC
         LIMIT ?`).all(isGroup ? 1 : 0, sessionId, anchor, limit) : this.db.prepare(`SELECT data
         FROM messages
         WHERE is_group = ? AND session_id = ? AND data IS NOT NULL
         ORDER BY sequence DESC
         LIMIT ?`).all(isGroup ? 1 : 0, sessionId, limit);
		const result = [];
		for (const row of rows) {
			if (!row?.data) continue;
			try {
				const parsed = JSON.parse(row.data);
				result.push(parsed);
			} catch {}
		}
		result.reverse();
		return result;
	}
	initSchema() {
		this.db.exec(`
      CREATE TABLE IF NOT EXISTS messages (
        message_hash    INTEGER PRIMARY KEY,
        is_group        INTEGER NOT NULL,
        session_id      INTEGER NOT NULL,
        sequence        INTEGER NOT NULL,
        event_name      TEXT NOT NULL,
        client_sequence INTEGER NOT NULL DEFAULT 0,
        random          INTEGER NOT NULL DEFAULT 0,
        timestamp       INTEGER NOT NULL DEFAULT 0,
        data            TEXT
      )
    `);
		this.db.exec("CREATE INDEX IF NOT EXISTS idx_messages_session_seq ON messages(is_group, session_id, sequence)");
	}
};
function isValidMessageId(messageId) {
	return Number.isInteger(messageId) && messageId !== 0;
}
function toInt$1(value) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.trunc(value);
	if (typeof value === "string" && value.trim()) {
		const parsed = Number(value);
		if (Number.isFinite(parsed)) return Math.trunc(parsed);
	}
	return 0;
}
function normalizePositiveInt(value, fallback, max) {
	if (!Number.isFinite(value)) return fallback;
	const n = Math.trunc(value);
	if (n <= 0) return fallback;
	if (n > max) return max;
	return n;
}
//#endregion
//#region src/onebot/instance-rkey.ts
var log$7 = createLogger("OneBot");
var RKEY_REFRESH_SKEW = 60;
var RKEY_REFRESH_COOLDOWN = 30;
var PRIVATE_IMAGE_RKEY_TYPE = 10;
var GROUP_IMAGE_RKEY_TYPE = 20;
var PRIVATE_VIDEO_RKEY_TYPE = 12;
var GROUP_VIDEO_RKEY_TYPE = 22;
var PRIVATE_PTT_RKEY_TYPE = 14;
var GROUP_PTT_RKEY_TYPE = 24;
var FALLBACK_IMAGE_RKEY_TYPE = 2;
var RKeyCache = class {
	cache = /* @__PURE__ */ new Map();
	lastRefreshAttempt = 0;
	warmUp(bridge, uin) {
		bridge.fetchDownloadRKeys().then((rkeys) => {
			this.updateCache(rkeys);
			log$7.info("rkeys loaded: UIN=%s count=%d", uin, rkeys.length);
		}, (err) => {
			log$7.warn("failed to load rkeys for UIN %s: %s", uin, err instanceof Error ? err.message : String(err));
		});
	}
	resolveImageUrl(bridge, element, isGroup) {
		const url = element.imageUrl ?? "";
		if (!urlNeedsRKey(url)) return url;
		const rkey = this.findRKey(bridge, isGroup);
		if (!rkey) return url;
		const cleanRKey = stripRKeyPrefix(rkey);
		return url + (url.includes("?") ? "&rkey=" : "?rkey=") + encodeURIComponent(cleanRKey);
	}
	/**
	* Resolve a URL for video/record/file media elements.
	* Appends the correct RKey type based on media kind and group/private context.
	*/
	resolveMediaUrl(bridge, element, isGroup) {
		const url = element.url ?? "";
		if (!url || !urlNeedsRKey(url)) return url;
		const mediaType = element.type;
		let primaryType;
		if (mediaType === "video") primaryType = isGroup ? GROUP_VIDEO_RKEY_TYPE : PRIVATE_VIDEO_RKEY_TYPE;
		else if (mediaType === "record") primaryType = isGroup ? GROUP_PTT_RKEY_TYPE : PRIVATE_PTT_RKEY_TYPE;
		else primaryType = isGroup ? GROUP_IMAGE_RKEY_TYPE : PRIVATE_IMAGE_RKEY_TYPE;
		const rkey = this.findRKeyForType(bridge, primaryType);
		if (!rkey) return url;
		const cleanRKey = stripRKeyPrefix(rkey);
		return url + (url.includes("?") ? "&rkey=" : "?rkey=") + encodeURIComponent(cleanRKey);
	}
	updateCache(rkeys) {
		const now = Math.floor(Date.now() / 1e3);
		for (const rk of rkeys) {
			if (!rk.rkey || !rk.type) continue;
			const baseTime = rk.createTime || now;
			const ttl = rk.ttlSeconds || 3600;
			this.cache.set(rk.type, {
				value: rk.rkey,
				type: rk.type,
				createTime: rk.createTime,
				ttlSeconds: rk.ttlSeconds,
				expiresAt: baseTime + ttl
			});
		}
	}
	findRKey(bridge, isGroup) {
		const primaryType = isGroup ? GROUP_IMAGE_RKEY_TYPE : PRIVATE_IMAGE_RKEY_TYPE;
		return this.findRKeyForType(bridge, primaryType);
	}
	findRKeyForType(bridge, primaryType) {
		const now = Math.floor(Date.now() / 1e3);
		const tryFind = (type) => {
			const cached = this.cache.get(type);
			if (!cached || !cached.value) return null;
			if (cached.expiresAt !== 0 && now + RKEY_REFRESH_SKEW >= cached.expiresAt) return null;
			return cached.value;
		};
		let result = tryFind(primaryType) ?? tryFind(FALLBACK_IMAGE_RKEY_TYPE);
		if (result) return result;
		if (now - this.lastRefreshAttempt < RKEY_REFRESH_COOLDOWN) return null;
		this.lastRefreshAttempt = now;
		bridge.fetchDownloadRKeys().then((rkeys) => this.updateCache(rkeys), () => {});
		result = tryFind(primaryType) ?? tryFind(FALLBACK_IMAGE_RKEY_TYPE);
		return result;
	}
};
function urlNeedsRKey(url) {
	if (!url || url.includes("rkey=")) return false;
	if (url.includes("gchat.qpic.cn")) return false;
	return url.includes("multimedia.nt.qq.com.cn") || url.includes(".nt.qq.com.cn") || url.includes("/download");
}
function stripRKeyPrefix(rkey) {
	for (const prefix of ["&rkey=", "?rkey="]) if (rkey.startsWith(prefix)) return rkey.slice(prefix.length);
	return rkey;
}
//#endregion
//#region src/onebot/message-parser.ts
var CQ_REGEX = /\[CQ:([a-z]+)(?:,([^\]]*))?\]/g;
function parseCQParams(raw) {
	const params = {};
	if (!raw) return params;
	for (const pair of raw.split(",")) {
		const eq = pair.indexOf("=");
		if (eq > 0) params[pair.substring(0, eq)] = pair.substring(eq + 1).replace(/&#91;/g, "[").replace(/&#93;/g, "]").replace(/&#44;/g, ",").replace(/&amp;/g, "&");
	}
	return params;
}
function cqUnescape(text) {
	return text.replace(/&#91;/g, "[").replace(/&#93;/g, "]").replace(/&amp;/g, "&");
}
async function parseFromCQString(message, options) {
	const elements = [];
	let lastIndex = 0;
	for (const match of message.matchAll(CQ_REGEX)) {
		if (match.index > lastIndex) {
			const text = cqUnescape(message.substring(lastIndex, match.index));
			if (text) elements.push({
				type: "text",
				text
			});
		}
		lastIndex = match.index + match[0].length;
		const cqType = match[1];
		const elem = await segmentToElement(cqType, parseCQParams(match[2] || ""), options);
		if (elem) elements.push(elem);
	}
	if (lastIndex < message.length) {
		const text = cqUnescape(message.substring(lastIndex));
		if (text) elements.push({
			type: "text",
			text
		});
	}
	return elements;
}
function isSegmentArray(val) {
	return Array.isArray(val) && val.every((item) => typeof item === "object" && item !== null && "type" in item);
}
async function segmentToElement(type, data, options) {
	switch (type) {
		case "text": {
			const text = String(data.text ?? "");
			return text ? {
				type: "text",
				text
			} : null;
		}
		case "face": return {
			type: "face",
			faceId: parseInt(String(data.id ?? "0"), 10)
		};
		case "at": {
			const qq = String(data.qq ?? "").trim();
			if (qq === "all") return {
				type: "at",
				targetUin: 0,
				uid: "all",
				text: "@全体成员 "
			};
			const uin = parseInt(qq, 10);
			if (uin <= 0) return null;
			const name = String(data.name ?? data.nickname ?? data.card ?? "").trim();
			let uid = String(data.uid ?? "").trim();
			if (!uid && options?.resolveMentionUid) uid = (await options.resolveMentionUid(uin))?.trim() ?? "";
			return {
				type: "at",
				targetUin: uin,
				uid: uid || void 0,
				text: name ? `@${name} ` : `@${uin} `
			};
		}
		case "reply": {
			const id = parseInt(String(data.id ?? "0"), 10);
			if (!Number.isInteger(id) || id === 0) return null;
			if (options?.resolveReplySequence) {
				const resolved = options.resolveReplySequence(id);
				if (typeof resolved === "number" && resolved > 0) {
					const element = {
						type: "reply",
						replySeq: resolved,
						replyMessageId: id
					};
					if (options?.resolveReplyMeta) {
						const meta = options.resolveReplyMeta(id);
						if (meta) {
							element.replySenderUin = meta.senderUin;
							element.replyTime = meta.time;
							element.replyRandom = meta.random;
						}
					}
					return element;
				}
			}
			return id > 0 ? {
				type: "reply",
				replySeq: id
			} : null;
		}
		case "image": return {
			type: "image",
			url: String(data.file ?? data.url ?? ""),
			flash: data.type === "flash",
			subType: parseInt(String(data.subType ?? "0"), 10),
			summary: data.summary ? String(data.summary) : void 0
		};
		case "record": return {
			type: "record",
			url: String(data.file ?? data.url ?? "")
		};
		case "video": return {
			type: "video",
			url: String(data.file ?? data.url ?? "")
		};
		case "json": return {
			type: "json",
			text: String(data.data ?? "")
		};
		case "xml": return {
			type: "xml",
			text: String(data.data ?? ""),
			subType: parseInt(String(data.id ?? "0"), 10)
		};
		case "poke": return {
			type: "poke",
			faceId: parseInt(String(data.type ?? data.id ?? "0"), 10)
		};
		case "forward": return {
			type: "forward",
			resId: String(data.id ?? "")
		};
		case "node": {
			const uin = String(data.user_id ?? data.uin ?? "0");
			const name = String(data.nickname ?? data.name ?? "");
			return {
				type: "node",
				targetUin: parseInt(uin, 10) || 0,
				text: name,
				resId: JSON.stringify(data.content ?? "")
			};
		}
		case "markdown": return {
			type: "markdown",
			text: String(data.content ?? "")
		};
		case "share": {
			const url = String(data.url ?? "");
			const title = String(data.title ?? "");
			const content = String(data.content ?? "");
			const image = String(data.image ?? "");
			return {
				type: "json",
				text: JSON.stringify({
					app: "com.tencent.structmsg",
					view: "news",
					prompt: title,
					meta: { news: {
						title,
						desc: content,
						jumpUrl: url,
						preview: image
					} }
				})
			};
		}
		case "music": {
			const musicType = String(data.type ?? "");
			const signUrl = options?.musicSignUrl || "https://ss.xingzhige.com/music_card/card";
			try {
				let postData;
				if (musicType === "custom") postData = {
					type: "custom",
					id: void 0,
					url: String(data.url ?? ""),
					audio: String(data.audio ?? ""),
					title: String(data.title ?? ""),
					image: String(data.image ?? ""),
					singer: String(data.content ?? "")
				};
				else postData = {
					type: musicType,
					id: String(data.id ?? "")
				};
				const resp = await fetch(signUrl, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(postData)
				});
				if (!resp.ok) throw new Error(`music sign HTTP ${resp.status}`);
				return {
					type: "json",
					text: await resp.text()
				};
			} catch (e) {
				console.warn(`[MsgParser] music sign failed: ${e}, falling back to local card`);
				const title = String(data.title ?? "Music");
				return {
					type: "json",
					text: JSON.stringify({
						app: "com.tencent.structmsg",
						view: "music",
						prompt: `[音乐]${title}`,
						meta: { music: {
							title,
							desc: String(data.content ?? ""),
							jumpUrl: String(data.url ?? ""),
							musicUrl: String(data.audio ?? ""),
							preview: String(data.image ?? "")
						} }
					})
				};
			}
		}
		case "location": {
			const lat = String(data.lat ?? "");
			const lon = String(data.lon ?? "");
			const title = String(data.title ?? "位置");
			const content = String(data.content ?? `${lat},${lon}`);
			return {
				type: "json",
				text: JSON.stringify({
					app: "com.tencent.map",
					view: "LocationShare",
					prompt: `[位置]${title}`,
					meta: { Location: {
						lat,
						lng: lon,
						title,
						address: content
					} }
				})
			};
		}
		case "contact": {
			const contactType = String(data.type ?? "qq");
			const contactId = String(data.id ?? "");
			return {
				type: "json",
				text: JSON.stringify({
					app: "com.tencent.contact.lua",
					view: "contact",
					prompt: `[推荐${contactType === "group" ? "群" : "好友"}]`,
					meta: { contact: {
						type: contactType,
						id: contactId
					} }
				})
			};
		}
		case "rps": return {
			type: "face",
			faceId: 359
		};
		case "dice": return {
			type: "face",
			faceId: 358
		};
		case "shake": return {
			type: "poke",
			faceId: 1
		};
		case "anonymous": return null;
		default:
			console.warn(`[MsgParser] unsupported segment type: ${type}`);
			return null;
	}
}
/**
* Parse an OneBot11 message value into internal MessageElement array.
* Supports:
*  - string (plain text or CQ code string)
*  - array of { type, data } segments (JSON segment format)
*
* If autoEscape is true, the string is treated as plain text (no CQ parsing).
*/
async function parseMessage(message, autoEscape, options) {
	if (typeof message === "string") {
		if (autoEscape) return message ? [{
			type: "text",
			text: message
		}] : [];
		return parseFromCQString(message, options);
	}
	if (isSegmentArray(message)) {
		const elements = [];
		for (const seg of message) {
			const data = seg.data ?? {};
			const elem = await segmentToElement(seg.type, data, options);
			if (elem) elements.push(elem);
		}
		return elements;
	}
	if (typeof message === "object" && message !== null && !Array.isArray(message)) {
		const seg = message;
		if (seg.type) {
			const data = seg.data ?? {};
			const elem = await segmentToElement(seg.type, data, options);
			return elem ? [elem] : [];
		}
	}
	return [];
}
//#endregion
//#region src/onebot/instance-context.ts
var log$6 = createLogger("OneBot");
function buildApiContext(ref) {
	const { bridge, qqInfo, messageStore } = ref;
	return {
		getLoginInfo: () => getLoginInfo(ref),
		isOnline: () => true,
		getMessage: (messageId) => messageStore.findEvent(messageId),
		getMessageMeta: (messageId) => messageStore.findMeta(messageId),
		canSendImage: () => true,
		canSendRecord: () => false,
		sendPrivateMessage: (userId, message, autoEscape) => handleSendPrivate(ref, userId, message, autoEscape),
		sendGroupMessage: (groupId, message, autoEscape) => handleSendGroup(ref, groupId, message, autoEscape),
		deleteMessage: (messageId, meta) => handleDeleteMessage(bridge, meta),
		getFriendList: () => handleGetFriendList(bridge, qqInfo),
		getGroupList: (noCache) => handleGetGroupList(bridge, qqInfo, noCache),
		getGroupInfo: (groupId, noCache) => handleGetGroupInfo(bridge, qqInfo, groupId, noCache),
		getGroupMemberList: (groupId, noCache) => handleGetGroupMemberList(bridge, qqInfo, groupId, noCache),
		getGroupMemberInfo: (groupId, userId, noCache) => handleGetGroupMemberInfo(bridge, qqInfo, groupId, userId, noCache),
		getStrangerInfo: (userId) => handleGetStrangerInfo(bridge, qqInfo, userId),
		setGroupKick: (groupId, userId, reject) => bridge.kickGroupMember(groupId, userId, reject),
		setGroupBan: (groupId, userId, duration) => bridge.muteGroupMember(groupId, userId, duration),
		setGroupWholeBan: (groupId, enable) => bridge.muteGroupAll(groupId, enable),
		setGroupAdmin: (groupId, userId, enable) => bridge.setGroupAdmin(groupId, userId, enable),
		setGroupCard: (groupId, userId, card) => bridge.setGroupCard(groupId, userId, card),
		setGroupName: (groupId, name) => bridge.setGroupName(groupId, name),
		setGroupLeave: (groupId) => bridge.leaveGroup(groupId),
		setGroupSpecialTitle: (groupId, userId, title) => bridge.setGroupSpecialTitle(groupId, userId, title),
		uploadGroupFile: async (groupId, file, name, folderId, uploadFile) => {
			return (await bridge.uploadGroupFile(groupId, file, name ?? "", folderId ?? "/", uploadFile ?? true)).fileId;
		},
		uploadPrivateFile: async (userId, file, name, uploadFile) => {
			return (await bridge.uploadPrivateFile(userId, file, name ?? "", uploadFile ?? true)).fileId;
		},
		getGroupFileUrl: (groupId, fileId, busId) => bridge.fetchGroupFileUrl(groupId, fileId, busId ?? 102),
		getGroupFiles: (groupId, folderId) => handleGetGroupFiles(bridge, groupId, folderId),
		deleteGroupFile: (groupId, fileId) => bridge.deleteGroupFile(groupId, fileId),
		moveGroupFile: (groupId, fileId, parentDirectory, targetDirectory) => bridge.moveGroupFile(groupId, fileId, parentDirectory, targetDirectory),
		createGroupFileFolder: (groupId, name, parentId) => bridge.createGroupFileFolder(groupId, name, parentId ?? "/"),
		deleteGroupFileFolder: (groupId, folderId) => bridge.deleteGroupFileFolder(groupId, folderId),
		renameGroupFileFolder: (groupId, folderId, newName) => bridge.renameGroupFileFolder(groupId, folderId, newName),
		getPrivateFileUrl: (userId, fileId, fileHash) => bridge.fetchPrivateFileUrl(userId, fileId, fileHash),
		handleFriendRequest: (flag, approve) => bridge.setFriendAddRequest(flag, approve),
		handleGroupRequest: (flag, _subType, approve, reason) => handleGroupAddRequest(bridge, flag, approve, reason),
		sendLike: (userId, times) => bridge.sendLike(userId, times),
		sendFriendPoke: (userId, targetId) => bridge.sendPoke(false, userId, targetId),
		sendGroupPoke: (groupId, userId) => bridge.sendPoke(true, groupId, userId),
		setEssenceMsg: (messageId) => handleSetEssence(bridge, messageStore, messageId, true),
		deleteEssenceMsg: (messageId) => handleSetEssence(bridge, messageStore, messageId, false),
		setGroupReaction: (groupId, sequence, code, isSet) => bridge.setGroupReaction(groupId, sequence, code, isSet),
		handleDeleteFriend: (userId, block) => bridge.deleteFriend(userId, !!block),
		getGroupMsgHistory: (groupId, messageId, count) => handleGetGroupMsgHistory(messageStore, groupId, messageId, count),
		getFriendMsgHistory: (userId, messageId, count) => handleGetFriendMsgHistory(messageStore, userId, messageId, count),
		handleGetGroupSystemMsg: async () => {
			try {
				return (await bridge.fetchGroupRequests()).map((r) => ({
					group_id: r.groupId,
					group_name: r.groupName,
					request_id: r.sequence,
					requester_uin: r.targetUin,
					requester_nick: r.targetName,
					message: r.comment,
					flag: `${r.eventType}:${r.groupId}:${r.targetUid}`
				}));
			} catch {
				return [];
			}
		},
		getDownloadRKeys: async () => {
			try {
				return (await bridge.fetchDownloadRKeys()).map((r) => ({
					rkey: r.rkey,
					type: r.type,
					ttl: r.ttlSeconds,
					create_time: r.createTime
				}));
			} catch {
				return [];
			}
		},
		sendGroupForwardMsg: async (groupId, messages) => {
			return handleSendGroupForward(ref, groupId, messages);
		},
		sendPrivateForwardMsg: async (userId, messages) => {
			return handleSendPrivateForward(ref, userId, messages);
		},
		sendForwardMsg: async (messages) => {
			return handleUploadForward(ref, messages);
		},
		getForwardMsg: async (resId) => {
			return handleGetForward(ref, resId);
		},
		setFriendRemark: (userId, remark) => bridge.setFriendRemark(userId, remark),
		getGroupFileCount: (groupId) => bridge.fetchGroupFileCount(groupId),
		setMsgEmojiLike: async (messageId, emojiId, set) => {
			const meta = messageStore.findMeta(messageId);
			if (!meta || !meta.isGroup) throw new Error("message not found or not a group message");
			await bridge.setGroupReaction(meta.targetId, meta.sequence, emojiId, set);
		}
	};
}
function getLoginInfo(ref) {
	return {
		userId: parseInt(ref.uin, 10) || 0,
		nickname: ref.qqInfo.nickname || ref.uin
	};
}
async function refreshSingleGroupMembers(bridge, groupId) {
	try {
		await bridge.fetchGroupMemberList(groupId);
	} catch {}
}
function normalizeHistoryCount(count) {
	if (!Number.isFinite(count)) return 20;
	const n = Math.trunc(count);
	if (n <= 0) return 20;
	if (n > 200) return 200;
	return n;
}
function sanitizeMessageEventForApi(event) {
	const result = { ...event };
	delete result.post_type;
	delete result.self_id;
	result.real_id = result.message_id ?? 0;
	return result;
}
async function handleGetFriendList(bridge, qqInfo) {
	try {
		return (await bridge.fetchFriendList()).map((f) => ({
			user_id: f.uin,
			nickname: f.nickname,
			remark: f.remark
		}));
	} catch {
		return qqInfo.friends.map((f) => ({
			user_id: f.uin,
			nickname: f.nickname,
			remark: f.remark
		}));
	}
}
async function handleGetGroupList(bridge, qqInfo, noCache) {
	try {
		if (noCache || qqInfo.groups.length === 0) await bridge.fetchGroupList();
	} catch {}
	return qqInfo.groups.map((g) => ({
		group_id: g.groupId,
		group_name: g.groupName,
		member_count: g.memberCount,
		max_member_count: g.memberMax
	}));
}
async function handleGetGroupInfo(bridge, qqInfo, groupId, noCache) {
	if (noCache || !qqInfo.findGroup(groupId)) try {
		await bridge.fetchGroupList();
	} catch {}
	const g = qqInfo.findGroup(groupId);
	if (!g) return null;
	return {
		group_id: g.groupId,
		group_name: g.groupName,
		member_count: g.memberCount,
		max_member_count: g.memberMax
	};
}
async function handleGetGroupMemberList(bridge, qqInfo, groupId, noCache) {
	if (noCache) {
		await refreshSingleGroupMembers(bridge, groupId);
		const g = qqInfo.findGroup(groupId);
		if (!g) return [];
		const result = [];
		for (const [, m] of g.members) result.push({
			group_id: groupId,
			user_id: m.uin,
			nickname: m.nickname,
			card: m.card,
			sex: "unknown",
			age: 0,
			join_time: m.joinTime,
			last_sent_time: m.lastSentTime,
			level: String(m.level),
			role: m.role,
			title: m.title
		});
		return result;
	}
	try {
		return (await bridge.fetchGroupMemberList(groupId)).map((m) => ({
			group_id: groupId,
			user_id: m.uin,
			nickname: m.nickname,
			card: m.card,
			sex: "unknown",
			age: 0,
			join_time: m.joinTime,
			last_sent_time: m.lastSentTime,
			level: String(m.level),
			role: m.role,
			title: m.title
		}));
	} catch {
		const g = qqInfo.findGroup(groupId);
		if (!g) return [];
		const result = [];
		for (const [, m] of g.members) result.push({
			group_id: groupId,
			user_id: m.uin,
			nickname: m.nickname,
			card: m.card,
			sex: "unknown",
			age: 0,
			join_time: m.joinTime,
			last_sent_time: m.lastSentTime,
			level: String(m.level),
			role: m.role,
			title: m.title
		});
		return result;
	}
}
async function handleGetGroupMemberInfo(bridge, qqInfo, groupId, userId, noCache) {
	if (noCache || !qqInfo.findGroupMember(groupId, userId)) await refreshSingleGroupMembers(bridge, groupId);
	const m = qqInfo.findGroupMember(groupId, userId);
	if (!m) return null;
	return {
		group_id: groupId,
		user_id: m.uin,
		nickname: m.nickname,
		card: m.card,
		sex: "unknown",
		age: 0,
		join_time: m.joinTime,
		last_sent_time: m.lastSentTime,
		level: String(m.level),
		role: m.role,
		title: m.title
	};
}
async function handleGetGroupFiles(bridge, groupId, folderId) {
	const result = await bridge.fetchGroupFiles(groupId, folderId ?? "/");
	return {
		files: result.files.map((file) => ({
			group_id: groupId,
			file_id: file.fileId,
			file_name: file.fileName,
			busid: file.busId,
			file_size: file.fileSize,
			upload_time: file.uploadTime,
			dead_time: file.deadTime,
			modify_time: file.modifyTime,
			download_times: file.downloadTimes,
			uploader: file.uploader,
			uploader_name: file.uploaderName
		})),
		folders: result.folders.map((folder) => ({
			group_id: groupId,
			folder_id: folder.folderId,
			folder_name: folder.folderName,
			create_time: folder.createTime,
			creator: folder.creator,
			create_name: folder.creatorName,
			total_file_count: folder.totalFileCount
		}))
	};
}
async function handleGetStrangerInfo(bridge, qqInfo, userId) {
	try {
		const p = await bridge.fetchUserProfile(userId);
		return {
			user_id: p.uin,
			nickname: p.nickname,
			sex: p.sex,
			age: p.age
		};
	} catch {
		const p = qqInfo.findUserProfile(userId);
		if (!p) return null;
		return {
			user_id: p.uin,
			nickname: p.nickname,
			sex: p.sex,
			age: p.age
		};
	}
}
async function handleGetGroupMsgHistory(messageStore, groupId, messageId, count) {
	if (!Number.isInteger(groupId) || groupId <= 0) return [];
	const limit = normalizeHistoryCount(count);
	let anchorSequence;
	if (Number.isInteger(messageId) && messageId !== 0) {
		const meta = messageStore.findMeta(messageId);
		if (!meta || !meta.isGroup || meta.targetId !== groupId || meta.sequence <= 0) return [];
		anchorSequence = meta.sequence;
	}
	return messageStore.listSessionEvents(true, groupId, limit, anchorSequence).filter((event) => {
		if (event.message_type !== "group") return false;
		const gid = Number(event.group_id ?? 0);
		return Number.isFinite(gid) && Math.trunc(gid) === groupId;
	}).map(sanitizeMessageEventForApi);
}
async function handleGetFriendMsgHistory(messageStore, userId, messageId, count) {
	if (!Number.isInteger(userId) || userId <= 0) return [];
	const limit = normalizeHistoryCount(count);
	let anchorSequence;
	if (Number.isInteger(messageId) && messageId !== 0) {
		const meta = messageStore.findMeta(messageId);
		if (!meta || meta.isGroup || meta.targetId !== userId || meta.sequence <= 0) return [];
		anchorSequence = meta.sequence;
	}
	return messageStore.listSessionEvents(false, userId, limit, anchorSequence).filter((event) => {
		if (event.message_type !== "private") return false;
		const uid = Number(event.user_id ?? 0);
		return Number.isFinite(uid) && Math.trunc(uid) === userId;
	}).map(sanitizeMessageEventForApi);
}
async function handleDeleteMessage(bridge, meta) {
	if (meta.isGroup) await bridge.recallGroupMessage(meta.targetId, meta.sequence);
	else await bridge.recallPrivateMessage(meta.targetId, meta.clientSequence, meta.sequence, meta.random, meta.timestamp);
}
async function handleGroupAddRequest(bridge, flag, approve, reason) {
	const parts = flag.split(":");
	if (parts.length < 3) throw new Error("invalid group request flag");
	const groupId = parseInt(parts[1], 10);
	if (!groupId) throw new Error("invalid group_id in flag");
	const matching = (await bridge.fetchGroupRequests()).find((r) => r.groupId === groupId);
	if (matching) await bridge.setGroupAddRequest(groupId, matching.sequence, matching.eventType, approve, reason, matching.filtered);
	else throw new Error("matching group request not found");
}
async function handleSetEssence(bridge, messageStore, messageId, enable) {
	const meta = messageStore.findMeta(messageId);
	if (!meta || !meta.isGroup) throw new Error("message not found or not a group message");
	await bridge.setGroupEssence(meta.targetId, meta.sequence, meta.random, enable);
}
function logSentMessage(isGroup, targetId, elements) {
	const type = isGroup ? "群聊" : "私聊";
	const parts = [];
	const replyElem = elements.find((e) => e.type === "reply");
	if (replyElem && replyElem.replyMessageId) parts.push(`[回复:${replyElem.replyMessageId}]`);
	for (const elem of elements) {
		if (elem.type === "reply") continue;
		switch (elem.type) {
			case "text":
				if (elem.text) {
					const preview = elem.text.length > 50 ? elem.text.substring(0, 50) + "..." : elem.text;
					parts.push(preview);
				}
				break;
			case "image":
				parts.push("[图片]");
				break;
			case "face":
				parts.push("[表情]");
				break;
			case "at":
				if (elem.text) parts.push(elem.text.trim());
				break;
			case "record":
				parts.push("[语音]");
				break;
			case "video":
				parts.push("[视频]");
				break;
			case "json":
				parts.push("[JSON消息]");
				break;
			case "xml":
				parts.push("[XML消息]");
				break;
			case "markdown":
				parts.push("[Markdown]");
				break;
			case "forward":
				parts.push("[转发消息]");
				break;
			case "poke":
				parts.push("[戳一戳]");
				break;
			default: break;
		}
	}
	const content = parts.join(" ").trim() || "[空消息]";
	log$6.info(`${type} ${targetId} | 发送：${content}`);
}
async function handleSendPrivate(ref, userId, message, autoEscape) {
	const elements = await parseMessage(message, autoEscape, {
		resolveReplySequence: (replyMessageId) => {
			return ref.messageStore.resolveReplySequence(false, userId, replyMessageId);
		},
		resolveReplyMeta: (replyMessageId) => {
			const meta = ref.messageStore.findMeta(replyMessageId);
			if (meta) return {
				senderUin: meta.targetId,
				time: meta.timestamp,
				random: meta.random
			};
			return null;
		},
		resolveMentionUid: (targetUin) => ref.bridge.resolveUserUid(targetUin),
		musicSignUrl: ref.musicSignUrl
	});
	if (elements.length === 0) throw new Error("message is empty");
	const receipt = await ref.bridge.sendPrivateMessage(userId, elements);
	const messageId = hashMessageIdInt32(receipt.sequence, userId, PRIVATE_MESSAGE_EVENT);
	logSentMessage(false, userId, elements);
	ref.cacheMessageMeta(messageId, {
		isGroup: false,
		targetId: userId,
		sequence: receipt.sequence,
		eventName: PRIVATE_MESSAGE_EVENT,
		clientSequence: receipt.clientSequence,
		random: receipt.random,
		timestamp: receipt.timestamp
	});
	return { messageId };
}
async function handleSendGroup(ref, groupId, message, autoEscape) {
	const elements = await parseMessage(message, autoEscape, {
		resolveReplySequence: (replyMessageId) => {
			return ref.messageStore.resolveReplySequence(true, groupId, replyMessageId);
		},
		resolveReplyMeta: (replyMessageId) => {
			const event = ref.messageStore.findEvent(replyMessageId);
			if (event) return {
				senderUin: typeof event.user_id === "number" ? event.user_id : parseInt(String(event.user_id || "0"), 10),
				time: typeof event.time === "number" ? event.time : parseInt(String(event.time || "0"), 10),
				random: 0
			};
			return null;
		},
		resolveMentionUid: (targetUin) => ref.bridge.resolveUserUid(targetUin, groupId),
		musicSignUrl: ref.musicSignUrl
	});
	if (elements.length === 0) throw new Error("message is empty");
	const receipt = await ref.bridge.sendGroupMessage(groupId, elements);
	const messageId = hashMessageIdInt32(receipt.sequence, groupId, GROUP_MESSAGE_EVENT);
	logSentMessage(true, groupId, elements);
	ref.cacheMessageMeta(messageId, {
		isGroup: true,
		targetId: groupId,
		sequence: receipt.sequence,
		eventName: GROUP_MESSAGE_EVENT,
		clientSequence: receipt.clientSequence,
		random: receipt.random,
		timestamp: receipt.timestamp
	});
	return { messageId };
}
async function handleSendGroupForward(ref, groupId, messages) {
	const nodes = await parseForwardNodes(ref, messages);
	const forwardId = await ref.bridge.uploadForwardNodes(nodes, groupId);
	const receipt = await ref.bridge.sendGroupMessage(groupId, [{
		type: "forward",
		resId: forwardId
	}]);
	const messageId = hashMessageIdInt32(receipt.sequence, groupId, GROUP_MESSAGE_EVENT);
	ref.cacheMessageMeta(messageId, {
		isGroup: true,
		targetId: groupId,
		sequence: receipt.sequence,
		eventName: GROUP_MESSAGE_EVENT,
		clientSequence: receipt.clientSequence,
		random: receipt.random,
		timestamp: receipt.timestamp
	});
	return {
		messageId,
		forwardId
	};
}
async function handleSendPrivateForward(ref, userId, messages) {
	const nodes = await parseForwardNodes(ref, messages);
	const forwardId = await ref.bridge.uploadForwardNodes(nodes);
	const receipt = await ref.bridge.sendPrivateMessage(userId, [{
		type: "forward",
		resId: forwardId
	}]);
	const messageId = hashMessageIdInt32(receipt.sequence, userId, PRIVATE_MESSAGE_EVENT);
	ref.cacheMessageMeta(messageId, {
		isGroup: false,
		targetId: userId,
		sequence: receipt.sequence,
		eventName: PRIVATE_MESSAGE_EVENT,
		clientSequence: receipt.clientSequence,
		random: receipt.random,
		timestamp: receipt.timestamp
	});
	return {
		messageId,
		forwardId
	};
}
async function handleUploadForward(ref, messages) {
	const nodes = await parseForwardNodes(ref, messages);
	return { forwardId: await ref.bridge.uploadForwardNodes(nodes) };
}
async function handleGetForward(ref, resId) {
	const nodes = await ref.bridge.fetchForwardNodes(resId);
	const results = [];
	for (const node of nodes) results.push({
		type: "node",
		data: {
			user_id: node.userUin,
			nickname: node.nickname,
			uin: String(node.userUin),
			name: node.nickname,
			content: await elementsToOneBotSegments(node.elements, false, node.userUin)
		}
	});
	return results;
}
async function parseForwardNodes(ref, messages) {
	if (!Array.isArray(messages)) throw new Error("forward messages must be an array");
	const nodes = [];
	for (const item of messages) {
		const segment = asJsonObject(item);
		if (!segment) continue;
		let nodeData = null;
		if (String(segment.type ?? "") === "node") nodeData = asJsonObject(segment.data);
		else if (segment.content !== void 0 || segment.message !== void 0) nodeData = segment;
		if (!nodeData) continue;
		const messageId = toPositiveInt(nodeData.id ?? nodeData.message_id);
		if (messageId > 0) {
			const event = ref.messageStore.findEvent(messageId);
			if (!event) throw new Error(`forward node message_id not found: ${messageId}`);
			const eventSender = asJsonObject(event.sender) ?? {};
			const nickname = String(eventSender.card ?? eventSender.nickname ?? nodeData.nickname ?? nodeData.name ?? "");
			const userUin = toPositiveInt(event.user_id);
			const elements = await parseMessage(event.message ?? event.raw_message ?? "", false);
			if (userUin > 0 && elements.length > 0) nodes.push({
				userUin,
				nickname: nickname || String(userUin),
				elements
			});
			continue;
		}
		const userUin = toPositiveInt(nodeData.user_id ?? nodeData.uin);
		if (userUin <= 0) throw new Error("forward node user_id/uin is required");
		const nickname = String(nodeData.nickname ?? nodeData.name ?? userUin);
		const elements = await parseMessage(nodeData.content ?? nodeData.message ?? "", false);
		if (elements.length === 0) throw new Error(`forward node content is empty: ${userUin}`);
		nodes.push({
			userUin,
			nickname,
			elements
		});
	}
	if (nodes.length === 0) throw new Error("forward node list is empty");
	return nodes;
}
function asJsonObject(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return null;
	return value;
}
function toPositiveInt(value) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.max(0, Math.trunc(value));
	if (typeof value === "string" && value.trim()) {
		const parsed = Number(value);
		if (Number.isFinite(parsed)) return Math.max(0, Math.trunc(parsed));
	}
	return 0;
}
//#endregion
//#region src/onebot/http-transport.ts
var log$5 = createLogger("OneBot.HTTP");
var HttpTransport = class {
	context;
	servers = /* @__PURE__ */ new Map();
	networks = [];
	constructor(config, context) {
		this.networks = activeNetworks(config);
		this.context = context;
	}
	start() {
		for (const network of this.networks) this.startEndpoint(network);
	}
	reloadConfig(config) {
		const nextNetworks = activeNetworks(config);
		const nextByName = new Map(nextNetworks.map((n) => [n.name, n]));
		for (const [name, running] of [...this.servers]) {
			const next = nextByName.get(name);
			if (!next || httpServerSignature(next) !== running.signature) {
				running.server.close();
				this.servers.delete(name);
				log$5.info("stopped [%s]", name);
			}
		}
		for (const network of nextNetworks) if (!this.servers.has(network.name)) this.startEndpoint(network);
		this.networks = nextNetworks;
	}
	stop() {
		for (const { server } of this.servers.values()) server.close();
		this.servers.clear();
	}
	startEndpoint(network) {
		const expectedPath = normalizePath(network.path ?? "/");
		const endpointToken = network.accessToken ?? "";
		const server = createServer((req, res) => {
			this.handleRequest(expectedPath, endpointToken, req, res);
		});
		server.on("listening", () => {
			log$5.success("[%s] listening %s:%d%s", network.name, network.host ?? "0.0.0.0", network.port, expectedPath);
		});
		server.on("error", (error) => {
			log$5.warn("[%s] server error: %s", network.name, error instanceof Error ? error.message : String(error));
		});
		server.listen(network.port, network.host ?? "0.0.0.0");
		this.servers.set(network.name, {
			server,
			signature: httpServerSignature(network),
			network
		});
	}
	async handleRequest(expectedPath, accessToken, req, res) {
		const parsedUrl = new URL(req.url ?? "/", "http://127.0.0.1");
		const incomingPath = parsedUrl.pathname;
		const ep = expectedPath.endsWith("/") ? expectedPath : expectedPath + "/";
		let action = "";
		if (incomingPath === expectedPath || incomingPath === expectedPath + "/") action = "";
		else if (incomingPath.startsWith(ep)) action = incomingPath.substring(ep.length);
		else {
			writeJson(res, 404, {
				status: "failed",
				retcode: 1404,
				data: null,
				wording: "not found"
			});
			return;
		}
		if (!isAuthorized$1(req, accessToken)) {
			writeJson(res, 401, {
				status: "failed",
				retcode: 1401,
				data: null,
				wording: "unauthorized"
			});
			return;
		}
		if (req.method === "GET" && !action) {
			writeJson(res, 200, {
				status: "ok",
				retcode: 0,
				data: { online: true }
			});
			return;
		}
		try {
			let params = {};
			let echo;
			if (req.method === "GET") parsedUrl.searchParams.forEach((value, key) => {
				try {
					params[key] = JSON.parse(value);
				} catch {
					params[key] = value;
				}
			});
			else if (req.method === "POST") {
				const bodyContent = await readRequestBody(req);
				if (bodyContent.trim()) try {
					const parsedBody = JSON.parse(bodyContent);
					if (typeof parsedBody === "object" && parsedBody !== null && !Array.isArray(parsedBody)) {
						if (parsedBody.action && !action) action = String(parsedBody.action);
						if (parsedBody.params && typeof parsedBody.params === "object" && !Array.isArray(parsedBody.params)) params = parsedBody.params;
						else params = parsedBody;
						echo = parsedBody.echo;
					}
				} catch {
					writeJson(res, 400, {
						status: "failed",
						retcode: 1400,
						data: null,
						wording: "bad request: invalid json"
					});
					return;
				}
			} else {
				writeJson(res, 405, {
					status: "failed",
					retcode: 1400,
					data: null,
					wording: "method not allowed"
				});
				return;
			}
			if (!action) {
				writeJson(res, 400, {
					status: "failed",
					retcode: 1400,
					data: null,
					wording: "bad request: missing action"
				});
				return;
			}
			const response = await this.context.api.handle(action, params);
			if (echo !== void 0) response.echo = echo;
			writeJson(res, 200, response);
		} catch (error) {
			writeJson(res, 500, {
				status: "failed",
				retcode: 1200,
				data: null,
				wording: error instanceof Error ? error.message : "internal error"
			});
		}
	}
};
function normalizePath(pathValue) {
	const path = pathValue.trim() || "/";
	if (path === "/") return "/";
	return path.endsWith("/") ? path.slice(0, -1) : path;
}
function httpServerSignature(network) {
	return `${network.host ?? "0.0.0.0"}:${network.port}${normalizePath(network.path ?? "/")}#${network.accessToken ?? ""}`;
}
function activeNetworks(config) {
	return config.networks.httpServers.filter((n) => n.enabled !== false);
}
function isAuthorized$1(request, token) {
	if (!token) return true;
	const rawAuth = request.headers.authorization;
	if ((Array.isArray(rawAuth) ? rawAuth[0] : rawAuth ?? "") === `Bearer ${token}`) return true;
	try {
		if (new URL(request.url ?? "/", "http://127.0.0.1").searchParams.get("access_token") === token) return true;
	} catch {}
	return false;
}
function readRequestBody(req, maxBytes = 2 * 1024 * 1024) {
	return new Promise((resolve, reject) => {
		const chunks = [];
		let total = 0;
		req.on("data", (chunk) => {
			total += chunk.length;
			if (total > maxBytes) {
				reject(/* @__PURE__ */ new Error("request body too large"));
				req.destroy();
				return;
			}
			chunks.push(chunk);
		});
		req.on("end", () => {
			resolve(Buffer.concat(chunks).toString("utf8"));
		});
		req.on("error", reject);
	});
}
function writeJson(res, statusCode, data) {
	res.statusCode = statusCode;
	res.setHeader("Content-Type", "application/json; charset=utf-8");
	res.end(JSON.stringify(data));
}
//#endregion
//#region ../websocket/src/native.ts
var __dirname$1 = path$1.dirname(fileURLToPath(import.meta.url));
function platformBinaryName$1() {
	return `websocket-${process.platform}-${process.arch}.node`;
}
function searchDirs() {
	return [
		path$1.resolve(__dirname$1, "native"),
		path$1.resolve(__dirname$1, "..", "native"),
		path$1.resolve(__dirname$1, "..", "..", "runtime", "native"),
		path$1.resolve(process.cwd(), "native"),
		path$1.resolve(process.cwd(), "dist", "native"),
		path$1.resolve(process.cwd(), "packages", "runtime", "native")
	];
}
function resolveAddonPath() {
	const fileName = platformBinaryName$1();
	for (const dir of searchDirs()) {
		const full = path$1.join(dir, fileName);
		if (existsSync$1(full)) return full;
	}
	throw new Error(`[snowluma/websocket] native addon not found: ${fileName}. Searched: ${searchDirs().join(", ")}`);
}
function loadAddon() {
	const addonPath = resolveAddonPath();
	const mod = { exports: {} };
	process.dlopen(mod, addonPath);
	return mod.exports;
}
function createStubAddon(reason) {
	const fail = () => {
		throw new Error(`[snowluma/websocket] native addon is stubbed (${reason}). Set SNOWLUMA_DEV_NO_NATIVE=0 (or unset) and provide the prebuilt binary to enable WebSocket I/O.`);
	};
	class StubParser {
		constructor(_options) {}
		push(_chunk) {
			return fail();
		}
	}
	console.warn(`[snowluma/websocket] WARNING: using stub addon (${reason}). WebSocket features are disabled.`);
	return {
		Parser: StubParser,
		buildFrame: fail,
		computeAcceptKey: fail
	};
}
function tryLoad() {
	const devSkip = process.env.SNOWLUMA_DEV_NO_NATIVE === "1";
	try {
		return loadAddon();
	} catch (err) {
		if (devSkip) return createStubAddon(err.message);
		throw err;
	}
}
var addon = tryLoad();
//#endregion
//#region ../websocket/src/extensions.ts
var TRAILER = Buffer.from([
	0,
	0,
	255,
	255
]);
function parseHeader(header) {
	const offers = [];
	if (!header) return offers;
	for (const rawOffer of String(header).split(",")) {
		const parts = rawOffer.split(";").map((p) => p.trim()).filter(Boolean);
		if (parts.length === 0) continue;
		const name = parts.shift().toLowerCase();
		const params = Object.create(null);
		for (const part of parts) {
			const eq = part.indexOf("=");
			if (eq === -1) params[part.toLowerCase()] = true;
			else {
				const key = part.slice(0, eq).trim().toLowerCase();
				let value = part.slice(eq + 1).trim();
				if (value.startsWith("\"") && value.endsWith("\"") || value.startsWith("'") && value.endsWith("'")) value = value.slice(1, -1);
				params[key] = value;
			}
		}
		offers.push({
			name,
			params
		});
	}
	return offers;
}
function normalizePerMessageDeflateOptions(value) {
	if (value === void 0 || value === false || value === null) return null;
	if (value === true) return {
		clientNoContextTakeover: true,
		serverNoContextTakeover: true
	};
	if (typeof value === "object") return {
		clientNoContextTakeover: true,
		serverNoContextTakeover: true,
		...value
	};
	return {
		clientNoContextTakeover: true,
		serverNoContextTakeover: true
	};
}
function acceptPerMessageDeflate(requestHeader, options) {
	const config = normalizePerMessageDeflateOptions(options);
	if (!config) return null;
	const offer = parseHeader(requestHeader).find((item) => item.name === "permessage-deflate");
	if (!offer) return null;
	const responseParams = [];
	if (config.serverNoContextTakeover !== false || offer.params.server_no_context_takeover) responseParams.push("server_no_context_takeover");
	if (config.clientNoContextTakeover !== false || offer.params.client_no_context_takeover) responseParams.push("client_no_context_takeover");
	const accepted = {
		enabled: true,
		requestNoContextTakeover: responseParams.includes("client_no_context_takeover"),
		responseNoContextTakeover: responseParams.includes("server_no_context_takeover"),
		threshold: config.threshold ?? 1024
	};
	return {
		header: ["permessage-deflate", ...responseParams].join("; "),
		options: accepted
	};
}
function offerPerMessageDeflate(options) {
	const config = normalizePerMessageDeflateOptions(options);
	if (!config) return null;
	const params = ["permessage-deflate"];
	if (config.clientNoContextTakeover !== false) params.push("client_no_context_takeover");
	if (config.serverNoContextTakeover !== false) params.push("server_no_context_takeover");
	return params.join("; ");
}
function parseAcceptedPerMessageDeflate(responseHeader, requestedOptions) {
	const config = normalizePerMessageDeflateOptions(requestedOptions);
	if (!config) return null;
	const accepted = parseHeader(responseHeader).find((item) => item.name === "permessage-deflate");
	if (!accepted) return null;
	for (const key of Object.keys(accepted.params)) if (key !== "client_no_context_takeover" && key !== "server_no_context_takeover") throw new Error(`Unsupported permessage-deflate parameter: ${key}`);
	return {
		enabled: true,
		requestNoContextTakeover: !!accepted.params.server_no_context_takeover,
		responseNoContextTakeover: !!accepted.params.client_no_context_takeover,
		threshold: config.threshold ?? 1024
	};
}
function compressRaw(data) {
	const compressed = zlib.deflateRawSync(data, { flush: zlib.constants.Z_SYNC_FLUSH });
	if (compressed.length >= 4 && compressed.subarray(compressed.length - 4).equals(TRAILER)) return compressed.subarray(0, compressed.length - 4);
	return compressed;
}
function decompressRaw(data, maxPayload) {
	const inflated = zlib.inflateRawSync(Buffer.concat([data, TRAILER]), { finishFlush: zlib.constants.Z_SYNC_FLUSH });
	if (maxPayload !== void 0 && inflated.length > maxPayload) {
		const err = /* @__PURE__ */ new Error("Message too large after inflate");
		err.code = 1009;
		throw err;
	}
	return inflated;
}
function normalizeProtocolList(protocols) {
	if (!protocols) return [];
	if (typeof protocols === "string") return protocols.split(",").map((p) => p.trim()).filter(Boolean);
	if (Array.isArray(protocols)) return protocols.map(String).map((p) => p.trim()).filter(Boolean);
	if (protocols instanceof Set) return Array.from(protocols).map(String).map((p) => p.trim()).filter(Boolean);
	return [];
}
function chooseSubprotocol(requestHeader, protocols) {
	const requested = normalizeProtocolList(requestHeader);
	if (typeof protocols === "function") {
		const selected = protocols(requested);
		return selected && requested.includes(String(selected)) ? String(selected) : null;
	}
	const supported = normalizeProtocolList(protocols);
	if (requested.length === 0 || supported.length === 0) return null;
	for (const protocol of supported) if (requested.includes(protocol)) return protocol;
	return null;
}
var DEFAULT_MAX_PAYLOAD = 100 * 1024 * 1024;
function isValidCloseCode(code) {
	if (code === 1e3 || code === 1001 || code === 1002 || code === 1003 || code === 1007 || code === 1008 || code === 1009 || code === 1010 || code === 1011) return true;
	if (code >= 3e3 && code <= 4999) return true;
	return false;
}
function encodeClosePayload(code, reason) {
	const reasonBuf = reason ? Buffer.from(String(reason), "utf8") : Buffer.alloc(0);
	if (code === void 0 || code === null) {
		if (reasonBuf.length > 0) throw new Error("Cannot send close reason without a code");
		return Buffer.alloc(0);
	}
	const buf = Buffer.allocUnsafe(2 + reasonBuf.length);
	buf.writeUInt16BE(code & 65535, 0);
	reasonBuf.copy(buf, 2);
	return buf;
}
var Utf8Validator = class {
	state = 0;
	codepoint = 0;
	minNext = 0;
	push(buf) {
		for (let i = 0; i < buf.length; i++) {
			const b = buf[i];
			if (this.state === 0) {
				if ((b & 128) === 0) continue;
				if ((b & 224) === 192) {
					if (b < 194) return false;
					this.codepoint = b & 31;
					this.state = 1;
					this.minNext = 128;
				} else if ((b & 240) === 224) {
					this.codepoint = b & 15;
					this.state = 2;
					this.minNext = b === 224 ? 160 : 128;
				} else if ((b & 248) === 240) {
					if (b > 244) return false;
					this.codepoint = b & 7;
					this.state = 3;
					this.minNext = b === 240 ? 144 : 128;
				} else return false;
			} else {
				if (b < this.minNext || b > 191) return false;
				if (this.state === 2 && this.codepoint === 13 && b & 32) return false;
				if (this.codepoint === 13 && this.state === 2 && b >= 160) return false;
				this.codepoint = this.codepoint << 6 | b & 63;
				this.state--;
				this.minNext = 128;
			}
		}
		return true;
	}
	done() {
		return this.state === 0;
	}
};
function randomMaskKey() {
	const b = Buffer.allocUnsafe(4);
	crypto$1.randomFillSync(b);
	return b;
}
var WebSocket$1 = class extends EventEmitter {
	_socket;
	_isServer;
	_maxPayload;
	_readyState;
	_perMessageDeflate;
	protocol;
	extensions;
	_parser;
	_msgOpcode = 0;
	_msgChunks = [];
	_msgSize = 0;
	_msgValidator = null;
	_msgCompressed = false;
	_closeCodeSent = null;
	_closeCodeReceived = null;
	_closeReasonReceived = "";
	_closeFrameSent = false;
	_closeTimer = null;
	static CONNECTING = 0;
	static OPEN = 1;
	static CLOSING = 2;
	static CLOSED = 3;
	constructor(socket, options) {
		super();
		options = options || {};
		this._socket = socket;
		this._isServer = !!options.isServer;
		this._maxPayload = options.maxPayload ?? DEFAULT_MAX_PAYLOAD;
		this._readyState = options.readyState ?? 1;
		this._perMessageDeflate = options.extensions?.perMessageDeflate;
		this.protocol = options.protocol || "";
		this.extensions = this._perMessageDeflate ? "permessage-deflate" : "";
		this._parser = new addon.Parser({
			isServer: this._isServer,
			maxPayload: this._maxPayload,
			allowedRsv: this._perMessageDeflate ? 64 : 0
		});
		this._bindSocket();
	}
	get readyState() {
		return this._readyState;
	}
	get isServer() {
		return this._isServer;
	}
	_bindSocket() {
		const sock = this._socket;
		sock.on("data", (chunk) => this._onData(chunk));
		sock.on("end", () => this._onEnd());
		sock.on("close", () => this._onSocketClose());
		sock.on("error", (err) => this._onError(err));
	}
	/** @internal */
	_onData(chunk) {
		if (this._readyState === 3) return;
		const res = this._parser.push(chunk);
		if (res.error) {
			this._failConnection(res.code || 1002, res.message || "Protocol error");
			return;
		}
		for (const f of res.frames) {
			this._handleFrame(f);
			if (this._readyState === 3) return;
		}
	}
	_onEnd() {
		if (this._readyState !== 3) {
			if (this._closeCodeReceived === null) {
				this._closeCodeReceived = 1006;
				this._closeReasonReceived = "";
			}
			this._destroySocket();
		}
	}
	_onSocketClose() {
		if (this._readyState === 3) return;
		if (this._closeCodeReceived === null) this._closeCodeReceived = 1006;
		this._readyState = 3;
		if (this._closeTimer) {
			clearTimeout(this._closeTimer);
			this._closeTimer = null;
		}
		this.emit("close", this._closeCodeReceived, this._closeReasonReceived);
	}
	_onError(err) {
		this.emit("error", err);
	}
	_handleFrame(f) {
		const { fin, opcode, payload } = f;
		const rsv = f.rsv ?? 0;
		if (opcode === 9) {
			this.emit("ping", payload);
			if (this._readyState === 1) this._sendControl(10, payload);
			return;
		}
		if (opcode === 10) {
			this.emit("pong", payload);
			return;
		}
		if (opcode === 8) {
			this._handleCloseFrame(payload);
			return;
		}
		if (opcode === 1 || opcode === 2) {
			if (this._msgOpcode !== 0) {
				this._failConnection(1002, "New data frame started before previous fragmented message finished");
				return;
			}
			if (rsv & 64 && !this._perMessageDeflate) {
				this._failConnection(1002, "Compressed frame without negotiated permessage-deflate");
				return;
			}
			this._msgOpcode = opcode;
			this._msgChunks = [];
			this._msgSize = 0;
			this._msgCompressed = (rsv & 64) !== 0;
			this._msgValidator = opcode === 1 ? new Utf8Validator() : null;
		} else if (opcode === 0) {
			if (this._msgOpcode === 0) {
				this._failConnection(1002, "Continuation frame without active message");
				return;
			}
			if (rsv !== 0) {
				this._failConnection(1002, "RSV bits set on continuation frame");
				return;
			}
		}
		this._msgSize += payload.length;
		if (this._msgSize > this._maxPayload) {
			this._failConnection(1009, "Message too large");
			return;
		}
		if (payload.length > 0) this._msgChunks.push(payload);
		if (fin) {
			let data = this._msgChunks.length === 1 ? this._msgChunks[0] : Buffer.concat(this._msgChunks, this._msgSize);
			if (this._msgCompressed) try {
				data = decompressRaw(data, this._maxPayload);
			} catch (err) {
				const e = err;
				this._failConnection(e.code || 1007, e.message || "Invalid compressed payload");
				return;
			}
			if (this._msgValidator) {
				if (!this._msgValidator.push(data) || !this._msgValidator.done()) {
					this._failConnection(1007, "Invalid UTF-8");
					return;
				}
			}
			const isBinary = this._msgOpcode === 2;
			this._msgOpcode = 0;
			this._msgChunks = [];
			this._msgSize = 0;
			this._msgValidator = null;
			this._msgCompressed = false;
			this.emit("message", data, isBinary);
		}
	}
	_handleCloseFrame(payload) {
		let code = 1005;
		let reason = "";
		if (payload.length === 1) {
			this._failConnection(1002, "Close payload length 1");
			return;
		}
		if (payload.length >= 2) {
			code = payload.readUInt16BE(0);
			if (!isValidCloseCode(code)) {
				this._failConnection(1002, "Invalid close code");
				return;
			}
			if (payload.length > 2) try {
				reason = new TextDecoder("utf-8", { fatal: true }).decode(payload.subarray(2));
			} catch {
				this._failConnection(1007, "Invalid UTF-8 in close reason");
				return;
			}
		}
		this._closeCodeReceived = code;
		this._closeReasonReceived = reason;
		if (this._readyState === 1) {
			this._readyState = 2;
			const echo = encodeClosePayload(code === 1005 ? void 0 : code, "");
			this._sendControl(8, echo);
			this._closeFrameSent = true;
			this._endSocketSoon();
		} else if (this._readyState === 2) this._endSocketSoon();
	}
	_endSocketSoon() {
		try {
			this._socket.end();
		} catch {}
		if (this._closeTimer) clearTimeout(this._closeTimer);
		this._closeTimer = setTimeout(() => this._destroySocket(), 3e4);
		this._closeTimer.unref?.();
	}
	_destroySocket() {
		try {
			this._socket.destroy();
		} catch {}
	}
	_failConnection(code, reason) {
		if (this._readyState === 3) return;
		const payload = encodeClosePayload(code, reason);
		let frame = null;
		try {
			frame = addon.buildFrame(8, true, payload, this._isServer ? null : randomMaskKey(), 0);
		} catch {}
		this._closeCodeSent = code;
		this._readyState = 2;
		const err = /* @__PURE__ */ new Error(`WebSocket protocol error: ${reason}`);
		err.code = code;
		this.emit("error", err);
		try {
			if (frame) this._socket.end(frame);
			else this._socket.end();
		} catch {}
		if (this._closeTimer) clearTimeout(this._closeTimer);
		this._closeTimer = setTimeout(() => this._destroySocket(), 2e3);
		this._closeTimer.unref?.();
	}
	_sendControl(opcode, payload) {
		const data = payload ?? Buffer.alloc(0);
		const frame = addon.buildFrame(opcode, true, data, this._isServer ? null : randomMaskKey(), 0);
		this._socket.write(frame);
	}
	send(data, options, cb) {
		if (typeof options === "function") {
			cb = options;
			options = void 0;
		}
		const opts = options || {};
		if (this._readyState !== 1) {
			const err = /* @__PURE__ */ new Error("WebSocket is not open");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		let payload;
		let opcode;
		if (typeof data === "string") {
			payload = Buffer.from(data, "utf8");
			opcode = opts.binary ? 2 : 1;
		} else if (Buffer.isBuffer(data)) {
			payload = data;
			opcode = opts.binary === false ? 1 : 2;
		} else if (data instanceof Uint8Array) {
			payload = Buffer.from(data.buffer, data.byteOffset, data.byteLength);
			opcode = opts.binary === false ? 1 : 2;
		} else if (data instanceof ArrayBuffer) {
			payload = Buffer.from(data);
			opcode = opts.binary === false ? 1 : 2;
		} else {
			const err = /* @__PURE__ */ new TypeError("Unsupported data type for send()");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		let rsv = 0;
		if (this._perMessageDeflate && opts.compress !== false && payload.length >= (this._perMessageDeflate.threshold ?? 1024)) {
			payload = compressRaw(payload);
			rsv = 64;
		}
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(opcode, true, payload, maskKey, rsv);
		this._socket.write(frame, cb);
	}
	ping(data, _mask, cb) {
		if (typeof data === "function") {
			cb = data;
			data = void 0;
		}
		const payload = data ? Buffer.isBuffer(data) ? data : Buffer.from(String(data), "utf8") : Buffer.alloc(0);
		if (payload.length > 125) throw new Error("Ping payload must be <=125 bytes");
		if (this._readyState !== 1) {
			const err = /* @__PURE__ */ new Error("WebSocket is not open");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(9, true, payload, maskKey, 0);
		this._socket.write(frame, cb);
	}
	pong(data, _mask, cb) {
		if (typeof data === "function") {
			cb = data;
			data = void 0;
		}
		const payload = data ? Buffer.isBuffer(data) ? data : Buffer.from(String(data), "utf8") : Buffer.alloc(0);
		if (payload.length > 125) throw new Error("Pong payload must be <=125 bytes");
		if (this._readyState !== 1) {
			const err = /* @__PURE__ */ new Error("WebSocket is not open");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(10, true, payload, maskKey, 0);
		this._socket.write(frame, cb);
	}
	close(code, reason) {
		if (this._readyState === 3 || this._readyState === 2) return;
		if (code !== void 0 && !isValidCloseCode(code)) throw new RangeError(`Invalid close code: ${code}`);
		if ((reason ? Buffer.from(String(reason), "utf8") : Buffer.alloc(0)).length > 123) throw new RangeError("Close reason must be <=123 bytes");
		const payload = encodeClosePayload(code, reason);
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(8, true, payload, maskKey, 0);
		this._readyState = 2;
		this._closeCodeSent = code ?? null;
		this._socket.write(frame);
		this._closeFrameSent = true;
		this._endSocketSoon();
	}
	terminate() {
		this._readyState = 2;
		this._destroySocket();
	}
};
//#endregion
//#region ../websocket/src/server.ts
function computeAccept(key) {
	return addon.computeAcceptKey(key);
}
function abortUpgrade(socket, status, message) {
	try {
		const body = message ? message : http.STATUS_CODES[status] || "";
		const head = `HTTP/1.1 ${status} ${http.STATUS_CODES[status] || "Error"}\r\nConnection: close\r
Content-Length: ${Buffer.byteLength(body)}\r\nContent-Type: text/plain\r
\r
`;
		socket.write(head + body);
	} catch {}
	try {
		socket.destroy();
	} catch {}
}
var TLS_OPTION_KEYS = [
	"ALPNProtocols",
	"SNICallback",
	"ca",
	"cert",
	"ciphers",
	"clientCertEngine",
	"crl",
	"dhparam",
	"ecdhCurve",
	"honorCipherOrder",
	"key",
	"maxVersion",
	"minVersion",
	"passphrase",
	"pfx",
	"privateKeyEngine",
	"privateKeyIdentifier",
	"requestCert",
	"rejectUnauthorized",
	"secureOptions",
	"secureProtocol",
	"sessionIdContext",
	"sigalgs",
	"ticketKeys"
];
function getTlsOptions(options) {
	const tlsOptions = {};
	for (const key of TLS_OPTION_KEYS) if (options[key] !== void 0) tlsOptions[key] = options[key];
	if (options.tls && typeof options.tls === "object") Object.assign(tlsOptions, options.tls);
	return tlsOptions;
}
var WebSocketServer = class extends EventEmitter {
	options;
	clients = /* @__PURE__ */ new Set();
	_server = null;
	_externalServer = null;
	_upgradeHandler = null;
	constructor(options) {
		super();
		options = options || {};
		this.options = {
			port: options.port,
			host: options.host,
			server: options.server,
			noServer: !!options.noServer,
			path: options.path,
			maxPayload: options.maxPayload,
			verifyClient: options.verifyClient,
			protocols: options.protocols,
			perMessageDeflate: options.perMessageDeflate,
			backlog: options.backlog,
			tls: options.tls
		};
		const tlsOptions = getTlsOptions(options);
		this.options.tls = Object.keys(tlsOptions).length > 0 ? tlsOptions : void 0;
		if (this.options.noServer) return;
		if (this.options.server) {
			this._externalServer = this.options.server;
			this._attachToServer(this._externalServer);
		} else if (this.options.port !== void 0) {
			const requestHandler = (_req, res) => {
				const body = http.STATUS_CODES[426] ?? "";
				res.writeHead(426, {
					"Content-Length": Buffer.byteLength(body),
					"Content-Type": "text/plain"
				});
				res.end(body);
			};
			this._server = this.options.tls ? https.createServer(this.options.tls, requestHandler) : http.createServer(requestHandler);
			this._attachToServer(this._server);
			this._server.listen(this.options.port, this.options.host, this.options.backlog, () => this.emit("listening"));
			this._server.on("error", (err) => this.emit("error", err));
		} else throw new Error("WebSocketServer requires { port } or { server } or { noServer: true }");
	}
	address() {
		if (this._server) return this._server.address();
		if (this._externalServer && this._externalServer.address) return this._externalServer.address();
		return null;
	}
	_attachToServer(server) {
		const handler = (req, socket, head) => {
			if (this.options.path) {
				if ((req.url ?? "/").split("?")[0] !== this.options.path) {
					if (server.listenerCount("upgrade") === 1) abortUpgrade(socket, 400, "Bad path for WebSocket");
					return;
				}
			}
			this.handleUpgrade(req, socket, head, (ws) => {
				this.emit("connection", ws, req);
			});
		};
		this._upgradeHandler = handler;
		server.on("upgrade", handler);
	}
	handleUpgrade(request, socket, head, cb) {
		const upgrade = (request.headers["upgrade"] ?? "").toLowerCase();
		const connection = (Array.isArray(request.headers["connection"]) ? request.headers["connection"].join(",") : request.headers["connection"] ?? "").toLowerCase();
		const version = request.headers["sec-websocket-version"];
		const key = request.headers["sec-websocket-key"];
		if (request.method !== "GET") return abortUpgrade(socket, 405, "Method not allowed");
		if (upgrade !== "websocket") return abortUpgrade(socket, 400, "Upgrade header must be websocket");
		if (!/\bupgrade\b/i.test(connection)) return abortUpgrade(socket, 400, "Connection header must contain \"upgrade\"");
		if (version !== "13") {
			try {
				socket.write("HTTP/1.1 426 Upgrade Required\r\nSec-WebSocket-Version: 13\r\nConnection: close\r\n\r\n");
			} catch {}
			try {
				socket.destroy();
			} catch {}
			return;
		}
		if (typeof key !== "string" || !/^[+/0-9A-Za-z]{22}==$/.test(key)) return abortUpgrade(socket, 400, "Invalid Sec-WebSocket-Key");
		const doAccept = () => {
			const accept = computeAccept(key);
			const extension = acceptPerMessageDeflate(request.headers["sec-websocket-extensions"], this.options.perMessageDeflate);
			const protocol = chooseSubprotocol(request.headers["sec-websocket-protocol"], this.options.protocols);
			const responseHeaders = [
				"HTTP/1.1 101 Switching Protocols",
				"Upgrade: websocket",
				"Connection: Upgrade",
				`Sec-WebSocket-Accept: ${accept}`
			];
			if (extension) responseHeaders.push(`Sec-WebSocket-Extensions: ${extension.header}`);
			if (protocol) responseHeaders.push(`Sec-WebSocket-Protocol: ${protocol}`);
			try {
				socket.write(responseHeaders.join("\r\n") + "\r\n\r\n");
			} catch {
				try {
					socket.destroy();
				} catch {}
				return;
			}
			const ns = socket;
			ns.setTimeout?.(0);
			ns.setNoDelay?.(true);
			const ws = new WebSocket$1(socket, {
				isServer: true,
				maxPayload: this.options.maxPayload,
				extensions: extension ? { perMessageDeflate: extension.options } : void 0,
				protocol: protocol ?? "",
				readyState: 1
			});
			this.clients.add(ws);
			ws.on("close", () => this.clients.delete(ws));
			if (head && head.length > 0) ws._onData(head);
			cb(ws, request);
		};
		const verify = this.options.verifyClient;
		if (typeof verify === "function") {
			const info = {
				origin: request.headers["origin"],
				secure: !!socket.encrypted,
				req: request
			};
			if (verify.length >= 2) verify(info, (allow, code, message) => {
				if (!allow) return abortUpgrade(socket, code || 401, message);
				doAccept();
			});
			else {
				if (!verify(info)) return abortUpgrade(socket, 401, "Unauthorized");
				doAccept();
			}
		} else doAccept();
	}
	close(cb) {
		if (this._externalServer && this._upgradeHandler) {
			this._externalServer.removeListener("upgrade", this._upgradeHandler);
			this._upgradeHandler = null;
		}
		for (const ws of this.clients) try {
			ws.close(1001, "Server shutting down");
		} catch {}
		if (this._server) this._server.close((err) => cb && cb(err));
		else if (cb) setImmediate(cb);
	}
};
//#endregion
//#region ../websocket/src/client.ts
function parseHeaders(headerBlock) {
	const lines = headerBlock.split("\r\n");
	const status = lines.shift();
	const m = /^HTTP\/1\.1\s+(\d+)\s*(.*)$/.exec(status);
	if (!m) throw new Error("Bad HTTP status line: " + status);
	const headers = Object.create(null);
	for (const line of lines) {
		if (!line) continue;
		const idx = line.indexOf(":");
		if (idx < 0) continue;
		const k = line.slice(0, idx).trim().toLowerCase();
		headers[k] = line.slice(idx + 1).trim();
	}
	return {
		statusCode: Number(m[1]),
		statusMessage: m[2] ?? "",
		headers
	};
}
var WebSocketClient = class extends EventEmitter {
	static CONNECTING = 0;
	static OPEN = 1;
	static CLOSING = 2;
	static CLOSED = 3;
	static Server;
	_url;
	_secure;
	_readyState;
	_maxPayload;
	_ws = null;
	_pendingQueue = [];
	_perMessageDeflate;
	_protocols;
	protocol = "";
	extensions = "";
	_socket;
	_handshakeBuf = Buffer.alloc(0);
	_wsKey;
	_expectedAccept;
	constructor(address, protocols, options) {
		super();
		if (typeof protocols === "object" && !Array.isArray(protocols) && protocols !== null) {
			options = protocols;
			protocols = void 0;
		}
		options = options || {};
		this._url = new URL$1(address);
		if (this._url.protocol !== "ws:" && this._url.protocol !== "wss:") throw new Error("Only ws: and wss: URLs are supported");
		this._secure = this._url.protocol === "wss:";
		this._readyState = 0;
		this._maxPayload = options.maxPayload;
		this._perMessageDeflate = options.perMessageDeflate;
		this._protocols = Array.isArray(protocols) ? protocols.map(String) : typeof protocols === "string" ? [protocols] : void 0;
		const host = this._url.hostname;
		const port = this._url.port ? Number(this._url.port) : this._secure ? 443 : 80;
		this._wsKey = crypto$1.randomBytes(16).toString("base64");
		this._expectedAccept = addon.computeAcceptKey(this._wsKey);
		const connectOpts = {
			host,
			port,
			...options.socketOptions || {}
		};
		const onConnect = () => {
			const pathAndQuery = (this._url.pathname || "/") + (this._url.search || "");
			const hostHeader = this._url.port && Number(this._url.port) !== (this._secure ? 443 : 80) ? `${host}:${this._url.port}` : host;
			const reqLines = [
				`GET ${pathAndQuery} HTTP/1.1`,
				`Host: ${hostHeader}`,
				"Upgrade: websocket",
				"Connection: Upgrade",
				`Sec-WebSocket-Key: ${this._wsKey}`,
				"Sec-WebSocket-Version: 13"
			];
			if (this._protocols && this._protocols.length > 0) reqLines.push(`Sec-WebSocket-Protocol: ${this._protocols.join(", ")}`);
			const extensionOffer = offerPerMessageDeflate(this._perMessageDeflate);
			if (extensionOffer) reqLines.push(`Sec-WebSocket-Extensions: ${extensionOffer}`);
			if (options.headers) for (const [k, v] of Object.entries(options.headers)) reqLines.push(`${k}: ${v}`);
			reqLines.push("", "");
			this._socket.write(reqLines.join("\r\n"));
		};
		if (this._secure && connectOpts.servername === void 0 && net$1.isIP(host) === 0) connectOpts.servername = host;
		this._socket = this._secure ? tls.connect(connectOpts, onConnect) : net$1.connect(connectOpts, onConnect);
		this._socket.setNoDelay?.(true);
		this._socket.on("data", (chunk) => this._onHandshakeData(chunk));
		this._socket.on("error", (err) => this._onEarlyError(err));
		this._socket.on("close", () => this._onEarlyClose());
	}
	get readyState() {
		return this._ws ? this._ws.readyState : this._readyState;
	}
	_onHandshakeData(chunk) {
		this._handshakeBuf = Buffer.concat([this._handshakeBuf, chunk]);
		const idx = this._handshakeBuf.indexOf("\r\n\r\n");
		if (idx < 0) {
			if (this._handshakeBuf.length > 16384) this._abort("Handshake response too large");
			return;
		}
		const headBlock = this._handshakeBuf.slice(0, idx).toString("latin1");
		const rest = this._handshakeBuf.slice(idx + 4);
		let parsed;
		try {
			parsed = parseHeaders(headBlock);
		} catch (e) {
			return this._abort(e.message);
		}
		if (parsed.statusCode !== 101) return this._abort(`Unexpected response status ${parsed.statusCode}`);
		if ((parsed.headers["upgrade"] || "").toLowerCase() !== "websocket") return this._abort("Missing/invalid Upgrade header");
		if (!/\bupgrade\b/i.test(parsed.headers["connection"] || "")) return this._abort("Missing Connection: Upgrade header");
		if (parsed.headers["sec-websocket-accept"] !== this._expectedAccept) return this._abort("Invalid Sec-WebSocket-Accept");
		let acceptedExtensions;
		try {
			acceptedExtensions = parseAcceptedPerMessageDeflate(parsed.headers["sec-websocket-extensions"], this._perMessageDeflate);
		} catch (e) {
			return this._abort(e.message);
		}
		if (parsed.headers["sec-websocket-extensions"] && !acceptedExtensions) return this._abort("Unexpected Sec-WebSocket-Extensions");
		const protocol = parsed.headers["sec-websocket-protocol"] || "";
		if (protocol && (!this._protocols || !this._protocols.includes(protocol))) return this._abort("Unexpected Sec-WebSocket-Protocol");
		this._socket.removeAllListeners("data");
		this._socket.removeAllListeners("error");
		this._socket.removeAllListeners("close");
		this._readyState = 1;
		this._ws = new WebSocket$1(this._socket, {
			isServer: false,
			maxPayload: this._maxPayload,
			extensions: acceptedExtensions ? { perMessageDeflate: acceptedExtensions } : void 0,
			protocol,
			readyState: 1
		});
		this.protocol = protocol;
		this.extensions = acceptedExtensions ? "permessage-deflate" : "";
		this._ws.on("message", (d, isBinary) => this.emit("message", d, isBinary));
		this._ws.on("ping", (d) => this.emit("ping", d));
		this._ws.on("pong", (d) => this.emit("pong", d));
		this._ws.on("close", (c, r) => this.emit("close", c, r));
		this._ws.on("error", (e) => this.emit("error", e));
		this.emit("upgrade", parsed);
		this.emit("open");
		if (rest.length > 0) this._ws._onData(rest);
		for (const entry of this._pendingQueue) this._ws.send(entry.data, entry.options, entry.cb);
		this._pendingQueue = [];
	}
	_onEarlyError(err) {
		this.emit("error", err);
	}
	_onEarlyClose() {
		if (!this._ws) {
			this._readyState = 3;
			this.emit("close", 1006, "");
		}
	}
	_abort(msg) {
		const err = /* @__PURE__ */ new Error("WebSocket handshake failed: " + msg);
		try {
			this._socket.destroy();
		} catch {}
		this.emit("error", err);
		this._readyState = 3;
		this.emit("close", 1006, "");
	}
	send(data, options, cb) {
		if (this._ws) return this._ws.send(data, options, cb);
		if (typeof options === "function") {
			cb = options;
			options = void 0;
		}
		this._pendingQueue.push({
			data,
			options,
			cb
		});
	}
	ping(data, mask, cb) {
		this._ws?.ping(data, mask, cb);
	}
	pong(data, mask, cb) {
		this._ws?.pong(data, mask, cb);
	}
	close(code, reason) {
		if (code !== void 0 && !isValidCloseCode(code)) throw new RangeError(`Invalid close code: ${code}`);
		if (this._ws) return this._ws.close(code, reason);
		try {
			this._socket.destroy();
		} catch {}
	}
	terminate() {
		if (this._ws) return this._ws.terminate();
		try {
			this._socket.destroy();
		} catch {}
	}
};
//#endregion
//#region ../websocket/src/index.ts
WebSocketClient.Server = WebSocketServer;
var WebSocket = WebSocketClient;
//#endregion
//#region src/onebot/ws-transport.ts
var log$4 = createLogger("OneBot.WS");
var WsTransport = class {
	context;
	servers = /* @__PURE__ */ new Map();
	clientStates = /* @__PURE__ */ new Map();
	forwardConnections = /* @__PURE__ */ new Map();
	reverseConnections = /* @__PURE__ */ new Map();
	reconnectTimers = /* @__PURE__ */ new Map();
	serverNetworks = [];
	clientNetworks = [];
	stopped = false;
	constructor(config, context) {
		this.serverNetworks = activeServers(config);
		this.clientNetworks = activeClients(config);
		this.context = context;
		for (const network of this.clientNetworks) this.clientStates.set(network.name, {
			network,
			signature: wsClientSignature(network),
			options: resolveReportOptions(network)
		});
	}
	start() {
		this.stopped = false;
		for (const network of this.serverNetworks) this.startServerEndpoint(network);
		for (const network of this.clientNetworks) this.startClientEndpoint(network.name);
	}
	reloadConfig(config) {
		const nextServers = activeServers(config);
		const nextClients = activeClients(config);
		const nextServerByName = new Map(nextServers.map((n) => [n.name, n]));
		const nextClientByName = new Map(nextClients.map((n) => [n.name, n]));
		for (const [name, running] of [...this.servers]) {
			const next = nextServerByName.get(name);
			if (!next || wsServerSignature(next) !== running.signature) {
				running.wss.close();
				this.servers.delete(name);
				for (const [socket, conn] of [...this.forwardConnections]) if (conn.serverName === name) {
					safeClose(socket);
					this.forwardConnections.delete(socket);
				}
				log$4.info("stopped forward server [%s]", name);
			} else {
				running.network = next;
				running.options = resolveReportOptions(next);
				for (const conn of this.forwardConnections.values()) if (conn.serverName === name) conn.options = running.options;
			}
		}
		for (const network of nextServers) if (!this.servers.has(network.name)) this.startServerEndpoint(network);
		for (const [name, state] of [...this.clientStates]) {
			const next = nextClientByName.get(name);
			const sig = next ? wsClientSignature(next) : null;
			if (!next || sig !== state.signature) {
				const conn = this.reverseConnections.get(name);
				if (conn) {
					safeClose(conn.socket);
					this.reverseConnections.delete(name);
				}
				const timer = this.reconnectTimers.get(name);
				if (timer) {
					clearTimeout(timer);
					this.reconnectTimers.delete(name);
				}
				this.clientStates.delete(name);
				log$4.info("stopped reverse client [%s]", name);
			} else {
				state.network = next;
				state.options = resolveReportOptions(next);
				const conn = this.reverseConnections.get(name);
				if (conn) conn.options = state.options;
			}
		}
		for (const network of nextClients) if (!this.clientStates.has(network.name)) {
			this.clientStates.set(network.name, {
				network,
				signature: wsClientSignature(network),
				options: resolveReportOptions(network)
			});
			if (!this.stopped) this.startClientEndpoint(network.name);
		}
		this.serverNetworks = nextServers;
		this.clientNetworks = nextClients;
	}
	stop() {
		this.publishEvent(this.context.buildLifecycleEvent("disable"));
		this.stopped = true;
		for (const timer of this.reconnectTimers.values()) clearTimeout(timer);
		this.reconnectTimers.clear();
		for (const socket of this.forwardConnections.keys()) safeClose(socket);
		this.forwardConnections.clear();
		for (const conn of this.reverseConnections.values()) safeClose(conn.socket);
		this.reverseConnections.clear();
		for (const { wss } of this.servers.values()) wss.close();
		this.servers.clear();
		this.clientStates.clear();
	}
	/**
	* Fan out one canonical event to every event-receiving WS connection.
	*
	* The instance pre-builds the {@link DispatchPayload} (two JSON variants at
	* most) so each connection is served with a single O(1) pick + send rather
	* than re-shaping or re-serializing the event itself. The raw `event` is
	* accepted so ad-hoc callers (e.g. `stop()`) can dispatch without allocating
	* a payload at the call site.
	*/
	publishEvent(event, payload) {
		const dispatch = payload ?? buildDispatchPayload(event);
		for (const conn of this.forwardConnections.values()) {
			if (conn.role !== "event" && conn.role !== "universal") continue;
			const json = pickDispatchJson(dispatch, conn.options);
			if (json === null) continue;
			safeSend(conn.socket, json);
		}
		for (const conn of this.reverseConnections.values()) {
			if (conn.role !== "event" && conn.role !== "universal") continue;
			const json = pickDispatchJson(dispatch, conn.options);
			if (json === null) continue;
			safeSend(conn.socket, json);
		}
	}
	startServerEndpoint(network) {
		const wss = new WebSocketServer({
			host: network.host ?? "0.0.0.0",
			port: network.port,
			path: network.path ?? "/"
		});
		const running = {
			wss,
			signature: wsServerSignature(network),
			network,
			options: resolveReportOptions(network)
		};
		this.servers.set(network.name, running);
		wss.on("listening", () => {
			log$4.success("[%s] listening %s:%d%s", network.name, network.host ?? "0.0.0.0", network.port, network.path ?? "/");
		});
		wss.on("connection", (socket, request) => {
			if (!isAuthorized(request, running.network.accessToken ?? "")) {
				safeClose(socket, 1008, "invalid access token");
				return;
			}
			const role = running.network.role ?? classifyForwardRole(request);
			const conn = {
				socket,
				role,
				options: running.options,
				serverName: running.network.name
			};
			this.forwardConnections.set(socket, conn);
			socket.on("message", (raw) => {
				this.handleApiMessage(socket, role, raw);
			});
			socket.on("close", () => {
				this.forwardConnections.delete(socket);
			});
			socket.on("error", (error) => {
				log$4.warn("[%s] forward socket error: %s", running.network.name, error instanceof Error ? error.message : String(error));
			});
			this.sendBootstrapMetaEvents(socket, role, conn.options);
		});
		wss.on("error", (error) => {
			log$4.warn("[%s] server error: %s", network.name, error instanceof Error ? error.message : String(error));
		});
	}
	startClientEndpoint(name) {
		const state = this.clientStates.get(name);
		if (!state || this.stopped) return;
		if (this.reverseConnections.has(name) || this.reconnectTimers.has(name)) return;
		const network = state.network;
		const role = network.role ?? "universal";
		const headers = {
			"User-Agent": "OneBot",
			"X-Self-ID": this.context.uin,
			"X-Client-Role": role
		};
		if (network.accessToken) headers.Authorization = `Bearer ${network.accessToken}`;
		const socket = new WebSocket(network.url, { headers });
		const conn = {
			socket,
			role,
			options: state.options,
			endpointUrl: network.url,
			reconnectIntervalMs: Math.max(1e3, network.reconnectIntervalMs ?? 5e3),
			name
		};
		this.reverseConnections.set(name, conn);
		socket.on("open", () => {
			log$4.info("[%s] reverse connected %s", name, network.url);
			this.sendBootstrapMetaEvents(socket, role, state.options);
		});
		socket.on("message", (raw) => {
			this.handleApiMessage(socket, role, raw);
		});
		socket.on("close", () => {
			this.reverseConnections.delete(name);
			if (this.stopped) return;
			if (!this.clientStates.has(name)) return;
			if (this.reconnectTimers.has(name)) return;
			const timer = setTimeout(() => {
				this.reconnectTimers.delete(name);
				if (this.stopped || !this.clientStates.has(name)) return;
				this.startClientEndpoint(name);
			}, conn.reconnectIntervalMs);
			timer.unref?.();
			this.reconnectTimers.set(name, timer);
		});
		socket.on("error", (error) => {
			log$4.warn("[%s] reverse error %s: %s", name, network.url, error instanceof Error ? error.message : String(error));
		});
	}
	async handleApiMessage(socket, role, raw) {
		if (role !== "api" && role !== "universal") return;
		const text = rawDataToString(raw);
		if (!text) return;
		safeSend(socket, await this.context.api.processRequest(text));
	}
	sendBootstrapMetaEvents(socket, role, options) {
		if (role !== "event" && role !== "universal") return;
		const events = [
			this.context.buildLifecycleEvent("connect"),
			this.context.buildLifecycleEvent("enable"),
			this.context.buildHeartbeatEvent()
		];
		for (const event of events) {
			const shaped = shapeEventForAdapter(event, options);
			if (!shaped) continue;
			safeSend(socket, JSON.stringify(shaped));
		}
	}
};
function classifyForwardRole(request) {
	const path = parseRequestPath(request.url ?? "/");
	if (path.endsWith("/api")) return "api";
	if (path.endsWith("/event")) return "event";
	return "universal";
}
function parseRequestPath(urlValue) {
	try {
		return new URL(urlValue, "ws://127.0.0.1").pathname;
	} catch {
		return "/";
	}
}
function normalizeWsPath(pathValue) {
	const path = (pathValue ?? "/").trim() || "/";
	if (path === "/") return "/";
	return path.endsWith("/") ? path.slice(0, -1) : path;
}
function activeServers(config) {
	return config.networks.wsServers.filter((n) => n.enabled !== false);
}
function activeClients(config) {
	return config.networks.wsClients.filter((n) => n.enabled !== false && !!n.url);
}
function wsServerSignature(network) {
	return `${network.host ?? "0.0.0.0"}:${network.port}${normalizeWsPath(network.path)}#${network.role ?? "auto"}#${network.accessToken ?? ""}`;
}
function wsClientSignature(network) {
	const role = network.role ?? "universal";
	const reconnectIntervalMs = Math.max(1e3, network.reconnectIntervalMs ?? 5e3);
	return `${network.url}#${role}#${reconnectIntervalMs}#${network.accessToken ?? ""}`;
}
function isAuthorized(request, token) {
	if (!token) return true;
	const rawAuth = request.headers.authorization;
	if ((Array.isArray(rawAuth) ? rawAuth[0] : rawAuth ?? "") === `Bearer ${token}`) return true;
	try {
		if (new URL(request.url ?? "/", "ws://127.0.0.1").searchParams.get("access_token") === token) return true;
	} catch {}
	return false;
}
function rawDataToString(raw) {
	if (typeof raw === "string") return raw;
	if (Buffer.isBuffer(raw)) return raw.toString("utf8");
	if (Array.isArray(raw)) return Buffer.concat(raw).toString("utf8");
	if (raw instanceof ArrayBuffer) return Buffer.from(new Uint8Array(raw)).toString("utf8");
	if (ArrayBuffer.isView(raw)) return Buffer.from(raw.buffer, raw.byteOffset, raw.byteLength).toString("utf8");
	return "";
}
function safeSend(socket, payload) {
	if (socket.readyState !== WebSocket.OPEN) return;
	socket.send(payload, (error) => {
		if (error) log$4.warn("send error: %s", error instanceof Error ? error.message : String(error));
	});
}
function safeClose(socket, code = 1e3, reason = "normal") {
	if (socket.readyState === WebSocket.CLOSED || socket.readyState === WebSocket.CLOSING) return;
	socket.close(code, reason);
}
//#endregion
//#region src/onebot/instance.ts
var log$3 = createLogger("Event");
var OneBotInstance = class OneBotInstance {
	uin;
	qqInfo;
	bridge;
	apiHandler;
	eventConverter;
	messageStore;
	httpTransport;
	httpPostTransport;
	wsTransport;
	rkeyCache;
	pids = /* @__PURE__ */ new Set();
	online = true;
	heartbeatTimer = null;
	static HEARTBEAT_INTERVAL = 3e4;
	constructor(uin, qqInfo, bridge, config) {
		this.uin = uin;
		this.qqInfo = qqInfo;
		this.bridge = bridge;
		this.eventConverter = new EventConverter();
		this.rkeyCache = new RKeyCache();
		this.eventConverter.setImageUrlResolver((element, isGroup) => this.rkeyCache.resolveImageUrl(this.bridge, element, isGroup));
		this.eventConverter.setMediaUrlResolver(async (element, isGroup, sessionId) => {
			if (!element.url) try {
				if (element.type === "file" && element.fileId) element.url = isGroup ? await this.bridge.fetchGroupFileUrl(sessionId, element.fileId) : element.fileHash ? await this.bridge.fetchPrivateFileUrl(sessionId, element.fileId, element.fileHash) : "";
				else if ((element.type === "record" || element.type === "video") && element.mediaNode) if (isGroup) element.url = element.type === "record" ? await this.bridge.fetchGroupPttUrlByNode(sessionId, element.mediaNode) : await this.bridge.fetchGroupVideoUrlByNode(sessionId, element.mediaNode);
				else element.url = element.type === "record" ? await this.bridge.fetchPrivatePttUrlByNode(element.mediaNode) : await this.bridge.fetchPrivateVideoUrlByNode(element.mediaNode);
			} catch {}
			return this.rkeyCache.resolveMediaUrl(this.bridge, element, isGroup);
		});
		this.eventConverter.setMessageIdResolver((isGroup, sessionId, sequence, eventName) => hashMessageIdInt32(sequence, sessionId, eventName || (isGroup ? "group_message" : "private_message")));
		this.messageStore = new MessageStore(path.join("data", this.uin, "messages.json"));
		this.apiHandler = new ApiHandler(buildApiContext({
			uin: this.uin,
			qqInfo: this.qqInfo,
			bridge: this.bridge,
			messageStore: this.messageStore,
			musicSignUrl: config.musicSignUrl,
			cacheMessageMeta: (messageId, meta) => this.cacheMessageMeta(messageId, meta)
		}));
		this.httpTransport = new HttpTransport(config, { api: this.apiHandler });
		this.httpPostTransport = new HttpPostTransport(config, {
			uin: this.uin,
			api: this.apiHandler
		});
		this.wsTransport = new WsTransport(config, {
			uin: this.uin,
			api: this.apiHandler,
			buildLifecycleEvent: (subType) => this.makeLifecycleEvent(subType),
			buildHeartbeatEvent: () => this.makeHeartbeatEvent()
		});
		this.httpTransport.start();
		this.httpPostTransport.start();
		this.wsTransport.start();
		this.startHeartbeat();
		this.rkeyCache.warmUp(this.bridge, this.uin);
	}
	reloadConfig(config) {
		this.httpTransport.reloadConfig(config);
		this.httpPostTransport.reloadConfig(config);
		this.wsTransport.reloadConfig(config);
	}
	dispose() {
		this.online = false;
		this.stopHeartbeat();
		this.httpTransport.stop();
		this.httpPostTransport.stop();
		this.wsTransport.stop();
		this.messageStore.close();
	}
	onBridgeEvent(event) {
		this.cacheMessageMetaFromBridgeEvent(event);
		this.dispatchBridgeEventAsync(event);
	}
	async dispatchBridgeEventAsync(event) {
		const converted = await this.eventConverter.convert(this.uin, event);
		if (!converted) return;
		this.dispatchEvent(converted);
	}
	addPid(pid) {
		this.pids.add(pid);
	}
	removePid(pid) {
		this.pids.delete(pid);
	}
	hasPid(pid) {
		return this.pids.has(pid);
	}
	getPids() {
		return [...this.pids];
	}
	get empty() {
		return this.pids.size === 0;
	}
	dispatchEvent(event) {
		this.cacheMessageEvent(event);
		this.logReceivedMessage(event);
		const payload = buildDispatchPayload(event);
		this.wsTransport.publishEvent(event, payload);
		this.httpPostTransport.publishEvent(event, payload);
	}
	logReceivedMessage(event) {
		const isSelf = event.post_type === "message_sent";
		if (event.post_type !== "message" && !isSelf) return;
		const messageId = toInt(event.message_id);
		const isGroup = event.message_type === "group";
		const parts = [];
		const message = event.message;
		if (Array.isArray(message)) for (const seg of message) {
			if (typeof seg !== "object" || seg === null || Array.isArray(seg)) continue;
			const type = String(seg.type ?? "");
			const data = typeof seg.data === "object" && seg.data !== null && !Array.isArray(seg.data) ? seg.data : {};
			if (type === "text" && data.text) {
				const text = String(data.text);
				const preview = text.length > 50 ? text.substring(0, 50) + "..." : text;
				parts.push(preview);
			} else if (type === "image") parts.push("[图片]");
			else if (type === "face") parts.push("[表情]");
			else if (type === "at") parts.push(`@${data.qq || ""}`);
			else if (type === "reply") parts.push(`[回复:${data.id || ""}]`);
			else if (type === "record") parts.push("[语音]");
			else if (type === "video") parts.push("[视频]");
			else parts.push(`[${type}]`);
		}
		const content = parts.join(" ").trim() || "[空消息]";
		const idStr = `ID:${messageId}`;
		const selfTag = isSelf ? "[自身] " : "";
		if (isGroup) {
			const groupId = toInt(event.group_id);
			const userId = toInt(event.user_id);
			const sender = event.sender;
			const nickname = sender?.card || sender?.nickname || String(userId);
			log$3.success(`${selfTag}群 ${groupId} | ${nickname}(${userId}): ${idStr} ${content}`);
		} else {
			const userId = toInt(event.user_id);
			const nickname = event.sender?.nickname || String(userId);
			log$3.success(`${selfTag}私聊 ${nickname}(${userId}): ${idStr} ${content}`);
		}
	}
	cacheMessageEvent(event) {
		if (event.post_type !== "message" && event.post_type !== "message_sent") return;
		const messageId = toInt(event.message_id);
		if (messageId === 0) return;
		const isGroup = event.message_type === "group";
		const sessionId = isGroup ? toInt(event.group_id) : toInt(event.user_id);
		const sequence = toInt(event.message_seq);
		const eventName = isGroup ? GROUP_MESSAGE_EVENT : PRIVATE_MESSAGE_EVENT;
		if (sessionId === 0) return;
		this.messageStore.storeEvent(messageId, isGroup, sessionId, sequence, eventName, event);
	}
	cacheMessageMetaFromBridgeEvent(event) {
		if (event.kind === "group_message") {
			const messageId = hashMessageIdInt32(event.msgSeq, event.groupId, GROUP_MESSAGE_EVENT);
			this.cacheMessageMeta(messageId, {
				isGroup: true,
				targetId: event.groupId,
				sequence: event.msgSeq,
				eventName: GROUP_MESSAGE_EVENT,
				clientSequence: 0,
				random: event.msgId,
				timestamp: event.time
			});
			return;
		}
		if (event.kind === "friend_message") {
			const messageId = hashMessageIdInt32(event.msgSeq, event.senderUin, PRIVATE_MESSAGE_EVENT);
			this.cacheMessageMeta(messageId, {
				isGroup: false,
				targetId: event.senderUin,
				sequence: event.msgSeq,
				eventName: PRIVATE_MESSAGE_EVENT,
				clientSequence: 0,
				random: event.msgId,
				timestamp: event.time
			});
			return;
		}
		if (event.kind === "temp_message") {
			const messageId = hashMessageIdInt32(event.msgSeq, event.senderUin, PRIVATE_MESSAGE_EVENT);
			this.cacheMessageMeta(messageId, {
				isGroup: false,
				targetId: event.senderUin,
				sequence: event.msgSeq,
				eventName: PRIVATE_MESSAGE_EVENT,
				clientSequence: 0,
				random: 0,
				timestamp: event.time
			});
		}
	}
	cacheMessageMeta(messageId, meta) {
		if (!Number.isInteger(messageId) || messageId === 0) return;
		this.messageStore.storeMeta(messageId, meta);
	}
	makeLifecycleEvent(subType) {
		const selfId = parseInt(this.uin, 10) || 0;
		return {
			time: Math.floor(Date.now() / 1e3),
			self_id: selfId,
			post_type: "meta_event",
			meta_event_type: "lifecycle",
			sub_type: subType,
			status: {
				online: this.online,
				good: this.online
			}
		};
	}
	startHeartbeat() {
		this.heartbeatTimer = setInterval(() => {
			this.dispatchEvent(this.makeHeartbeatEvent());
		}, OneBotInstance.HEARTBEAT_INTERVAL);
		this.heartbeatTimer.unref?.();
	}
	makeHeartbeatEvent() {
		const selfId = parseInt(this.uin, 10) || 0;
		return {
			time: Math.floor(Date.now() / 1e3),
			self_id: selfId,
			post_type: "meta_event",
			meta_event_type: "heartbeat",
			status: {
				online: this.online,
				good: this.online
			},
			interval: OneBotInstance.HEARTBEAT_INTERVAL
		};
	}
	stopHeartbeat() {
		if (this.heartbeatTimer) {
			clearInterval(this.heartbeatTimer);
			this.heartbeatTimer = null;
		}
	}
};
function toInt(value) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.trunc(value);
	if (typeof value === "string" && value.trim()) {
		const parsed = Number(value);
		if (Number.isFinite(parsed)) return Math.trunc(parsed);
	}
	return 0;
}
//#endregion
//#region src/onebot/manager.ts
var log$2 = createLogger("OneBot");
var VERBOSE_WARMUP = process.env.SNOWLUMA_VERBOSE_WARMUP === "1";
var OneBotManager = class {
	instances = /* @__PURE__ */ new Map();
	bind(bridgeManager) {
		bridgeManager.setSessionStartedCallback((uin, qqInfo, bridge) => {
			this.onSessionStarted(uin, qqInfo, bridge);
		});
		bridgeManager.setSessionClosedCallback((uin) => {
			this.onSessionClosed(uin);
		});
		bridgeManager.setEventCallback((uin, event) => {
			this.onBridgeEvent(uin, event);
		});
	}
	getInstance(uin) {
		return this.instances.get(uin) ?? null;
	}
	getInstances() {
		return [...this.instances.values()];
	}
	reloadConfig(uin) {
		const instance = this.instances.get(uin);
		if (!instance) return false;
		const config = loadOneBotConfig(uin);
		instance.reloadConfig(config);
		log$2.info("configuration reloaded: UIN=%s", uin);
		return true;
	}
	dispose() {
		for (const instance of this.instances.values()) instance.dispose();
		this.instances.clear();
	}
	onSessionStarted(uin, qqInfo, bridge) {
		if (this.instances.has(uin)) return;
		const instance = new OneBotInstance(uin, qqInfo, bridge, loadOneBotConfig(uin));
		const activePid = bridge.activePid;
		if (activePid !== null) instance.addPid(activePid);
		this.instances.set(uin, instance);
		log$2.info("session started: UIN=%s", uin);
		warmUpBridgeState(uin, qqInfo, bridge).catch((err) => {
			log$2.warn("warmup error for UIN %s: %s", uin, err instanceof Error ? err.stack ?? err.message : String(err));
		});
	}
	onSessionClosed(uin) {
		const instance = this.instances.get(uin);
		if (!instance) return;
		instance.dispose();
		this.instances.delete(uin);
		log$2.info("session closed: UIN=%s", uin);
	}
	onBridgeEvent(uin, event) {
		const instance = this.instances.get(uin);
		if (!instance) return;
		instance.onBridgeEvent(event);
	}
};
async function warmUpBridgeState(uin, qqInfo, bridge) {
	try {
		const friends = await bridge.fetchFriendList();
		log$2.info("friends loaded: UIN=%s count=%d", uin, friends.length);
		const selfUin = parseInt(uin, 10) || 0;
		for (const f of friends) if (f.uin === selfUin) {
			qqInfo.setSelfProfile({
				uin: f.uin,
				uid: f.uid,
				nickname: f.nickname || uin,
				remark: "",
				qid: "",
				sex: "unknown",
				age: 0,
				sign: "",
				avatar: ""
			});
			qqInfo.nickname = f.nickname || uin;
			log$2.debug("self info: UIN=%s uid=%s nickname=%s", uin, f.uid, f.nickname ?? "");
			break;
		}
	} catch (e) {
		log$2.warn("failed to load friends for UIN %s: %s", uin, e instanceof Error ? e.message : String(e));
	}
	let groups = [];
	try {
		groups = await bridge.fetchGroupList();
		log$2.info("groups loaded: UIN=%s count=%d", uin, groups.length);
	} catch (e) {
		log$2.warn("failed to load groups for UIN %s: %s", uin, e instanceof Error ? e.message : String(e));
	}
	let loadedGroupCount = 0;
	let loadedMemberCount = 0;
	let failedGroupCount = 0;
	for (const g of groups) try {
		const members = await bridge.fetchGroupMemberList(g.groupId);
		loadedGroupCount += 1;
		loadedMemberCount += members.length;
		if (VERBOSE_WARMUP) log$2.debug("members loaded: group=%d count=%d", g.groupId, members.length);
	} catch (e) {
		failedGroupCount += 1;
		log$2.warn("failed to load members for group %d: %s", g.groupId, e instanceof Error ? e.message : String(e));
	}
	log$2.info("member warmup completed: UIN=%s groups=%d/%d members=%d failed=%d", uin, loadedGroupCount, groups.length, loadedMemberCount, failedGroupCount);
}
//#endregion
//#region src/common/runtime.ts
var CONFIG_DIR = "config";
var RUNTIME_CONFIG_PATH = path.join(CONFIG_DIR, "runtime.json");
var DEFAULT_RUNTIME_CONFIG = { webuiPort: 5099 };
function loadRuntimeConfig() {
	fs.mkdirSync(CONFIG_DIR, { recursive: true });
	const loaded = tryLoadRuntimeConfig();
	if (!loaded) {
		saveRuntimeConfig(DEFAULT_RUNTIME_CONFIG);
		return { ...DEFAULT_RUNTIME_CONFIG };
	}
	const normalized = { webuiPort: normalizePort(loaded.webuiPort ?? 5099, 5099) };
	if (normalized.webuiPort !== loaded.webuiPort) saveRuntimeConfig(normalized);
	return normalized;
}
function tryLoadRuntimeConfig() {
	if (!fs.existsSync(RUNTIME_CONFIG_PATH)) return null;
	try {
		const raw = fs.readFileSync(RUNTIME_CONFIG_PATH, "utf8");
		const parsed = JSON.parse(raw);
		if (!isObject(parsed)) return null;
		return { webuiPort: normalizePort(parsed.webuiPort ?? 5099, 5099) };
	} catch {
		return null;
	}
}
function saveRuntimeConfig(config) {
	fs.writeFileSync(RUNTIME_CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
}
function normalizePort(value, fallback) {
	if (typeof value === "number" && Number.isFinite(value)) {
		const n = Math.trunc(value);
		if (n > 0 && n <= 65535) return n;
		return fallback;
	}
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) {
			const port = Math.trunc(n);
			if (port > 0 && port <= 65535) return port;
		}
	}
	return fallback;
}
function isObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region src/hook/hook-packet-client.ts
var HookPacketClient = class {
	constructor(client) {
		this.client = client;
	}
	async sendPacket(serviceCmd, body, timeoutMs = 15e3) {
		if (!this.client.isLoggedIn) return {
			success: false,
			gotResponse: false,
			errorCode: -1,
			errorMessage: "qq_hook client is not logged in",
			responseData: null
		};
		try {
			const reply = await this.client.send(serviceCmd, body, {
				wantReply: true,
				replyTimeoutMs: timeoutMs
			});
			return {
				success: reply.error === 0,
				gotResponse: true,
				errorCode: reply.error,
				errorMessage: reply.message || "",
				responseData: reply.body
			};
		} catch (error) {
			return {
				success: false,
				gotResponse: false,
				errorCode: -1,
				errorMessage: error instanceof Error ? error.message : String(error),
				responseData: null
			};
		}
	}
};
//#endregion
//#region src/hook/injector.ts
var __dirname = path.dirname(fileURLToPath$1(import.meta.url));
var nativeAddon = null;
var nativeLoadError = null;
function loadNativeAddon(addonPath) {
	const mod = { exports: {} };
	process.dlopen(mod, addonPath);
	return mod.exports;
}
function platformBinaryName(ext) {
	if (process.platform === "win32" && process.arch === "x64") return `snowluma-win32-x64.${ext}`;
	return `snowluma-${process.platform}-${process.arch}.${ext}`;
}
function platformInjectableExt() {
	return process.platform === "win32" ? "dll" : "so";
}
function defaultProcessName() {
	return process.platform === "win32" ? "QQ.exe" : "qq";
}
function nativeSearchDirs() {
	return [
		path.resolve(__dirname, "native"),
		path.resolve(__dirname, "..", "..", "..", "runtime", "native"),
		path.resolve(process.cwd(), "dist", "native"),
		path.resolve(process.cwd(), "packages", "runtime", "native")
	];
}
function resolveHookNativePath(ext) {
	const fileName = platformBinaryName(ext);
	for (const dir of nativeSearchDirs()) {
		const fullPath = path.join(dir, fileName);
		if (existsSync(fullPath)) return fullPath;
	}
	return null;
}
function getNativeHookAddon() {
	if (nativeAddon) return nativeAddon;
	const addonPath = resolveHookNativePath("node");
	if (!addonPath) {
		nativeLoadError = `No hook native addon found for ${process.platform}-${process.arch}`;
		return null;
	}
	try {
		nativeAddon = loadNativeAddon(addonPath);
		nativeLoadError = null;
		return nativeAddon;
	} catch (error) {
		nativeLoadError = error instanceof Error ? error.message : String(error);
		return null;
	}
}
function getNativeHookLoadError() {
	return nativeLoadError;
}
function listHookProcesses() {
	const addon = getNativeHookAddon();
	if (!addon) return [];
	return [...new Set(addon.getAllMainProcess())].filter((pid) => Number.isInteger(pid) && pid > 0).sort((a, b) => a - b).map((pid) => ({
		pid,
		name: defaultProcessName(),
		path: ""
	}));
}
function injectHookProcess(pid) {
	const addon = getNativeHookAddon();
	if (!addon) throw new Error(getNativeHookLoadError() ?? "hook native addon is not available");
	const injectableExt = platformInjectableExt();
	const dllPath = resolveHookNativePath(injectableExt);
	if (!dllPath) throw new Error(`No hook ${injectableExt} found for ${process.platform}-${process.arch}`);
	return {
		method: "loadModuleManual",
		handle: addon.loadModuleManual(pid, dllPath)
	};
}
function unloadHookProcess(pid, handle) {
	const addon = getNativeHookAddon();
	if (!addon) throw new Error(getNativeHookLoadError() ?? "hook native addon is not available");
	addon.unloadModuleManual(pid, handle);
}
//#endregion
//#region src/hook/qq-hook-client.ts
var PIPE_MAGIC = 827344977;
var DEFAULT_ACK_TIMEOUT_MS = 5e3;
var DEFAULT_REPLY_TIMEOUT_MS = 3e4;
var PipeOp = /* @__PURE__ */ function(PipeOp) {
	PipeOp[PipeOp["hello"] = 1] = "hello";
	PipeOp[PipeOp["sendRequest"] = 2] = "sendRequest";
	PipeOp[PipeOp["sendAck"] = 3] = "sendAck";
	PipeOp[PipeOp["sendReply"] = 4] = "sendReply";
	PipeOp[PipeOp["error"] = 5] = "error";
	PipeOp[PipeOp["recvPacket"] = 6] = "recvPacket";
	PipeOp[PipeOp["loginState"] = 7] = "loginState";
	return PipeOp;
}({});
var PipeFlagWantReply = 1;
var PipeFlagLoggedIn = 4;
function linuxRuntimeDir() {
	const explicit = process.env.SNOWLUMA_HOOK_RUNTIME_DIR;
	if (explicit && explicit.length > 0) return explicit;
	const xdg = process.env.XDG_RUNTIME_DIR;
	if (xdg && xdg.length > 0) return xdg;
	return `/tmp/snowluma-${typeof process.geteuid === "function" ? process.geteuid() : os.userInfo().uid}`;
}
function mojoPipeName(pid, suffix) {
	if (process.platform === "win32") return `\\\\.\\pipe\\mojo.${pid}.${suffix}`;
	return path.join(linuxRuntimeDir(), `mojo.${pid}.${suffix}.sock`);
}
function toBuffer(body) {
	if (Buffer.isBuffer(body)) return body;
	if (body instanceof Uint8Array) return Buffer.from(body);
	if (typeof body === "string") return Buffer.from(body, "utf8");
	if (body == null) return Buffer.alloc(0);
	throw new TypeError("body must be Buffer, Uint8Array, string, or null");
}
function createDeferred() {
	let resolve;
	let reject;
	return {
		promise: new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		}),
		resolve,
		reject
	};
}
function withTimeout(promise, timeoutMs, label) {
	if (!timeoutMs || timeoutMs <= 0) return promise;
	return new Promise((resolve, reject) => {
		const timer = setTimeout(() => {
			reject(/* @__PURE__ */ new Error(`${label} timed out after ${timeoutMs} ms`));
		}, timeoutMs);
		promise.then((value) => {
			clearTimeout(timer);
			resolve(value);
		}, (error) => {
			clearTimeout(timer);
			reject(error);
		});
	});
}
function encodeFrame({ op, requestId = 0, status = 0, flags = 0, value0 = 0n, cmd = "", msg = "", body = Buffer.alloc(0) }) {
	const cmdBuf = Buffer.from(cmd, "utf8");
	const msgBuf = Buffer.from(msg, "utf8");
	const bodyBuf = toBuffer(body);
	const header = Buffer.alloc(40);
	header.writeUInt32LE(PIPE_MAGIC, 0);
	header.writeUInt16LE(1, 4);
	header.writeUInt16LE(op, 6);
	header.writeUInt32LE(requestId >>> 0, 8);
	header.writeInt32LE(status | 0, 12);
	header.writeUInt32LE(flags >>> 0, 16);
	header.writeUInt32LE(cmdBuf.length >>> 0, 20);
	header.writeUInt32LE(msgBuf.length >>> 0, 24);
	header.writeUInt32LE(bodyBuf.length >>> 0, 28);
	header.writeBigUInt64LE(BigInt(value0), 32);
	return Buffer.concat([
		header,
		cmdBuf,
		msgBuf,
		bodyBuf
	]);
}
var FrameReader = class {
	buffer = Buffer.alloc(0);
	constructor(onFrame) {
		this.onFrame = onFrame;
	}
	push(chunk) {
		this.buffer = Buffer.concat([this.buffer, chunk]);
		while (this.buffer.length >= 40) {
			const magic = this.buffer.readUInt32LE(0);
			const version = this.buffer.readUInt16LE(4);
			if (magic !== 827344977 || version !== 1) throw new Error(`bad frame header magic=0x${magic.toString(16)} version=${version}`);
			const cmdLen = this.buffer.readUInt32LE(20);
			const msgLen = this.buffer.readUInt32LE(24);
			const bodyLen = this.buffer.readUInt32LE(28);
			const total = 40 + cmdLen + msgLen + bodyLen;
			if (this.buffer.length < total) return;
			const frame = {
				op: this.buffer.readUInt16LE(6),
				requestId: this.buffer.readUInt32LE(8),
				status: this.buffer.readInt32LE(12),
				flags: this.buffer.readUInt32LE(16),
				value0: this.buffer.readBigUInt64LE(32),
				cmd: "",
				msg: "",
				body: Buffer.alloc(0)
			};
			let offset = 40;
			frame.cmd = this.buffer.subarray(offset, offset + cmdLen).toString("utf8");
			offset += cmdLen;
			frame.msg = this.buffer.subarray(offset, offset + msgLen).toString("utf8");
			offset += msgLen;
			frame.body = Buffer.from(this.buffer.subarray(offset, offset + bodyLen));
			this.buffer = this.buffer.subarray(total);
			this.onFrame(frame);
		}
	}
};
var QqHookClient = class QqHookClient extends EventEmitter$1 {
	pid;
	defaultAckTimeoutMs;
	defaultReplyTimeoutMs;
	controlSocket = null;
	recvSocket = null;
	controlConnectPromise = null;
	recvConnectPromise = null;
	nextRequestId = 1;
	pendingAcks = /* @__PURE__ */ new Map();
	pendingReplies = /* @__PURE__ */ new Map();
	controlHello = null;
	recvHello = null;
	controlHelloResolver = null;
	recvHelloResolver = null;
	controlWriteChain = Promise.resolve();
	closed = false;
	loginState = {
		loggedIn: false,
		uin: "0",
		uinNumber: 0n
	};
	loginWaiters = [];
	constructor(pid, { ackTimeoutMs = DEFAULT_ACK_TIMEOUT_MS, replyTimeoutMs = DEFAULT_REPLY_TIMEOUT_MS } = {}) {
		super();
		this.pid = pid;
		this.defaultAckTimeoutMs = ackTimeoutMs;
		this.defaultReplyTimeoutMs = replyTimeoutMs;
	}
	get isLoggedIn() {
		return this.loginState.loggedIn;
	}
	get isClosed() {
		return this.closed;
	}
	get currentUin() {
		return this.loginState.uin;
	}
	get currentUinNumber() {
		return this.loginState.uinNumber;
	}
	getLoginState() {
		return { ...this.loginState };
	}
	async waitForLogin({ timeoutMs = 0 } = {}) {
		await this.connect();
		if (this.loginState.loggedIn) return this.getLoginState();
		const deferred = createDeferred();
		this.loginWaiters.push(deferred);
		return withTimeout(deferred.promise, timeoutMs, "waitForLogin");
	}
	static controlPipeName(pid) {
		return mojoPipeName(pid, "control");
	}
	static recvPipeName(pid) {
		return mojoPipeName(pid, "recv");
	}
	/**
	* Lightweight liveness check for the control pipe. Used to detect whether an
	* existing SnowLuma hook is still hosted inside the QQ.exe process without
	* opening the pipe, so probing cannot disturb the first real client connect.
	*/
	static async probePipe(pid) {
		return (await QqHookClient.listLivePipes()).has(pid);
	}
	/**
	* Enumerate every PID currently hosting a SnowLuma `mojo.<pid>.control` pipe
	* in a single filesystem listing. The HookManager's pipe-watcher uses this
	* to drive connect/reconnect decisions without per-PID stat calls.
	*/
	static async listLivePipes() {
		const result = /* @__PURE__ */ new Set();
		try {
			if (process.platform === "win32") {
				const names = await promises.readdir("\\\\.\\pipe\\");
				for (const name of names) {
					const m = /^mojo\.(\d+)\.control$/i.exec(name);
					if (m) result.add(Number(m[1]));
				}
			} else {
				const names = await promises.readdir(linuxRuntimeDir());
				for (const name of names) {
					const m = /^mojo\.(\d+)\.control\.sock$/.exec(name);
					if (m) result.add(Number(m[1]));
				}
			}
		} catch {}
		return result;
	}
	async connect() {
		if (this.closed) throw new Error("qq_hook client is closed");
		if (this.controlSocket && this.controlHello) return this.controlHello;
		if (this.controlConnectPromise) return this.controlConnectPromise;
		this.controlConnectPromise = (async () => {
			this.controlSocket = await this.connectSocket(QqHookClient.controlPipeName(this.pid), "control", (frame) => this.handleControlFrame(frame));
			this.controlHello = await this.waitForHello(false);
			return this.controlHello;
		})();
		try {
			return await this.controlConnectPromise;
		} finally {
			this.controlConnectPromise = null;
		}
	}
	async startRecv(onPacket) {
		if (this.closed) throw new Error("qq_hook client is closed");
		if (typeof onPacket === "function") this.on("packet", onPacket);
		if (this.recvSocket && this.recvHello) return this.recvHello;
		if (this.recvConnectPromise) return this.recvConnectPromise;
		this.recvConnectPromise = (async () => {
			this.recvSocket = await this.connectSocket(QqHookClient.recvPipeName(this.pid), "recv", (frame) => this.handleRecvFrame(frame));
			this.recvHello = await this.waitForHello(true);
			return this.recvHello;
		})();
		try {
			return await this.recvConnectPromise;
		} finally {
			this.recvConnectPromise = null;
		}
	}
	async connectAll({ recv = true } = {}) {
		return {
			control: await this.connect(),
			recv: recv ? await this.startRecv() : null
		};
	}
	async send(cmd, body, { wantReply = true, ackTimeoutMs = this.defaultAckTimeoutMs, replyTimeoutMs = this.defaultReplyTimeoutMs } = {}) {
		await this.connect();
		const requestId = this.nextRequestId++ >>> 0;
		const payload = encodeFrame({
			op: PipeOp.sendRequest,
			requestId,
			flags: wantReply ? PipeFlagWantReply : 0,
			cmd,
			body
		});
		const ackDeferred = createDeferred();
		this.pendingAcks.set(requestId, {
			resolve: ackDeferred.resolve,
			reject: ackDeferred.reject,
			wantReply
		});
		let replyDeferred = null;
		if (wantReply) {
			replyDeferred = createDeferred();
			this.pendingReplies.set(requestId, replyDeferred);
		}
		try {
			await this.writeControl(payload);
			await withTimeout(ackDeferred.promise, ackTimeoutMs, `send ack ${requestId}`);
			if (!wantReply) return { requestId };
			return await withTimeout(replyDeferred.promise, replyTimeoutMs, `send reply ${requestId}`);
		} catch (error) {
			this.pendingAcks.delete(requestId);
			this.pendingReplies.delete(requestId);
			throw error;
		}
	}
	async sendNoReply(cmd, body, options = {}) {
		return this.send(cmd, body, {
			...options,
			wantReply: false
		});
	}
	async sendAndWait(cmd, body, options = {}) {
		return this.send(cmd, body, {
			...options,
			wantReply: true
		});
	}
	async sendMany(items, { concurrency = 64, wantReply = true, ackTimeoutMs = this.defaultAckTimeoutMs, replyTimeoutMs = this.defaultReplyTimeoutMs } = {}) {
		const results = new Array(items.length);
		let nextIndex = 0;
		const workerCount = Math.max(1, Math.min(concurrency | 0, items.length || 1));
		const worker = async () => {
			for (;;) {
				const index = nextIndex;
				nextIndex += 1;
				if (index >= items.length) return;
				const item = items[index];
				const itemWantReply = item.wantReply ?? wantReply;
				results[index] = await this.send(item.cmd, item.body, {
					wantReply: itemWantReply,
					ackTimeoutMs: item.ackTimeoutMs ?? ackTimeoutMs,
					replyTimeoutMs: item.replyTimeoutMs ?? replyTimeoutMs
				});
			}
		};
		await Promise.all(Array.from({ length: workerCount }, () => worker()));
		return results;
	}
	waitForPacket(predicate = () => true, { timeoutMs = 0 } = {}) {
		return new Promise((resolve, reject) => {
			let timer = null;
			const cleanup = () => {
				this.off("packet", onPacket);
				if (timer) {
					clearTimeout(timer);
					timer = null;
				}
			};
			const onPacket = (packet) => {
				try {
					if (!predicate(packet)) return;
					cleanup();
					resolve(packet);
				} catch (error) {
					cleanup();
					reject(error);
				}
			};
			this.on("packet", onPacket);
			if (timeoutMs > 0) timer = setTimeout(() => {
				cleanup();
				reject(/* @__PURE__ */ new Error(`recv packet timed out after ${timeoutMs} ms`));
			}, timeoutMs);
		});
	}
	close() {
		if (this.closed) return;
		this.closed = true;
		this.rejectControlPending(/* @__PURE__ */ new Error("qq_hook client closed"));
		this.rejectRecvPending(/* @__PURE__ */ new Error("qq_hook client closed"));
		this.rejectLoginWaiters(/* @__PURE__ */ new Error("qq_hook client closed"));
		if (this.controlSocket) {
			this.controlSocket.destroy();
			this.controlSocket = null;
		}
		if (this.recvSocket) {
			this.recvSocket.destroy();
			this.recvSocket = null;
		}
		this.controlHello = null;
		this.recvHello = null;
		this.controlWriteChain = Promise.resolve();
	}
	rejectLoginWaiters(error) {
		const waiters = this.loginWaiters;
		this.loginWaiters = [];
		for (const waiter of waiters) waiter.reject(error);
	}
	rejectControlPending(error) {
		for (const pending of this.pendingAcks.values()) pending.reject(error);
		for (const pending of this.pendingReplies.values()) pending.reject(error);
		this.pendingAcks.clear();
		this.pendingReplies.clear();
		if (this.controlHelloResolver) {
			this.controlHelloResolver.reject(error);
			this.controlHelloResolver = null;
		}
	}
	rejectRecvPending(error) {
		if (this.recvHelloResolver) {
			this.recvHelloResolver.reject(error);
			this.recvHelloResolver = null;
		}
	}
	writeControl(payload) {
		const socket = this.controlSocket;
		if (!socket || socket.destroyed) return Promise.reject(/* @__PURE__ */ new Error("control pipe is not connected"));
		const writePromise = this.controlWriteChain.then(() => new Promise((resolve, reject) => {
			if (!this.controlSocket || this.controlSocket.destroyed) {
				reject(/* @__PURE__ */ new Error("control pipe is not connected"));
				return;
			}
			socket.write(payload, (error) => {
				if (error) reject(error);
				else resolve();
			});
		}));
		this.controlWriteChain = writePromise.catch(() => {});
		return writePromise;
	}
	connectSocket(pipeName, kind, onFrame) {
		return new Promise((resolve, reject) => {
			const socket = net.createConnection(pipeName);
			const reader = new FrameReader(onFrame);
			const onInitialError = (error) => reject(error);
			socket.once("error", onInitialError);
			socket.once("connect", () => {
				socket.off("error", onInitialError);
				socket.on("data", (chunk) => {
					try {
						reader.push(chunk);
					} catch (error) {
						this.emit("error", error);
						socket.destroy(error instanceof Error ? error : void 0);
					}
				});
				socket.on("error", (error) => {
					this.emit("error", error);
				});
				socket.on("close", () => {
					this.handleSocketClose(kind);
					this.emit("close", kind);
				});
				resolve(socket);
			});
		});
	}
	waitForHello(recvPipe) {
		const deferred = createDeferred();
		if (recvPipe) this.recvHelloResolver = deferred;
		else this.controlHelloResolver = deferred;
		return deferred.promise;
	}
	resolveHello(frame, recvPipe) {
		const resolver = recvPipe ? this.recvHelloResolver : this.controlHelloResolver;
		if (!resolver) return;
		if (recvPipe) this.recvHelloResolver = null;
		else this.controlHelloResolver = null;
		resolver.resolve({
			pipeName: frame.msg,
			pid: Number(frame.value0),
			recvPipe
		});
	}
	handleSocketClose(kind) {
		if (kind === "control") {
			this.controlSocket = null;
			this.controlHello = null;
			this.rejectControlPending(/* @__PURE__ */ new Error("control pipe closed"));
			return;
		}
		this.recvSocket = null;
		this.recvHello = null;
		this.rejectRecvPending(/* @__PURE__ */ new Error("recv pipe closed"));
	}
	applyLoginStateFrame(frame) {
		const flaggedLoggedIn = (frame.flags & PipeFlagLoggedIn) !== 0;
		const statusLoggedIn = frame.status !== 0;
		const loggedIn = flaggedLoggedIn || statusLoggedIn;
		const uinNumber = BigInt(frame.value0);
		const uin = frame.msg || uinNumber.toString();
		const previous = this.loginState;
		const next = {
			loggedIn,
			uin,
			uinNumber
		};
		this.loginState = next;
		this.emit("loginState", next);
		if (previous.loggedIn !== next.loggedIn || previous.uin !== next.uin) {
			if (next.loggedIn) {
				const waiters = this.loginWaiters;
				this.loginWaiters = [];
				for (const waiter of waiters) waiter.resolve({ ...next });
			}
		}
	}
	handleControlFrame(frame) {
		if (frame.op === PipeOp.hello) {
			this.resolveHello(frame, false);
			return;
		}
		if (frame.op === PipeOp.loginState) {
			this.applyLoginStateFrame(frame);
			return;
		}
		if (frame.op === PipeOp.sendAck) {
			const pending = this.pendingAcks.get(frame.requestId);
			if (!pending) return;
			this.pendingAcks.delete(frame.requestId);
			pending.resolve({
				requestId: frame.requestId,
				wantReply: pending.wantReply
			});
			return;
		}
		if (frame.op === PipeOp.sendReply) {
			const pending = this.pendingReplies.get(frame.requestId);
			if (!pending) return;
			this.pendingReplies.delete(frame.requestId);
			pending.resolve({
				requestId: frame.requestId,
				error: frame.status,
				message: frame.msg,
				body: Buffer.from(frame.body)
			});
			return;
		}
		if (frame.op === PipeOp.error) {
			const error = new Error(frame.msg || `pipe error ${frame.status}`);
			const ack = this.pendingAcks.get(frame.requestId);
			if (ack) {
				this.pendingAcks.delete(frame.requestId);
				ack.reject(error);
			}
			const reply = this.pendingReplies.get(frame.requestId);
			if (reply) {
				this.pendingReplies.delete(frame.requestId);
				reply.reject(error);
			}
		}
	}
	handleRecvFrame(frame) {
		if (frame.op === PipeOp.hello) {
			this.resolveHello(frame, true);
			return;
		}
		if (frame.op === PipeOp.loginState) {
			this.applyLoginStateFrame(frame);
			return;
		}
		if (frame.op !== PipeOp.recvPacket) return;
		this.emit("packet", {
			seq: Number(frame.value0),
			error: frame.status,
			cmd: frame.cmd,
			uin: frame.msg,
			body: Buffer.from(frame.body)
		});
	}
};
//#endregion
//#region src/hook/hook-manager.ts
var log$1 = createLogger("Hook");
var DEFAULT_WATCHER_INTERVAL_MS = 1500;
var MIN_WATCHER_INTERVAL_MS = 250;
/**
* Manages SnowLuma hook injection and bridge connectivity for QQ.exe processes.
*
* Lifecycle: load -> inject DLL only (returns fast) -> background watcher
* detects the named pipe coming up and connects -> on QQ login the bridge is
* notified. The watcher also handles reconnect after a pipe drop and detects
* hooks that survived a previous SnowLuma restart.
*
* Concurrency: every per-PID mutation (load / unload / refresh / connect /
* close-handler / watcher reconcile) goes through a per-PID promise chain so
* users can spam buttons without races.
*/
var HookManager = class {
	states = /* @__PURE__ */ new Map();
	opsByPid = /* @__PURE__ */ new Map();
	watcherIntervalMs;
	watcherTimer = null;
	watcherTicking = false;
	disposed = false;
	constructor(ntqq, bridgeManager, options = {}) {
		this.ntqq = ntqq;
		this.bridgeManager = bridgeManager;
		this.watcherIntervalMs = Math.max(MIN_WATCHER_INTERVAL_MS, options.watcherIntervalMs ?? DEFAULT_WATCHER_INTERVAL_MS);
		this.scheduleWatcher(0);
	}
	async listProcesses() {
		const processes = listHookProcesses();
		const seen = /* @__PURE__ */ new Set();
		for (const proc of processes) {
			seen.add(proc.pid);
			const state = this.ensureState(proc.pid);
			state.name = proc.name || state.name;
			state.path = proc.path || state.path;
		}
		const result = [];
		for (const proc of processes) result.push(this.toPublicInfo(this.ensureState(proc.pid)));
		for (const state of this.states.values()) if (!seen.has(state.pid) && (state.injected || state.client)) result.push(this.toPublicInfo(state));
		return result.sort((a, b) => a.pid - b.pid);
	}
	loadProcess(pid) {
		if (!Number.isInteger(pid) || pid <= 0) throw new Error("invalid pid");
		return this.serialize(pid, () => this.loadProcessInternal(pid));
	}
	unloadProcess(pid) {
		if (!Number.isInteger(pid) || pid <= 0) throw new Error("invalid pid");
		return this.serialize(pid, () => this.unloadProcessInternal(pid));
	}
	/**
	* Re-probe the named pipe for `pid`, reconnect if it became available,
	* or tear down a stale connection if it disappeared. Safe to call at any
	* time; serialised against load/unload/watcher actions on the same PID.
	*/
	refreshProcess(pid) {
		if (!Number.isInteger(pid) || pid <= 0) throw new Error("invalid pid");
		return this.serialize(pid, () => this.refreshProcessInternal(pid));
	}
	dispose() {
		this.disposed = true;
		if (this.watcherTimer) {
			clearTimeout(this.watcherTimer);
			this.watcherTimer = null;
		}
		for (const state of this.states.values()) {
			this.tearDownClient(state);
			state.status = state.injected ? "disconnected" : "available";
		}
	}
	/**
	* Serialise an operation against a per-PID promise chain. Guarantees that
	* load / unload / refresh / watcher-driven connects for the same PID never
	* interleave even if the user mashes buttons.
	*/
	async serialize(pid, op) {
		const previous = this.opsByPid.get(pid) ?? Promise.resolve();
		let release;
		const completion = new Promise((resolve) => {
			release = resolve;
		});
		const chained = previous.then(() => completion);
		this.opsByPid.set(pid, chained);
		try {
			await previous.catch(() => void 0);
			return await op();
		} finally {
			release();
			if (this.opsByPid.get(pid) === chained) this.opsByPid.delete(pid);
		}
	}
	async loadProcessInternal(pid) {
		const state = this.ensureState(pid);
		state.error = "";
		state.status = "loading";
		try {
			if (!state.injected) if ((await QqHookClient.listLivePipes()).has(pid)) {
				state.injected = true;
				state.method = "reconnect";
				log$1.info("PID=%d already has SnowLuma pipe; will reconnect via watcher", pid);
			} else {
				state.injectResult = injectHookProcess(pid);
				state.injected = true;
				state.method = state.injectResult.method;
				log$1.info("SnowLuma loaded into PID=%d via %s", pid, state.method);
			}
			state.status = state.connected ? state.loggedIn ? "online" : "loaded" : "connecting";
		} catch (error) {
			state.status = "error";
			state.error = error instanceof Error ? error.message : String(error);
			log$1.error("load failed: PID=%d err=%s", pid, state.error);
		}
		this.scheduleWatcher(0);
		return this.toPublicInfo(state);
	}
	async unloadProcessInternal(pid) {
		const state = this.ensureState(pid);
		state.error = "";
		try {
			const wasLoggedIn = state.loggedIn;
			this.tearDownClient(state);
			if (wasLoggedIn) this.bridgeManager.onPidDisconnected(pid);
			const handle = state.injectResult?.handle;
			if (state.injected && handle) {
				unloadHookProcess(pid, handle);
				log$1.info("SnowLuma unloaded from PID=%d via unloadModuleManual", pid);
			}
			state.injected = false;
			state.injectResult = null;
			state.method = "";
			state.uin = "0";
			if ((await QqHookClient.listLivePipes()).has(pid)) {
				state.error = "DLL卸载失败：命名管道仍然存在，watcher将自动重连";
				state.status = "connecting";
				log$1.warn("unload verification failed: PID=%d pipe still exists after unloadModuleManual, watcher will reconnect", pid);
			} else {
				state.status = "available";
				state.error = "";
			}
		} catch (error) {
			state.status = "error";
			state.error = error instanceof Error ? error.message : String(error);
			log$1.error("unload failed: PID=%d err=%s", pid, state.error);
		}
		return this.toPublicInfo(state);
	}
	async refreshProcessInternal(pid) {
		const state = this.ensureState(pid);
		state.error = "";
		try {
			if ((await QqHookClient.listLivePipes()).has(pid)) {
				if (!state.injected) {
					state.injected = true;
					state.method = state.method || "reconnect";
				}
				if (state.client?.isClosed) this.tearDownClient(state);
				if (!state.connected) await this.attemptConnect(state);
				else state.status = state.loggedIn ? "online" : "loaded";
			} else {
				const wasLoggedIn = state.loggedIn;
				this.tearDownClient(state);
				if (wasLoggedIn) this.bridgeManager.onPidDisconnected(pid);
				state.status = state.injected ? "disconnected" : "available";
			}
		} catch (error) {
			state.error = error instanceof Error ? error.message : String(error);
			state.status = state.injected ? "disconnected" : "error";
			log$1.warn("refresh failed: PID=%d err=%s", pid, state.error);
		}
		return this.toPublicInfo(state);
	}
	ensureState(pid) {
		let state = this.states.get(pid);
		if (!state) {
			state = {
				pid,
				name: "QQ.exe",
				path: "",
				injected: false,
				connected: false,
				loggedIn: false,
				uin: "0",
				status: "available",
				error: "",
				method: "",
				client: null,
				sender: null,
				injectResult: null,
				bound: false
			};
			this.states.set(pid, state);
		}
		return state;
	}
	scheduleWatcher(delayMs) {
		if (this.disposed) return;
		if (this.watcherTimer) {
			clearTimeout(this.watcherTimer);
			this.watcherTimer = null;
		}
		this.watcherTimer = setTimeout(() => {
			this.watcherTimer = null;
			this.tickWatcher();
		}, Math.max(0, delayMs));
	}
	async tickWatcher() {
		if (this.disposed) return;
		if (this.watcherTicking) {
			this.scheduleWatcher(this.watcherIntervalMs);
			return;
		}
		this.watcherTicking = true;
		try {
			const livePipes = await QqHookClient.listLivePipes();
			const processes = listHookProcesses();
			for (const proc of processes) {
				const state = this.ensureState(proc.pid);
				state.name = proc.name || state.name;
				state.path = proc.path || state.path;
			}
			for (const pid of livePipes) {
				const state = this.ensureState(pid);
				if (!state.injected) {
					state.injected = true;
					state.method = state.method || "reconnect";
					if (state.status === "available") state.status = "connecting";
					log$1.info("Detected pre-existing SnowLuma pipe in PID=%d", pid);
				}
			}
			const runningSet = new Set(processes.map((p) => p.pid));
			const tasks = [];
			for (const state of [...this.states.values()]) {
				const alivePipe = livePipes.has(state.pid);
				if (!runningSet.has(state.pid) && !alivePipe && !state.injected && !state.client) {
					this.states.delete(state.pid);
					continue;
				}
				if (state.connected && !alivePipe) {
					tasks.push(this.serialize(state.pid, async () => this.reconcileLostPipe(state.pid)).catch((err) => log$1.warn("watcher teardown failed: PID=%d err=%s", state.pid, this.errMsg(err))));
					continue;
				}
				if (state.injected && !state.connected && alivePipe) {
					tasks.push(this.serialize(state.pid, async () => this.reconcileConnect(state.pid)).catch((err) => log$1.warn("watcher connect failed: PID=%d err=%s", state.pid, this.errMsg(err))));
					continue;
				}
				if (state.injected && !state.connected && !alivePipe) {
					if (state.status !== "error" && state.status !== "disconnected" && state.status !== "loading") state.status = "connecting";
				}
			}
			await Promise.all(tasks);
		} finally {
			this.watcherTicking = false;
			this.scheduleWatcher(this.watcherIntervalMs);
		}
	}
	/** Re-check pipe and connect under the per-PID lock. */
	async reconcileConnect(pid) {
		const state = this.states.get(pid);
		if (!state || !state.injected || state.connected) return;
		if (state.client?.isClosed) this.tearDownClient(state);
		if (!(await QqHookClient.listLivePipes()).has(pid)) return;
		await this.attemptConnect(state);
	}
	/** Tear down a client whose pipe disappeared. */
	async reconcileLostPipe(pid) {
		const state = this.states.get(pid);
		if (!state || !state.connected) return;
		if ((await QqHookClient.listLivePipes()).has(pid)) return;
		const wasLoggedIn = state.loggedIn;
		this.tearDownClient(state);
		state.status = state.injected ? wasLoggedIn ? "disconnected" : "connecting" : "available";
		if (wasLoggedIn) this.bridgeManager.onPidDisconnected(pid);
	}
	async attemptConnect(state) {
		if (state.connected) return;
		if (state.client?.isClosed) this.tearDownClient(state);
		if (!state.client) {
			state.client = new QqHookClient(state.pid);
			state.sender = new HookPacketClient(state.client);
			state.bound = false;
		}
		if (!state.bound) {
			this.bindClient(state, state.client);
			state.bound = true;
		}
		const client = state.client;
		try {
			await client.connectAll({ recv: true });
			state.connected = true;
			state.status = client.isLoggedIn ? "online" : "loaded";
			state.error = "";
			const loginState = client.getLoginState();
			if (loginState.loggedIn) this.handleLoginState(state, loginState);
			log$1.info("pipe connected: PID=%d", state.pid);
		} catch (error) {
			state.error = this.errMsg(error);
			this.tearDownClient(state);
			state.status = state.injected ? "connecting" : "available";
		}
	}
	bindClient(state, client) {
		client.on("packet", (packet) => this.handlePacket(state, packet));
		client.on("loginState", (loginState) => this.handleLoginState(state, loginState));
		client.on("error", (error) => {
			const msg = this.errMsg(error);
			state.error = msg;
			log$1.warn("pipe error: PID=%d err=%s", state.pid, msg);
		});
		client.on("close", () => {
			if (this.disposed) return;
			if (state.client !== client) return;
			this.serialize(state.pid, async () => {
				if (state.client !== client) return;
				const wasLoggedIn = state.loggedIn;
				this.tearDownClient(state);
				if (!state.injected) state.status = "available";
				else if (wasLoggedIn) {
					state.status = "disconnected";
					this.bridgeManager.onPidDisconnected(state.pid);
				} else state.status = "connecting";
			}).catch((err) => log$1.warn("close reconcile failed: PID=%d err=%s", state.pid, this.errMsg(err)));
		});
	}
	/** Detach + close the current client and reset its associated fields. */
	tearDownClient(state) {
		const client = state.client;
		if (client) {
			client.removeAllListeners();
			try {
				client.close();
			} catch {}
		}
		state.client = null;
		state.sender = null;
		state.bound = false;
		state.connected = false;
		state.loggedIn = false;
	}
	handleLoginState(state, loginState) {
		const wasLoggedIn = state.loggedIn;
		const previousUin = state.uin;
		state.uin = loginState.uin || loginState.uinNumber.toString();
		state.loggedIn = loginState.loggedIn && isRealUin(state.uin);
		state.status = state.loggedIn ? "online" : state.connected ? "loaded" : state.status;
		if (!state.loggedIn || !state.sender) return;
		if (wasLoggedIn && previousUin === state.uin) return;
		this.bridgeManager.onHookLogin(state.pid, state.uin, state.sender);
		log$1.success("login detected: PID=%d UIN=%s", state.pid, state.uin);
	}
	handlePacket(state, packet) {
		if (!state.loggedIn) return;
		const uin = packet.uin || state.uin;
		if (!isRealUin(uin)) return;
		this.ntqq.onHookPacket(state.pid, {
			...packet,
			uin
		});
	}
	toPublicInfo(state) {
		return {
			pid: state.pid,
			name: state.name,
			path: state.path,
			injected: state.injected,
			connected: state.connected,
			loggedIn: state.loggedIn,
			uin: state.uin,
			status: state.status,
			error: state.error,
			method: state.method
		};
	}
	errMsg(value) {
		return value instanceof Error ? value.message : String(value);
	}
};
function isRealUin(uin) {
	if (!uin || uin === "0") return false;
	return /^\d+$/.test(uin) && uin.length >= 5;
}
//#endregion
//#region src/index.ts
var runtimeConfig = loadRuntimeConfig();
var log = createLogger("App");
async function main() {
	log.info("SnowLuma starting");
	const ntqq = new NtqqHandler();
	const bridgeManager = new BridgeManager();
	const oneBotManager = new OneBotManager();
	const hookManager = new HookManager(ntqq, bridgeManager);
	bridgeManager.bind(ntqq);
	oneBotManager.bind(bridgeManager);
	try {
		log.info("WebUI is enabled, starting...");
		const { initWebUI } = await import("./server-CVf9X0L2.js");
		await initWebUI(runtimeConfig.webuiPort || 5099, oneBotManager, hookManager);
	} catch (err) {
		log.error("Failed to start WebUI: ", err);
	}
	process.on("SIGINT", () => {
		log.warn("Shutting down...");
		oneBotManager.dispose();
		hookManager.dispose();
		process.exit(0);
	});
}
main().catch((error) => {
	log.error(error instanceof Error ? error.stack ?? error.message : String(error));
	process.exit(1);
});
//#endregion
