import { t as createLogger } from "./logger-eam4arGv.js";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region src/onebot/event-filter.ts
/**
* Extract the dispatch options from an adapter. Each adapter is fully
* self-describing — there is no global fallback. Defaults are applied here
* only as a safety net for partially-deserialized legacy configs.
*/
function resolveReportOptions(network) {
	return {
		messageFormat: network.messageFormat ?? "array",
		reportSelfMessage: network.reportSelfMessage ?? false
	};
}
/**
* Build the dispatch payload for one canonical OneBot event. Performs at most
* two `JSON.stringify` calls (one per format variant) regardless of how many
* adapters the payload will fan out to.
*/
function buildDispatchPayload(event) {
	const isSelfMessage = event.post_type === "message_sent";
	const arrayJson = JSON.stringify(event);
	let stringJson = arrayJson;
	if ((event.post_type === "message" || event.post_type === "message_sent") && Array.isArray(event.message)) {
		const raw = typeof event.raw_message === "string" ? event.raw_message : "";
		stringJson = JSON.stringify({
			...event,
			message: raw
		});
	}
	return {
		isSelfMessage,
		arrayJson,
		stringJson
	};
}
/**
* Pick the pre-serialized payload variant an adapter should send, or `null`
* when the adapter chose not to receive this event. Hot-path helper: one
* branch + one map lookup per connection, no allocation.
*/
function pickDispatchJson(payload, options) {
	if (payload.isSelfMessage && !options.reportSelfMessage) return null;
	return options.messageFormat === "string" ? payload.stringJson : payload.arrayJson;
}
/**
* One-shot variant of {@link buildDispatchPayload} + {@link pickDispatchJson}
* for ad-hoc events (e.g. WS connection bootstrap meta events) that aren't
* worth pre-building a full payload for.
*
* Returns `null` when the adapter shouldn't see this event. Otherwise returns
* the original event untouched, or a shallow clone with `message` rewritten.
*/
function shapeEventForAdapter(event, options) {
	if (event.post_type === "message_sent" && !options.reportSelfMessage) return null;
	if (options.messageFormat === "string" && (event.post_type === "message" || event.post_type === "message_sent") && Array.isArray(event.message)) {
		const raw = typeof event.raw_message === "string" ? event.raw_message : "";
		return {
			...event,
			message: raw
		};
	}
	return event;
}
//#endregion
//#region src/onebot/http-post-transport.ts
var http_post_transport_exports = /* @__PURE__ */ __exportAll({
	HttpPostTransport: () => HttpPostTransport,
	executeQuickOperation: () => executeQuickOperation
});
var log = createLogger("OneBot.POST");
var DEFAULT_TIMEOUT_MS = 5e3;
var HttpPostTransport = class {
	context;
	clients = /* @__PURE__ */ new Map();
	stopped = false;
	constructor(config, context) {
		this.clients = resolveClients(config);
		this.context = context;
	}
	start() {
		this.stopped = false;
		if (this.clients.size > 0) log.info("configured %d HTTP POST adapter(s): %s", this.clients.size, [...this.clients.keys()].join(", "));
	}
	reloadConfig(config) {
		this.clients = resolveClients(config);
		log.info("reloaded %d HTTP POST adapter(s)", this.clients.size);
	}
	stop() {
		this.stopped = true;
	}
	/**
	* Forward one canonical event to every active HTTP push client.
	*
	* The instance pre-builds the {@link DispatchPayload} so this method only
	* picks the right pre-serialized variant per client (zero extra
	* `JSON.stringify` calls). The raw `event` is still kept around because the
	* quick-operation handler reads structured fields from it.
	*/
	publishEvent(event, payload) {
		if (this.stopped || this.clients.size === 0) return;
		const dispatch = payload ?? buildDispatchPayload(event);
		for (const client of this.clients.values()) {
			const json = pickDispatchJson(dispatch, client.options);
			if (json === null) continue;
			this.postEvent(client.network, json, event);
		}
	}
	async postEvent(network, payload, event) {
		if (this.stopped) return;
		const headers = {
			"Content-Type": "application/json",
			"User-Agent": "OneBot",
			"X-Self-ID": this.context.uin
		};
		if (network.accessToken) headers["X-Signature"] = await computeHmacSha1(network.accessToken, payload);
		const timeoutMs = network.timeoutMs ?? DEFAULT_TIMEOUT_MS;
		try {
			const response = await fetch(network.url, {
				method: "POST",
				headers,
				body: payload,
				signal: AbortSignal.timeout(timeoutMs)
			});
			if (response.ok) {
				if ((response.headers.get("content-type") ?? "").includes("application/json")) {
					const body = await response.text();
					if (body.trim()) await this.handleQuickOperation(event, body);
				}
			} else log.warn("[%s] POST %s returned %d", network.name, network.url, response.status);
		} catch (error) {
			if (!this.stopped) log.warn("[%s] POST %s failed: %s", network.name, network.url, error instanceof Error ? error.message : String(error));
		}
	}
	async handleQuickOperation(event, responseBody) {
		try {
			const operation = JSON.parse(responseBody);
			if (!operation || typeof operation !== "object") return;
			await executeQuickOperation(event, operation, this.context.api);
		} catch (error) {
			log.warn("quick operation failed: %s", error instanceof Error ? error.message : String(error));
		}
	}
};
function resolveClients(config) {
	const out = /* @__PURE__ */ new Map();
	for (const network of config.networks.httpClients) {
		if (network.enabled === false) continue;
		if (!network.url) continue;
		out.set(network.name, {
			network,
			options: resolveReportOptions(network)
		});
	}
	return out;
}
async function computeHmacSha1(secret, payload) {
	const { createHmac } = await import("crypto");
	return "sha1=" + createHmac("sha1", secret).update(payload).digest("hex");
}
/**
* Execute a quick operation based on the event type and the response body.
* This implements the .handle_quick_operation hidden API behavior.
* See: https://github.com/botuniverse/onebot-11/blob/master/api/hidden.md
*/
async function executeQuickOperation(event, operation, api) {
	const postType = event.post_type;
	if (postType === "message") {
		if (operation.reply !== void 0 && operation.reply !== null && operation.reply !== "") {
			const messageType = event.message_type;
			const autoEscape = !!operation.auto_escape;
			if (messageType === "group") {
				const params = {
					group_id: event.group_id,
					message: operation.reply,
					auto_escape: autoEscape
				};
				if (operation.at_sender !== false && event.user_id) {
					const atSegment = {
						type: "at",
						data: { qq: String(event.user_id) }
					};
					if (typeof operation.reply === "string") {
						params.message = [atSegment, {
							type: "text",
							data: { text: operation.reply }
						}];
						params.auto_escape = false;
					} else if (Array.isArray(operation.reply)) params.message = [atSegment, ...operation.reply];
				}
				await api.handle("send_group_msg", params);
			} else if (messageType === "private") await api.handle("send_private_msg", {
				user_id: event.user_id,
				message: operation.reply,
				auto_escape: autoEscape
			});
		}
		if (operation.delete) await api.handle("delete_msg", { message_id: event.message_id });
		if (operation.ban && event.message_type === "group") {
			const duration = typeof operation.ban_duration === "number" ? operation.ban_duration : 1800;
			await api.handle("set_group_ban", {
				group_id: event.group_id,
				user_id: event.user_id,
				duration
			});
		}
		if (operation.kick && event.message_type === "group") await api.handle("set_group_kick", {
			group_id: event.group_id,
			user_id: event.user_id,
			reject_add_request: !!operation.reject_add_request
		});
	}
	if (postType === "request") {
		if (operation.approve !== void 0) {
			const requestType = event.request_type;
			if (requestType === "friend") await api.handle("set_friend_add_request", {
				flag: event.flag,
				approve: operation.approve,
				remark: operation.remark ?? ""
			});
			else if (requestType === "group") await api.handle("set_group_add_request", {
				flag: event.flag,
				sub_type: event.sub_type,
				approve: operation.approve,
				reason: operation.reason ?? ""
			});
		}
	}
}
//#endregion
export { resolveReportOptions as a, pickDispatchJson as i, http_post_transport_exports as n, shapeEventForAdapter as o, buildDispatchPayload as r, HttpPostTransport as t };
