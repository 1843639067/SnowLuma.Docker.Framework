import { format } from "util";
//#region src/utils/logger.ts
var LEVEL_WEIGHT = {
	debug: 10,
	info: 20,
	success: 25,
	warn: 30,
	error: 40
};
var LEVEL_LABEL = {
	debug: "DEBUG",
	info: "INFO",
	success: "OK",
	warn: "WARN",
	error: "ERROR"
};
var COLOR_CODE = {
	debug: 90,
	info: 36,
	success: 32,
	warn: 33,
	error: 31
};
var COLOR_SCOPE = 35;
var COLOR_DIM = 2;
var COLOR_RESET = "\x1B[0m";
var MAX_LOG_ENTRIES = 1e3;
var logEntries = [];
var logSubscribers = /* @__PURE__ */ new Set();
var nextLogId = 1;
function resolveMinLevel() {
	const raw = (process.env.SNOWLUMA_LOG_LEVEL ?? "info").toLowerCase();
	if (raw === "debug" || raw === "info" || raw === "success" || raw === "warn" || raw === "error") return raw;
	return "info";
}
var MIN_LEVEL = resolveMinLevel();
function shouldLog(level) {
	return LEVEL_WEIGHT[level] >= LEVEL_WEIGHT[MIN_LEVEL];
}
function useColor() {
	if (process.env.NO_COLOR === "1") return false;
	return Boolean(process.stdout.isTTY);
}
function ansi(code, text) {
	return `\x1b[${code}m${text}${COLOR_RESET}`;
}
function currentTime() {
	const d = /* @__PURE__ */ new Date();
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
}
function render(level, scope, args) {
	const message = format(...args);
	const ts = currentTime();
	const label = LEVEL_LABEL[level].padEnd(5, " ");
	if (!useColor()) return `${ts} ${label} [${scope}] ${message}`;
	return `${ansi(COLOR_DIM, ts)} ${ansi(COLOR_CODE[level], label)} ${ansi(COLOR_SCOPE, `[${scope}]`)} ${message}`;
}
function emit(level, options, args) {
	if (!shouldLog(level)) return;
	const message = format(...args);
	const line = render(level, options.scope, args);
	const entry = {
		id: nextLogId++,
		time: (/* @__PURE__ */ new Date()).toISOString(),
		level,
		scope: options.scope,
		message,
		line
	};
	logEntries.push(entry);
	if (logEntries.length > MAX_LOG_ENTRIES) logEntries.shift();
	for (const subscriber of logSubscribers) subscriber(entry);
	(level === "warn" || level === "error" ? process.stderr : process.stdout).write(line.replace(/[\x00-\x1A\x1C-\x1F\x7F]/g, "") + "\n");
}
function getRecentLogs(limit = 300) {
	const n = Math.max(1, Math.min(Math.trunc(limit), MAX_LOG_ENTRIES));
	return logEntries.slice(-n);
}
function subscribeLogs(callback) {
	logSubscribers.add(callback);
	return () => {
		logSubscribers.delete(callback);
	};
}
function createLogger(scope) {
	const options = { scope };
	return {
		debug: (...args) => emit("debug", options, args),
		info: (...args) => emit("info", options, args),
		success: (...args) => emit("success", options, args),
		warn: (...args) => emit("warn", options, args),
		error: (...args) => emit("error", options, args)
	};
}
//#endregion
export { getRecentLogs as n, subscribeLogs as r, createLogger as t };
